<?php 

/**
* 
*/
class CronController
{

	public $config;

	function __construct ()
	{
		$this->config = Settings::getSettings();
	}

	public function actionLeaders ()
	{

		$time = time();

		$users = array();

		$leads_comps = Competition::getLeaderCompetitions($time);

		if (count($leads_comps) == 0) return;

		foreach ($leads_comps as $comp) 
		{
			$need_time = $time - $comp['term'] * 60 * 60 * 24;

			$users[$comp['name']] = User::getLeaders($need_time);

			// получаем старых победителей
			$old_winers = User::getOldWiners($comp['name']);

			if (count($old_winers) > 0)
			{

				// дёргаем им баланс
				foreach ($old_winers as $winer) 
				{

					if ($winer['lastupdate'] != $time)
					{
						User::updateBalances($winer);

						User::updateLastUpdate($time, $winer['id']);
					}

					// Обнуляем множитель
					User::setLeaderMultiply($winer['id'], $comp['name'], 0);

				}

			}
			
			if (count($users[$comp['name']]) > 0)
			{

				// дёргаем баланс новым победителям
				foreach ($users[$comp['name']] as $winer) 
				{

					if ($winer['lastupdate'] != $time)
					{
						User::updateBalances($winer);

						User::updateLastUpdate($time, $winer['id']);
					}

					// Устанавливаем множитель
					User::setLeaderMultiply($winer['id'], $comp['name'], $comp[$winer['place'].'m']);

				}
			}

			// Устанавливаем дату следущего окончания периода гонки
			Competition::setNewDate($comp['name'], ($time + $comp['term'] * 60 * 60 * 24));

		}

	}

}
?>