<?php 

class Multi
{

    function __construct()
    {
        #$this->db = Db::getConnection();
    }

    private function Cookies(){
        $ip = Func::GetUserIp();
        $cookies = $ip."herVamVsemOtArtemona".time();
        $cookies = md5("herVamVsemOtArtemona"."-".$cookies);

        return $cookies;
    }

    private function SetCookies(){
        setcookie(
            'fyou',
            $this->Cookies(),
            time()+360*24*60*60,
            'btc-mine-farm.ru'
        );
    }

    public function CheckCookies(){
        if ( isset($_COOKIE["fyou"]) ) {
            $cookies = $_COOKIE["fyou"];
        }else{
            $this->SetCookies();
        }
    }

    public function CheckCookiesLogin($lmail){
		
		$db = Db::getConnection();

        $sql = "SELECT COUNT(*) FROM users_001 WHERE email = :email";

		$result = $db->prepare($sql);

		$result->bindParam(':email', $lmail, PDO::PARAM_STR);

		$result->execute();

		if ($result->fetchColumn() == 1){
			
			$sql = 'SELECT multi FROM users_001 WHERE email = :email';

			$result = $db->prepare($sql);

			$result->bindParam(':email', $lmail, PDO::PARAM_STR);

			$result->execute();

            $data = $result->fetch();
            #if ($data['multi'] == 0) {
            if (is_null($data['multi'])) {
                $cookies = (isset($_COOKIE["fyou"])) ? $_COOKIE["fyou"] : $_COOKIE["fyou"];
				
				$sql = 'UPDATE users_001 SET multi = :multi WHERE email = :email';

				$result = $db->prepare($sql);

				$result->bindParam(':email', $lmail, PDO::PARAM_STR);
				$result->bindParam(':multi', $cookies, PDO::PARAM_STR);

				$result->execute();
				
				return true;
		
            }else{
                $cookies = $_COOKIE["fyou"];
                if ($data['multi'] == $cookies) {
                    # code...
                }else{
					$sql = 'UPDATE users_001 SET multi = :multi WHERE email = :email';

					$result = $db->prepare($sql);

					$result->bindParam(':email', $lmail, PDO::PARAM_STR);
					$result->bindParam(':multi', $cookies, PDO::PARAM_STR);

					$result->execute();
                }
				return true;
            }
			
        }else return false;

    }

}

?>