<?php

/**
 * Функция __autoload для автоматического подключения классов
 */
function __autoload($class_name)
{

    $array_paths = array(
        '/controllers/',
        '/models/',
        '/components/',
    );

    foreach ($array_paths as $path) 
    {
        // Формируем имя и путь к файлу с классом
        $path = ROOT . $path . $class_name . '.php';

        // Если такой файл существует, подключаем его
        if (file_exists($path)) require_once($path);

    }
}
