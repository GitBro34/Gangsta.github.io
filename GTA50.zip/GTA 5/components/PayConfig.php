<?PHP
class PayConfig
{

	# Payeer Настройки (sci) пополнение
	public $shopID = 1035169407;
	public $secretW = "9596465"; 

	# Payeer Настройки (api) авто вывод
	public $AccountNumber = 'P102234366';
	public $apiId = 43243234234;
	public $apiKey = '324234';
	
	# Freekassa Настройки (sci) пополнение
	public $fkId = '154523';
	public $fkSecret = '12345';
	public $fkSecret2 = '12345';

	# Yandex Money Настройки (sci) пополнение
	public $yandexSecret = 'CgPwlWCt+WHnh65Dc7cmooli'; 
	public $yandexAcc = '12345';

	# Yandex Money Настройки (api) авто вывод
	public $yandexClientID = '173BC7BE6B5D922E5EE71EEEAA4CBFDED3555F538910BBC4E6B0A554A5278D6D';
	public $yandexApiSecret = '4792D13D8D3639A145D453B53CE56F0ED6A87D5F27ABFD3775F31FBDF88BE08BDA1AB314066229930EC299CCC15CA60B3308257C0928D97C1A0173DF7EE2B377';
	public $yandexApiTock = false;

	public function yandexRedirecturi ()
	{
		return PROTOCOL."://".HOST."/handler/ymtocken";
	}

	# Настройки ВКонтакте  
	public $vk_group_id = 184820240;
	public $vk_id = 7070923;
	public $vk_key = 'KSjFlRVZdt4u0UfFonHn';

	public function vk_redirect_uri ()
	{
		return  PROTOCOL."://".HOST."/handler/vk";
	}

	# Настройки ReCaptcha
	public $rc_site_key = '6Lcsu_sUAAAAAB0zg1Lxr7gD1u-kx56FSGG-Rtxp';
	public $rc_secret_key = '6Lcsu_sUAAAAAI7slOVyJyN6IAbC2TJhzh8PeayA';

	# paykassa_sci  пополнение
    public $secretPayKass = "12345";
    public $idPayKass = "3417";

    # paykassa_API авто вывод
    public $secretPayKey = "12345";
    public $apiPayId = "123";

}