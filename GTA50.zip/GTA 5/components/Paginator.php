<?php

class Paginator
{

	private function ParseURLNavigation($str, $page)
	{
	
		$array_a = array("/page/{$page}/", "/page/{$page}", "#");
	
		return str_replace($array_a, "", $str);
	
	}

	public function getQuery ($module, $num_page, $on_page, $sort = false, $usid = 0)
	{
		$lim = ($num_page - 1) * $on_page;

		if ($sort) $sort = $this->getSort($module, $sort);

		switch ($module) 
		{
			case 'AdminSerfing':
				return "SELECT db_serfing_plans.*, db_serfing.* FROM db_serfing LEFT JOIN db_serfing_plans ON db_serfing.plan = db_serfing_plans.id WHERE db_serfing.status > 0 ORDER BY db_serfing.id DESC LIMIT ".$lim.", ".$on_page;
				break;
			case 'AdminSerfingnew':
				return "SELECT db_serfing_plans.*, db_serfing.* FROM db_serfing LEFT JOIN db_serfing_plans ON db_serfing.plan = db_serfing_plans.id WHERE db_serfing.status = 0 ORDER BY db_serfing.id DESC LIMIT ".$lim.", ".$on_page;
				break;
			case 'MainFeedback':
				return "SELECT * FROM db_feedback WHERE status = 1 ORDER BY id DESC LIMIT ".$lim.", ".$on_page;
				break;
			case 'AdminFeedbacknew':
				return "SELECT * FROM db_feedback WHERE status = 0 ORDER BY id DESC LIMIT ".$lim.", ".$on_page;
				break;
			case 'AdminInserts':
				return "SELECT * FROM db_insert WHERE status = 1 ORDER BY date_add DESC LIMIT ".$lim.", ".$on_page;
				break;
			case 'AdminPayments':
				#return "SELECT * FROM db_payment WHERE status = 1 ORDER BY date_add DESC LIMIT ".$lim.", ".$on_page;
				return "SELECT * FROM db_payment ORDER BY date_add DESC LIMIT ".$lim.", ".$on_page;
				break;
			case 'AdminDeposits':
				return "SELECT db_plans.*, db_deposits.* FROM db_deposits LEFT JOIN db_plans ON db_deposits.plan = db_plans.id ORDER BY db_deposits.date_add DESC LIMIT ".$lim.", ".$on_page;
				break;
			case 'AdminUsers':
				return "SELECT *, INET_NTOA(ip) uip, (users_002.money_b) money_b, (users_002.money_p) money_p, (users_002.money_r) money_r, (users_002.money_k) money_k, (SELECT SUM(db_plans.perc) FROM db_deposits LEFT JOIN db_plans ON db_deposits.plan = db_plans.id WHERE db_deposits.user_id = users_001.id) speed FROM users_001 LEFT JOIN users_002 ON users_002.id = users_001.id WHERE users_001.id = users_002.id ORDER BY ".$sort." DESC LIMIT ".$lim.", ".$on_page;
				break;
			case 'AdminUsersMulty':
				return "SELECT `multi`,`user`,`id`,INET_NTOA(ip) uip,`email`,`date_reg`,`banned` FROM `users_001` WHERE `multi` IN (SELECT `multi` FROM `users_001` GROUP BY `multi` HAVING count(*)>1) ORDER BY multi DESC";
				break;

		}
	}

	public function getPagination ($module, $num_page, $on_page, $sort = false, $usid = 0)
	{

		$db = Db::getConnection();

		switch ($module) 
		{
			case 'AdminSerfing':
				$sql = 'SELECT COUNT(*) FROM db_serfing WHERE status > 0';
				$result = $db->prepare($sql);
				$format = '/admin/serfing/';
				break;
			case 'AdminSerfingnew':
				$sql = 'SELECT COUNT(*) FROM db_serfing WHERE status = 0';
				$result = $db->prepare($sql);
				$format = '/admin/serfing/new/';
				break;
			case 'MainFeedback':
				$sql = 'SELECT COUNT(*) FROM db_feedback WHERE status = 1';
				$result = $db->prepare($sql);
				$format = '/feedback/';
				break;
			case 'AdminFeedback':
				$sql = 'SELECT COUNT(*) FROM db_feedback WHERE status = 1';
				$result = $db->prepare($sql);
				$format = '/admin/feedback/';
				break;
			case 'AdminFeedbacknew':
				$sql = 'SELECT COUNT(*) FROM db_feedback WHERE status = 0';
				$result = $db->prepare($sql);
				$format = '/admin/feedback/new/';
				break;
			case 'AdminInserts':
				$sql = 'SELECT COUNT(*) FROM db_insert WHERE status = 1';
				$result = $db->prepare($sql);
				$format = '/admin/inserts/';
				break;
			case 'AdminPayments':
				$sql = 'SELECT COUNT(*) FROM db_payment WHERE status = 1';
				$result = $db->prepare($sql);
				$format = '/admin/payments/';
				break;
			case 'AdminDeposits':
				$sql = 'SELECT COUNT(*) FROM db_deposits';
				$result = $db->prepare($sql);
				$format = '/admin/deposits/';
				break;
			case 'AdminUsers':
				$sql = 'SELECT COUNT(*) FROM users_002';
				$result = $db->prepare($sql);
				$format = '/admin/users/'.$sort.'/';
				break;
			case 'AdminMulty':
				$sql = 'SELECT COUNT(*) FROM users_001';
				$result = $db->prepare($sql);
				$format = '/admin/multy/'.$sort.'/';
				break;

		}

		$result->execute();

		$all_pages = $result->fetchColumn();

		if($all_pages > $on_page) return '<ul class="pagination">'.$this->Navigation(10, $num_page, ceil($all_pages / $on_page), $format).'</ul>';
		
	}

	private function getSort ($module, $sort)
	{

		switch ($module) 
		{

			case 'AdminUsers':
				switch ($sort) 
				{
					case 1:
						return 'users_001.user';
						break;
					case 'b':
						return 'users_002.money_b';
						break;
					case 'p':
						return 'users_002.money_p';
						break;
					case 'r':
						return 'users_002.money_r';
						break;
					case 'k':
						return 'users_002.money_k';
						break;
					case 5:
						return 'users_001.date_reg';
						break;
					case 6:
						return 'users_001.ip';
						break;

				}
				break;

		}
	}

	public function issetPage ($module, $on_page, $page, $usid = 0)
	{

		$db = Db::getConnection();

		switch ($module) 
		{

			case 'AdminSerfing':
				$sql = 'SELECT COUNT(*) FROM db_serfing WHERE status > 0';
				$result = $db->prepare($sql);
				break;
			case 'AdminSerfingnew':
				$sql = 'SELECT COUNT(*) FROM db_serfing WHERE status = 0';
				$result = $db->prepare($sql);
				break;
			case 'MainFeedback':
				$sql = 'SELECT COUNT(*) FROM db_feedback WHERE status = 1';
				$result = $db->prepare($sql);
				break;
			case 'AdminFeedbacknew':
				$sql = 'SELECT COUNT(*) FROM db_feedback WHERE status = 0';
				$result = $db->prepare($sql);
				break;
			case 'AdminInserts':
				$sql = 'SELECT COUNT(*) FROM db_insert WHERE status = 1 AND type = 2';
				$result = $db->prepare($sql);
				break;
			case 'AdminPayments':
				$sql = 'SELECT COUNT(*) FROM db_payment WHERE status = 1';
				$result = $db->prepare($sql);
				break;
			case 'AdminDeposits':
				$sql = 'SELECT COUNT(*) FROM db_deposits';
				$result = $db->prepare($sql);
				break;
			case 'AdminUsers':
				$sql = 'SELECT COUNT(*) FROM users_002';
				$result = $db->prepare($sql);
				break;
			case 'AdminMulty':
				$sql = 'SELECT COUNT(*) FROM users_001';
				$result = $db->prepare($sql);
				break;

		}

		$result->execute();

		if (($page - 1) * $on_page > $result->fetchColumn()) return 1;

		return $page;
	}
	
	function Navigation($max, $page, $AllPages, $strURI)
	{
	
		$strReturn = "";
		$left = false;
		$right = false;
		
		$strURI = $this->ParseURLNavigation($strURI, $page);
		
		$page = (intval($page) > 0) ? intval($page) : 1;
	
	
		if($AllPages <= $max)
		{
		
			for($i = 1; $i <= $AllPages; $i++)
			{
				
				if($i == $page)
				{
					
					$strReturn .= '<li class="active"><a href="'.$strURI.$i.'">'.$page.'</a></li>';
					
				}else $strReturn .= '<li><a href="'.$strURI.$i.'">'.$i.'</a> ';
				
			}
		
		}
		else
		{
			
			for($i = 1; $i <= $AllPages; $i++)
			{
				
				
				
				if($i == $page OR ($i == $page-1) OR ($i == $page-2)  OR ($i == $page-3) OR ($i == $page-4) OR ($i == $page+1) OR 
				($i == $page+2)  OR ($i == $page+3) OR ($i == $page+4))
				{
					
					if($i == $page)
					{
					
						$strReturn .= '<li class="active"><a href="'.$strURI.$i.'">'.$page.'</a></li>';
					
					}
					else
					{
							
						$strReturn .= '<li><a href="'.$strURI.$i.'">'.$i.'</a> ';
						
					}
					
				}
				else
				{
					
					if($i > $page)
					{
								
						if(!$right)
						{ 
						
							if($page <= $AllPages-6)
							{
							
								$strReturn .= " ... <a href=\"{$strURI}{$AllPages}\" class='stn'>{$AllPages}</a> "; $right = true;
							
							}
							else
							{
							
								$strReturn .= " <a href=\"{$strURI}{$AllPages}\" class='stn'>{$AllPages}</a> "; $right = true;
							
							}
						
						}
					
					}
					else
					{
						
						if(!$left)
						{
							
							if($page > 6)
							{
							
								$strReturn .= " <a href=\"{$strURI}1\" class='stn'>1</a> ... "; $left = true;
							
							}
							else
							{
							
								$strReturn .= " <a href=\"{$strURI}1\" class='stn'>1</a> "; $left = true;
							
							}
							
						}
					
					}
					
				}
				
				
			}
		
		}
		
		$left_str = '<li><a href="'.$strURI.'"1>&laquo;</a></li> ';
		$right_str = ' <li><a href="'.$strURI.($page+1).'">&raquo;</a></li>';
		
		return $left_str.$strReturn.$right_str;
		
	}

}
