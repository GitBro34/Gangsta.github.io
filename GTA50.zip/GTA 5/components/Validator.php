<?PHP

/**
* 
*/
class Validator
{

    public static function isPassword($password = NULL)
    {
        
        return (is_array($password) OR $password == NULL) ? false : (preg_match("/^[a-zA-Z0-9]{6,20}$/", $password)) ? $password : false;
    
    }

    public static function isPayPass($password = NULL)
    {
        
        return (is_array($password) OR $password == NULL) ? false : (preg_match("/^[a-zA-Z0-9]{8}$/", $password)) ? $password : false;
    
    }

    public static function isLogin($login = NULL)
    {
        
        return (is_array($login) OR $login == NULL) ? false : (preg_match("/^[a-zA-Z0-9]{4,18}$/", $login)) ? $login : false;
    
    }

    public static function isMail($mail = NULL)
    {
        
        return (is_array($mail) OR $mail == NULL) ? false : (preg_match("/^([a-zA-Z0-9\+_\-]+)(\.[a-zA-Z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $mail)) ? $mail : false;
   
    }

    public static function isUrl($url = NULL)
    {
        
        return (is_array($url) OR $url == NULL) ? false : (preg_match("/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\?\&\=\/\w \.-]*)*\/?$/", $url)) ? $url : false;
   
    }

    public static function isSystem($system = NULL)
    {
        
        if ($system === 'py' OR 
            $system === 'fk' OR 
            $system === 'bitcoin' OR 
            $system === 'ethereum' OR 
            $system === 'litecoin' OR 
            $system === 'dogecoin' OR 
            $system === 'dash' OR 
            $system === 'bitcoincash' OR 
            $system === 'zcash' OR 
            $system === 'monero' OR 
            $system === 'ethereumclassic' OR 
            $system === 'ripple' OR 
            $system === 'neo' OR 
            $system === 'gas' OR 
            $system === 'bitcoinsv' OR 
            $system === 'waves' OR 
            $system === 'tron' OR 
            $system === 'ac' OR 
            $system === 'ym' OR 
            $system === 'pyb' OR 
            $system === 'pymt' OR 
            $system === 'pymf' OR 
            $system === 'pyt' OR 
            $system === 'pokp'OR 
			$system === 'qw' OR 
			$system === 'visa') return $system;

        return false;
   
    }

    public static function isPurse($purse, $system)
    {

        switch ($system) 
        {
        	case 'py':
        		return (is_array($purse)) ? false : (preg_match("/^P[0-9]{7,}$/", $purse)) ? $purse : false;
        		break;
        	case 'ac':
        		if(is_array($purse) && empty($purse) && strlen($purse) > 255 && strpos($purse,'@') > 64) return false;
				return ( ! preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $purse)) ? false : strtolower($purse);
        		break;
            case 'ym':
                return (is_array($purse)) ? false : (preg_match("/^[0-9]{13,16}$/", $purse)) ? $purse : false;
                break;
			case 'qw':
                return (is_array($purse)) ? false : (preg_match("/^[\+]{1}[7]{1}[9]{1}[\d]{9}$/", $purse)) ? $purse : false;
                break;
            case 'pyb':
                return (is_array($purse)) ? false : (preg_match("/^[\+]{1}[7]{1}[9]{1}[\d]{9}$/", $purse)) ? $purse : false;
                break;
            case 'pymt':
                return (is_array($purse)) ? false : (preg_match("/^[\+]{1}[7]{1}[9]{1}[\d]{9}$/", $purse)) ? $purse : false;
                break;
            case 'pymf':
                return (is_array($purse)) ? false : (preg_match("/^[\+]{1}[7]{1}[9]{1}[\d]{9}$/", $purse)) ? $purse : false;
                break;
            case 'pyt':
                return (is_array($purse)) ? false : (preg_match("/^[\+]{1}[7]{1}[9]{1}[\d]{9}$/", $purse)) ? $purse : false;
                break;
            case 'pokp':
                return (is_array($purse)) ? false : (preg_match("/^([O]{1}[K]{1}[\d]{9}|.*@.*)$/", $purse)) ? $purse : false;
                break;
			case 'visa':
                return (is_array($purse)) ? false : (preg_match("/^([45]{1}[\d]{15}|[6]{1}[\d]{17})$/", $purse)) ? $purse : false;
                break;
        }

        return false;
    }

    public static function isClean($text)
    {
        
        return strip_tags($text);
   
    }

}

?>