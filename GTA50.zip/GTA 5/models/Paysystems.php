<?php 

/**
* 
*/
class Paysystems
{

    public static $paynames = array(
        'ac' => 'AdvancedCash',
        'py' => 'Payeer',
        'bitcoin' => 'BitCoin',
        'ethereum' => 'Ethereum',
        'litecoin' => 'litecoin',
        'dogecoin' => 'Dogecoin',
        'dash' => 'Dash',
        'bitcoincash' => 'Bitcoincash',
        'zcash' => 'Zcash',
        'monero' => 'Monero',
        'ethereumclassic' => 'Ethereumclassic',
        'ripple' => 'Ripple',
        'neo' => 'Neo',
        'gas' => 'Gas',
        'bitcoinsv' => 'Bitcoinsv',
        'waves' => 'Waves',
        'tron' => 'Tron',
        'fk' => 'FreeKassa',
        'ym' => 'YandexMoney',
		'qw' => 'QiWi',
        'pyb' => 'Beeline',
        'pymt' => 'Mts',
        'pymf' => 'Megafon',
        'pyt' => 'Tele2',
        'pokp' => 'OkPay',
		'visa' => 'Visa',
    );

    public static $payexamples = array(
        'ac' => 'sample@domain.zn',
        'py' => 'P123456789',
        'bitcoin' => 'bi567vb5785in6b356ub743gfi5kbhy',
        'ethereum' => 'bi567vb5785in6b356ub743gfi5kbhy',
      	'fk' => '+79603578977',
		'ym' => '410014084969041',
		'qw' => '+79181234567',
        'pyb' => '+79030001122',
        'pymt' => '+79130001122',
        'pymf' => '+79230001122',
        'pyt' => '+79230001122',
        'pokp' => 'OK123456789',
		'visa' => '4500 1234 5678 9101',
    );

    // мин. и макс. на пополнение
    public static $arrMinMax = array(
        'bitcoin' => array(
            'min' => 0.00010000,
            'max' => 10000,
        ),
        'ethereum' => array(
            'min' => 0.00300000,
            'max' => 10000,
        ),
        'litecoin' => array(
            'min' => 0.00300000,
            'max' => 10000,
        ),
        'dogecoin' => array(
            'min' => 100.00000000,
            'max' => 100000000,
        ),
        'dash' => array(
            'min' => 0.00060000,
            'max' => 10000,
        ),
        'bitcoincash' => array(
            'min' => 0.00040000,
            'max' => 10000,
        ),
        'zcash' => array(
            'min' => 0.00200000,
            'max' => 10000,
        ),
        'monero' => array(
            'min' => 0.00200000,
            'max' => 10000,
        ),
        'ethereumclassic' => array(
            'min' => 0.00300000,
            'max' => 10000,
        ),
        'ripple' => array(
            'min' => 1.000000,
            'max' => 1000000,
        ),
        'neo' => array(
            'min' => 1.00000000,
            'max' => 1000000,
        ),
        'gas' => array(
            'min' => 0.10000000,
            'max' => 1000000,
        ),
        'bitcoinsv' => array(
            'min' => 0.00100000,
            'max' => 100000,
        ),
        'waves' => array(
            'min' => 0.001000,
            'max' => 100000000,
        ),
        'tron' => array(
            'min' => 0.001000,
            'max' => 1000000000,
        ),
    );

    public static function doWithdraw ($user_data, $ps, $amount, $payconfig)
    {

        $time = time();

        $comment = "Выплата пользователю ".$user_data['user']." с проекта ".HOST;
		
		if($ps !== 'py'){
			$paysystem = Paysystems::getPaysystem($ps);
			$amount_c = Func::numPercent ($paysystem['comis'], $amount);
			$amount = $amount - $amount_c;
		}

        switch ($ps) 
        {
            case 'ac':

                $merchantWebService = new MerchantWebService();

                $arg0 = new authDTO();
                $arg0->apiName = $payconfig->advApiName;
                $arg0->accountEmail = $payconfig->advApiEmail;
                $arg0->authenticationToken = $merchantWebService->getAuthenticationToken($payconfig->advApiKey);

                $arg1 = new sendMoneyRequest();
                $arg1->amount = sprintf("%.2f", $amount);
                $arg1->currency = "RUR";
                $arg1->email = $user_data['ac'];
                $arg1->note = $comment;
                $arg1->savePaymentTemplate = false;

                $validationSendMoney = new validationSendMoney();
                $validationSendMoney->arg0 = $arg0;
                $validationSendMoney->arg1 = $arg1;

                $sendMoney = new sendMoney();
                $sendMoney->arg0 = $arg0;
                $sendMoney->arg1 = $arg1;

                try 
                {
                    $merchantWebService->validationSendMoney($validationSendMoney);
                    $sendMoneyResponse = $merchantWebService->sendMoney($sendMoney);

                    if ($res = strval($sendMoneyResponse->return)) return true;

                    else return 12;

                } 
                catch (Exception $e) 
                {

                    return 13;
                }
                break;

            case 'py':

                $payeer = new Payeer($payconfig->AccountNumber, $payconfig->apiId, $payconfig->apiKey);

                if (!$payeer->isAuth()) return 15;

                $arBalance = $payeer->getBalance();

                if($arBalance["auth_error"] != 0) return 14;

                $balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

                if( ($balance) < ($amount) ) return 13;

                $arTransfer = $payeer->transfer(array(
					'curIn' => 'RUB',
					'sum' => $amount,
					'curOut' => 'RUB',
					'to' => $user_data['py'],
					'comment' => $comment,
					'anonim' => 'Y',
                ));

                if (!empty($arTransfer["historyId"])) return true;

                else return 12;

                break;

            case 'ym':

                /*require_once(ROOT . "/components/YandexMoney/api.php");

                $api = new YandexMoney\API($payconfig->yandexApiTock);

                $request_payment = $api->requestPayment(array(
                    "pattern_id" => "p2p",
                    "to" => $user_data['ym'],
                    "amount" => $amount,
                    "comment" => $comment, 
                    "message" => $comment 
                ));

                $process_payment = $api->processPayment(array(
                    "request_id" => $request_payment->request_id,
                ));

                if ($process_payment->status == 'success') return true;

                return 12;

                break;*/
				$payeer = new Payeer($payconfig->AccountNumber, $payconfig->apiId, $payconfig->apiKey);

                if (!$payeer->isAuth()) return 15;

                $arBalance = $payeer->getBalance();

                if($arBalance["auth_error"] != 0) return 14;

                $balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

                if( ($balance) < ($amount) ) return 13;

                $arTransfer = $payeer->initOutput(array(
                    'ps' => '57378077',
                    'curIn' => 'RUB',
                    'sumOut' => $amount,
                    'curOut' => 'RUB',
                    'param_ACCOUNT_NUMBER' => $user_data['ym'],
                    'comment' => $comment,
                    ));

                if (!$arTransfer) return 12;

                $historyId = $payeer->output();

                if ($historyId > 0) return true;

                else return 12;

                break;
				
			case 'qw':

                $payeer = new Payeer($payconfig->AccountNumber, $payconfig->apiId, $payconfig->apiKey);

                if (!$payeer->isAuth()) return 15;

                $arBalance = $payeer->getBalance();

                if($arBalance["auth_error"] != 0) return 14;

                $balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

                if( ($balance) < ($amount) ) return 13;

                $arTransfer = $payeer->initOutput(array(
                    'ps' => '26808',
                    'curIn' => 'RUB',
                    'sumOut' => $amount,
                    'curOut' => 'RUB',
                    'param_ACCOUNT_NUMBER' => $user_data['qw'],
                    'comment' => $comment,
                    ));

                if (!$arTransfer) return 12;

                $historyId = $payeer->output();

                if ($historyId > 0) return true;

                else return 12;

                break;
				
			case 'visa':

                $payeer = new Payeer($payconfig->AccountNumber, $payconfig->apiId, $payconfig->apiKey);

                if (!$payeer->isAuth()) return 15;

                $arBalance = $payeer->getBalance();

                if($arBalance["auth_error"] != 0) return 14;

                $balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

                if( ($balance) < ($amount) ) return 13;

                $arTransfer = $payeer->initOutput(array(
                    'ps' => '27313794',
                    'curIn' => 'RUB',
                    'sumOut' => $amount,
                    'curOut' => 'RUB',
                    'param_ACCOUNT_NUMBER' => $user_data['visa'],
                    'comment' => $comment,
                    ));

                if (!$arTransfer) return 12;

                $historyId = $payeer->output();

                if ($historyId > 0) return true;

                else return 12;

                break;

            case 'pyb':

                $payeer = new Payeer($payconfig->AccountNumber, $payconfig->apiId, $payconfig->apiKey);

                if (!$payeer->isAuth()) return 15;

                $arBalance = $payeer->getBalance();

                if($arBalance["auth_error"] != 0) return 14;

                $balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

                if( ($balance) < ($amount) ) return 13;

                $arTransfer = $payeer->initOutput(array(
                    'ps' => '24898938',
                    'curIn' => 'RUB',
                    'sumOut' => $amount,
                    'curOut' => 'RUB',
                    'param_ACCOUNT_NUMBER' => $user_data['pyb'],
                    'comment' => $comment,
                    ));

                if (!$arTransfer) return 12;

                $historyId = $payeer->output();

                if ($historyId > 0) return true;

                else return 12;

                break;

            case 'pymt':

                $payeer = new Payeer($payconfig->AccountNumber, $payconfig->apiId, $payconfig->apiKey);

                if (!$payeer->isAuth()) return 15;

                $arBalance = $payeer->getBalance();

                if($arBalance["auth_error"] != 0) return 14;

                $balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

                if( ($balance) < ($amount) ) return 13;

                $arTransfer = $payeer->initOutput(array(
                    'ps' => '24899291',
                    'curIn' => 'RUB',
                    'sumOut' => $amount,
                    'curOut' => 'RUB',
                    'param_ACCOUNT_NUMBER' => $user_data['pymt'],
                    'comment' => $comment,
                    ));

                if (!$arTransfer) return 12;

                $historyId = $payeer->output();

                if ($historyId > 0) return true;

                else return 12;

                break;

            case 'pymf':

                $payeer = new Payeer($payconfig->AccountNumber, $payconfig->apiId, $payconfig->apiKey);

                if (!$payeer->isAuth()) return 15;

                $arBalance = $payeer->getBalance();

                if($arBalance["auth_error"] != 0) return 14;

                $balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

                if( ($balance) < ($amount) ) return 13;

                $arTransfer = $payeer->initOutput(array(
                    'ps' => '24899391',
                    'curIn' => 'RUB',
                    'sumOut' => $amount,
                    'curOut' => 'RUB',
                    'param_ACCOUNT_NUMBER' => $user_data['pymf'],
                    'comment' => $comment,
                    ));

                if (!$arTransfer) return 12;

                $historyId = $payeer->output();

                if ($historyId > 0) return true;

                else return 12;

                break;

            case 'pyt':

                $payeer = new Payeer($payconfig->AccountNumber, $payconfig->apiId, $payconfig->apiKey);

                if (!$payeer->isAuth()) return 15;

                $arBalance = $payeer->getBalance();

                if($arBalance["auth_error"] != 0) return 14;

                $balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

                if( ($balance) < ($amount) ) return 13;

                $arTransfer = $payeer->initOutput(array(
                    'ps' => '95877310',
                    'curIn' => 'RUB',
                    'sumOut' => $amount,
                    'curOut' => 'RUB',
                    'param_ACCOUNT_NUMBER' => $user_data['pyt'],
                    'comment' => $comment,
                    ));

                if (!$arTransfer) return 12;

                $historyId = $payeer->output();

                if ($historyId > 0) return true;

                else return 12;

                break;

            case 'pokp':

                $payeer = new Payeer($payconfig->AccountNumber, $payconfig->apiId, $payconfig->apiKey);

                if (!$payeer->isAuth()) return 15;

                $arBalance = $payeer->getBalance();

                if($arBalance["auth_error"] != 0) return 14;

                $balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

                if( ($balance) < ($amount) ) return 13;

                $arTransfer = $payeer->initOutput(array(
                    'ps' => '1652561',
                    'curIn' => 'RUB',
                    'sumOut' => $amount,
                    'curOut' => 'RUB',
                    'param_ACCOUNT_NUMBER' => $user_data['pokp'],
                    'comment' => $comment,
                    ));

                if (!$arTransfer) return 12;

                $historyId = $payeer->output();

                if ($historyId > 0) return true;

                else return 12;

                break;

            default:
                return 12;
                break;
        }
    }

    public static function prepeareParams ($paysystem, $amount, $lid, $user, $payconfig)
    {

        switch ($paysystem) 
        {
            case 'py':
                $m_shop = $payconfig->shopID;
                $m_orderid = $lid;
                $m_amount = number_format($amount, 2, ".", "");
                $m_curr = "RUB";
                $m_desc = base64_encode(HOST." - USER ".$user['user']);
                $m_key = $payconfig->secretW;

                $arHash = array(
                    $m_shop,
                    $m_orderid,
                    $m_amount,
                    $m_curr,
                    $m_desc,
                    $m_key
                );
                $sign = strtoupper(hash('sha256', implode(":", $arHash)));

                $params = array(
                    'location' => 'https://payeer.com/api/merchant/m.php',
                    'method' => 'get',
                    'm_shop' => $m_shop,
                    'm_orderid' => $m_orderid,
                    'm_amount' => $m_amount,
                    'm_curr' => $m_curr,
                    'm_desc' => $m_desc,
                    'm_sign' => $sign,
                    );
                return $params;
                break;

            case $paysystem == 'bitcoin' OR 
            $paysystem == 'ethereum' OR 
            $paysystem == 'litecoin' OR 
            $paysystem == 'dogecoin' OR 
            $paysystem == 'dash' OR 
            $paysystem == 'bitcoincash' OR 
            $paysystem == 'zcash' OR 
            $paysystem == 'monero' OR 
            $paysystem == 'ethereumclassic' OR 
            $paysystem == 'ripple' OR 
            $paysystem == 'neo' OR 
            $paysystem == 'gas' OR 
            $paysystem == 'bitcoinsv' OR 
            $paysystem == 'waves' OR 
            $paysystem == 'tron':

                $paykassa_merchant_id = $payconfig->idPayKass;               // идентификатор магазина
                $paykassa_merchant_password = $payconfig->secretPayKass;     // пароль магазина
                    
                    $system_id = [
                        "payeer"            => 1,  // поддерживаемая валюта RUB USD
                        "perfectmoney"      => 2,  // поддерживаемая валюта USD
                        "advcash"           => 4,  // поддерживаемая валюта RUB USD
                        "bitcoin"           => 11, // поддерживаемая валюта BTC
                        "ethereum"          => 12, // поддерживаемая валюта ETH
                        "litecoin"          => 14, // поддерживаемая валюта LTC
                        "dogecoin"          => 15, // поддерживаемая валюта DOGE
                        "dash"              => 16, // поддерживаемая валюта DASH
                        "bitcoincash"       => 18, // поддерживаемая валюта BCH
                        "zcash"             => 19, // поддерживаемая валюта ZEC
                        "monero"            => 20, // поддерживаемая валюта XMR
                        "ethereumclassic"   => 21, // поддерживаемая валюта ETC
                        "berty"             => 7,  // поддерживаемая валюта RUB USD
                        "ripple"            => 22, // поддерживаемая валюта XRP
                        "neo"               => 23, // поддерживаемая валюта NEO
                        "gas"               => 24, // поддерживаемая валюта GAS
                        "bitcoinsv"         => 25, // поддерживаемая валюта BSV
                        "waves"             => 26, // поддерживаемая валюта WAVES
                        "tron"              => 27, // поддерживаемая валюта TRX
                    ];

                    $system_echo = [
                        "payeer"            => 'Payeer',
                        "perfectmoney"      => 'Perfect Money',
                        "advcash"           => 'AdvCash',
                        "bitcoin"           => 'Bitcoin',
                        "ethereum"          => 'Ethereum',
                        "litecoin"          => 'Litecoin',
                        "dogecoin"          => 'Dogecoin',
                        "dash"              => 'Dash',
                        "bitcoincash"       => 'Bitcoin Cash',
                        "zcash"             => 'Zcash',
                        "monero"            => 'Monero',
                        "ethereumclassic"   => 'Ethereum Classic',
                        "ripple"            => 'Ripple',
                        "berty"             => 'Berty',
                        "neo"               => 'Neo',
                        "gas"               => 'Gas',
                        "bitcoinsv"         => 'BitCoinsv',
                        "waves"             => 'Waves',
                        "tron"              => 'Tron',
                    ];

                    $system_name = [
                        "payeer"            => 'RUB',  // поддерживаемая валюта RUB USD
                        "perfectmoney"      => 'USD',  // поддерживаемая валюта USD
                        "advcash"           => 'RUB',  // поддерживаемая валюта RUB USD
                        "bitcoin"           => 'BTC', // поддерживаемая валюта BTC
                        "ethereum"          => 'ETH', // поддерживаемая валюта ETH
                        "litecoin"          => 'LTC', // поддерживаемая валюта LTC
                        "dogecoin"          => 'DOGE', // поддерживаемая валюта DOGE
                        "dash"              => 'DASH', // поддерживаемая валюта DASH
                        "bitcoincash"       => 'BCH', // поддерживаемая валюта BCH
                        "zcash"             => 'ZEC', // поддерживаемая валюта ZEC
                        "monero"            => 'XMR', // поддерживаемая валюта XMR
                        "ethereumclassic"   => 'ETC', // поддерживаемая валюта ETC
                        "ripple"            => 'XRP', // поддерживаемая валюта XRP
                        "berty"             => 'RUB', // поддерживаемая валюта RUB USD
                        "neo"               => 'NEO', // поддерживаемая валюта NEO
                        "gas"               => 'GAS', // поддерживаемая валюта GAS
                        "bitcoinsv"         => 'BSV', // поддерживаемая валюта BSV
                        "waves"             => 'WAVES', // поддерживаемая валюта WAVES
                        "tron"              => 'TRX', // поддерживаемая валюта TRX
                    ];

                #$system = mb_strtoupper($paysystem);
                $system = $paysystem;

                $opts = array(
                    'http'=>array(
                        'method'=>"GET",
                        'header'=>"Accept-language: en\r\n" .
                                  "Cookie: foo=bar\r\n"
                    )
                );

                $context = stream_context_create($opts);

                $file = file_get_contents('https://api.cryptonator.com/api/ticker/'.$system_name[$system].'-rub', false, $context);
                $res = json_decode($file, true);
                $price = $res["ticker"]["price"]; # Цена за 1 еденицу

                #$sum = round(floatval($_POST["sum"]),2);
                $sum = $amount;
                
                $sumRes = $sum / $price;
                $sum = number_format($sumRes, 8, ".", "");

                $currency = $system_name[$system];
                #$$currency = 'BTC';

                $order_id = $lid;
                $comment = 'Pay for user '.$user['user'];

                $paykassa = new PayKassaSCI(
                    $paykassa_merchant_id,
                    $paykassa_merchant_password
                );

                $res = $paykassa->sci_create_order_get_data( # Для крипты
                    $sum,    // обязательный параметр, сумма платежа, пример: 1.0433
                    $currency,  // обязательный параметр, валюта, пример: BTC
                    $order_id,  // обязательный параметр, уникальный числовой идентификатор платежа в вашем системе, пример: 150800
                    $comment,   // обязательный параметр, текстовый комментарй платежа, пример: Заказ услуги #150800
                    $system_id[$system] // обязательный параметр, пример: 12 - Ethereum
                );

                define('PATH_TO_LOG',  $_SERVER['DOCUMENT_ROOT']);
                $f=fopen(PATH_TO_LOG."/log/paykassa_error.log", "ab+");
                fwrite($f, date("d.m.Y H:i:s")."; TRUE POST: ".serialize($_POST)."; res: ".serialize($res).";\n\n");
                fflush($f);
                fclose($f);

                if ($res['error']) {        // $res['error'] - true если ошибка
                    #echo $res['message'];   // $res['message'] - текст сообщения об ошибке
                    // действия в случае ошибки
                    if (isset($res["data"]["min"])) {
                        echo "<br/>Минимальная сумма пополнения ".$res["data"]["min"];
                        $url = "http://btc-mine-farm.info/insert";
                    }else{
                        echo $res["message"];
                    }
                } else {
                    $invoice = $res['data']['invoice'];     // Нормер операции в системе Paykassa.pro
                    $order_id = $res['data']['order_id'];   // Ордер в магазине
                    $wallet = $res['data']['wallet'];       // Адрес для оплаты
                    $amount = $res['data']['amount'];       // Сумма к оплате, может измениться, если комиссия переведена на клинета
                    $system = $res['data']['system'];       // Система, в которой выставлен счет
                    $url = $res['data']['url'];             // Ссылка для перехода на оплату

                    #header('Location: '.$res["data"]["url"]);

                    #echo 'Send '.$amount.' '.$currency.' to this address '.$wallet.'. Balance will be updated automatically.';
                    #echo 'Отправьте '.$amount.' '.$currency.' на этот адресс '.$wallet.' <br/>Ссылка для оплаты: <a target="_blank" href="'.$url.'">тыц</a>';
                    //Send 0.35000000 BTC to this address 32e6LAW8Nps9GJMSQK4Busm6UUUkUc4tzE. Balance will be updated automatically.
                    #header('Location: '.$res["data"]["url"]);
                    $arr = explode("=", $url);
                }

                $params = array(
                    'location' => $url,
                    'method' => 'get',
                    'hash' => $arr[1],
                    'lng' => 'ru',
                );
                return $params;

                break;

            case 'fk':
                $sum = number_format($amount, 2, ".", "");
                $sign = md5($payconfig->fkId.":".$sum.":".$payconfig->fkSecret.":".$lid);

                $params = array(
                    'location' => 'http://www.free-kassa.ru/merchant/cash.php',
                    'method' => 'get',
                    'm' => $payconfig->fkId,
                    'oa' => $sum,
                    'o' => $lid,
                    's' => $sign,
                    );
                return $params;
                break;

            case 'ac':
                $sign = hash("sha256", $payconfig->advEmail.":".$payconfig->advName.":".$amount.":RUB:".$payconfig->advKey.":".$lid);
                $params = array(
                    'location' => 'https://wallet.advcash.com/sci/',
                    'method' => 'post',
                    'ac_account_email' => $payconfig->advEmail,
                    'ac_sci_name' => $payconfig->advName,
                    'ac_amount' => $amount,
                    'ac_currency' => 'RUB',
                    'ac_order_id' => $lid,
                    'ac_sign' => $sign,
                    );
                return $params;
                break;

            case 'ym':
                $params = array(
                    'location' => 'https://money.yandex.ru/quickpay/confirm.xml',
                    'method' => 'post',
                    'receiver' => $payconfig->yandexAcc,
                    'sum' => $amount * 1.05,
                    'writable-sum' => 'false',
                    'formcomment' => '', //comment
                    'short-dest' => '', //comment
                    'targets' => $lid, //comment
                    'writable-targets' => 'false',
                    'label' => $lid, //tag
                    'quickpay-form' => 'shop',
                    'paymentType' => 'PC',
                    'comment-needed' => 'true',
                    'comment' => $lid,
                    'fio' => 0,
                    'mail' => 0,
                    'phone' => 0,
                    'address' => 0
                );
                return $params;
            default:
                return false;
                break;
        }
    }

    public static function getForm ($params)
    {
        $form = "<center><form id='form' action='";

        $location = array_shift($params);

        $form .= $location."' method='";

        $method = array_shift($params);

        $form .= $method."'>";

        foreach ($params as $key => $value) 
        {
            $form .="<input type='hidden' name='".$key."' value='".$value."'>";
        }

        $form .= "<input type='submit' value='оплатить'>";

        $form .= "</form></center>";

        $form .= "<script>document.getElementById('form').submit();</script>";

        return $form;

    }
    /**
     * @param string
     * @param bool
     * @return bool
     */
    public static function isActive($ps, $type = false)
    {

        $db = Db::getConnection();

        if ($type === false) 
        {

            $sql = 'SELECT COUNT(active) FROM db_paysystems WHERE name = :ps';

            $result = $db->prepare($sql);

            $result->bindParam(':ps', $ps, PDO::PARAM_STR);

            $result->execute();

            if ($result->fetchColumn() == 0) return false;

            $sql = 'SELECT active FROM db_paysystems WHERE name = :ps';

            $result = $db->prepare($sql);

            $result->bindParam(':ps', $ps, PDO::PARAM_STR);

            $result->execute();

            if ($result->fetchColumn() == 1) return true;

            return false;

        }
        else
        {

            $sql = 'SELECT COUNT(*) FROM db_paysystems WHERE name = :ps';

            $result = $db->prepare($sql);

            $result->bindParam(':ps', $ps, PDO::PARAM_STR);

            $result->execute();

            if ($result->fetchColumn() == 0) return false;

            $sql = 'SELECT * FROM db_paysystems WHERE name = :ps';

            $result = $db->prepare($sql);

            $result->bindParam(':ps', $ps, PDO::PARAM_STR);

            $result->execute();

            $row = $result->fetch();

            if ($row['active_'.$type] == 1) return 1;

            if ($row['active_'.$type] == 2) return 2;

            return false;

        }
        
    }

    public static function getActiveSystems()
    {

        $db = Db::getConnection();

        $paysystems = array();

        $sql = 'SELECT COUNT(*) FROM db_paysystems WHERE active = 1';

        $result = $db->query($sql);

        if ($result->fetchColumn() == 0) return $paysystems;

        $sql = 'SELECT * FROM db_paysystems WHERE active = 1';

        $result = $db->query($sql);
        
        while ($row = $result->fetch()) $paysystems[] = $row;

        return $paysystems;
    }

    public static function getPaysystemsSettings()
    {

        $paysystems = array();

        $db = Db::getConnection();

        $sql = 'SELECT * FROM db_paysystems';

        $result = $db->query($sql);
        
        while ($row = $result->fetch()) $paysystems[] = $row;

        return $paysystems;
    }

    /**
     * @param string
     * @return array/bool
     */
    public static function getPaysystem($name)
    {

        if ($name == false) return false;

        $db = Db::getConnection();

        $sql = 'SELECT COUNT(*) FROM db_paysystems WHERE name = :name';

        $result = $db->prepare($sql);

        $result->bindParam(':name', $name, PDO::PARAM_STR);

        $result->execute();

        if ($result->fetchColumn() == 0) return false;

        $sql = 'SELECT * FROM db_paysystems WHERE name = :name';

        $result = $db->prepare($sql);

        $result->bindParam(':name', $name, PDO::PARAM_STR);

        $result->execute();

        return $result->fetch();

    }

    public static function updatePaysystemsSettings($params, $name)
    {

        $db = Db::getConnection();

        $args = array();

        $sql = 'UPDATE db_paysystems SET ';

        foreach ($params as $key => $value) 
        {

            $sql .= $key." = :".$key.", ";

            $args[':'.$key] = $value; 
        }

        $args[':name'] = $name;

        $sql = substr($sql, 0, -2);

        $sql .=" WHERE name = :name";

        $result = $db->prepare($sql);

        $result->execute($args);
        
    }


}
