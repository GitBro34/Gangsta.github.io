<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Общие Настройки</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
<?=(isset($errors)) ? $errors : ''; ?>
<form action="" method="post">
  <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
<table class="table table-bordered table-striped" >
    <tr>
    <td colspan="2" align="center">-------------------Реферальная программа-------------------<br></td>
  </tr>
  <tr bgcolor="#efefef">
    <td style="padding-left:10px;">Вложенность уровней рефералки:</td>
    <td width="200" align="center"><select name="ref_lvls">
        <option value="1" <?=($settings['ref_lvls'] == 1) ? "selected" : ""; ?>>1 уровневая</option>
        <option value="2" <?=($settings['ref_lvls'] == 2) ? "selected" : ""; ?>>2 уровневая</option>
        <option value="3" <?=($settings['ref_lvls'] == 3) ? "selected" : ""; ?>>3 уровневая</option>
        <option value="4" <?=($settings['ref_lvls'] == 4) ? "selected" : ""; ?>>4 уровневая</option>
        <option value="5" <?=($settings['ref_lvls'] == 5) ? "selected" : ""; ?>>5 уровневая</option>
      </select></td>
  </tr>
  <tr>
    <td>Проценты реферу 1ур:</td>
    <td width="150" align="center"><input type="text" name="ref1" value="<?=$settings["ref1"]; ?>" /></td>
  </tr>

  <tr>
    <td>Проценты реферу 2ур:</td>
    <td width="150" align="center"><input type="text" name="ref2" value="<?=$settings["ref2"]; ?>" /></td>
  </tr>

  <tr>
    <td>Проценты реферу 3ур:</td>
    <td width="150" align="center"><input type="text" name="ref3" value="<?=$settings["ref3"]; ?>" /></td>
  </tr>

  <tr>
    <td>Проценты реферу 4ур:</td>
    <td width="150" align="center"><input type="text" name="ref4" value="<?=$settings["ref4"]; ?>" /></td>
  </tr>

  <tr>
    <td>Проценты реферу 5ур:</td>
    <td width="150" align="center"><input type="text" name="ref5" value="<?=$settings["ref5"]; ?>" /></td>
  </tr>

  
  <tr>
    <td colspan="2" align="center">-------------------Настройки ограничений пополнения------------------- <br></td>
  </tr> 
<tr>
    <td>Минимальная сумма:</td>
    <td width="150" align="center"><input type="text" name="min_ins" value="<?=$settings["min_ins"]; ?>" /></td>
  </tr>

  <tr>
    <td>Максимальная сумма:</td>
    <td width="150" align="center"><input type="text" name="max_ins" value="<?=$settings["max_ins"]; ?>" /></td>
  </tr>  
<tr>
     <td colspan="2" align="center">-------------------Настройки ограничений выплат ( Заглушка )------------------- <br></td>
  </tr> 
<tr>
    <td>Минимальная сумма:</td>
    <td width="150" align="center"><input type="text" name="min_payss" value="<?=$settings["min_payss"]; ?>" /></td>
  </tr>
    <td colspan="2" align="center">-------------------Настройки ограничений пополнения------------------- <br></td>
  </tr>   
<tr>
    <td>Часовое ограничение:</td>
    <td width="150" align="center"><input type="text" name="pay_timeout" value="<?=$settings["pay_timeout"]; ?>" /></td>
  </tr>

  <tr>
    <td colspan="2" align="center">-------------------Настройки ежедневного бонуса------------------- <br></td>
  </tr> 

  <tr>
    <td>Минимальный бонус:</td>
    <td width="150" align="center"><input type="text" name="min_bonus" value="<?=$settings["min_bonus"]; ?>" /></td>
  </tr>

  <tr>
    <td>Максимальный бонус:</td>
    <td width="150" align="center"><input type="text" name="max_bonus" value="<?=$settings["max_bonus"]; ?>" /></td>
  </tr>

  <tr>
    <td colspan="2" align="center">-------------------Бонусы------------------- <br></td>
  </tr>  
   <tr>
    <td>Бонус при регистрации:</td>
    <td width="150" align="center">
      <select name="reg_bonus">
        <option value="0" <?=($settings['reg_bonus'] == 0) ? "selected" : ""; ?>>без бонуса</option>

        <?php foreach ($plans as $plan) : ?>

          <option value="<?=$plan['id']; ?>" <?=($settings['reg_bonus'] == $plan['id']) ? "selected" : ""; ?>><?=$plan['name']; ?></option>
          
        <?php endforeach; ?>

      </select>
    </td>
  </tr>

  <tr>
    <td>Бонус за реферала 1ур. (руб.):</td>
    <td width="150" align="center"><input type="text" name="ref_bonus" value="<?=$settings["ref_bonus"]; ?>" /></td>
  </tr>

  <tr>
    <td>Бонус при пополнении (для покупок) (%):</td>
    <td width="150" align="center"><input type="text" name="insert_b_bonus" value="<?=$settings["insert_b_bonus"]; ?>" /></td>
  </tr>

  <tr>
    <td>Бонус при пополнении (для рекламы) (%):</td>
    <td width="150" align="center"><input type="text" name="insert_r_bonus" value="<?=$settings["insert_r_bonus"]; ?>" /></td>
  </tr>
  <tr>
    <td>Награда за квест вступить в группу вк (руб.):</td>
    <td width="150" align="center"><input type="text" name="vk_quest_bonus" value="<?=$settings["vk_quest_bonus"]; ?>" /></td>
  </tr>

  <tr>
    <td>Награда за квест 100 кликов серфинга (руб.):</td>
    <td width="150" align="center"><input type="text" name="serf_quest_bonus" value="<?=$settings["serf_quest_bonus"]; ?>" /></td>
  </tr>
<tr>
    <td>Награда за квест 500 кликов серфинга (руб.):</td>
    <td width="150" align="center"><input type="text" name="serf_quest_bonus2" value="<?=$settings["serf_quest_bonus2"]; ?>" /></td>
  </tr>
<tr>
    <td>Награда за квест 1000 кликов серфинга (руб.):</td>
    <td width="150" align="center"><input type="text" name="serf_quest_bonus3" value="<?=$settings["serf_quest_bonus3"]; ?>" /></td>
  </tr>
  <tr>
    <td>Награда за квест 10 рефералов (руб.):</td>
    <td width="150" align="center"><input type="text" name="ref_quest_bonus" value="<?=$settings["ref_quest_bonus"]; ?>" /></td>
  </tr>
   <tr>
    <td>Награда за квест 50 рефералов (руб.):</td>
    <td width="150" align="center"><input type="text" name="ref_quest_bonus2" value="<?=$settings["ref_quest_bonus2"]; ?>" /></td>
  </tr>
   <tr>
    <td>Награда за квест 100 рефералов (руб.):</td>
    <td width="150" align="center"><input type="text" name="ref_quest_bonus3" value="<?=$settings["ref_quest_bonus3"]; ?>" /></td>
  </tr>
  <tr>
    <td>Награда за квест Пополнение 10 (руб.):</td>
    <td width="150" align="center"><input type="text" name="ins_quest_bonus" value="<?=$settings["ins_quest_bonus"]; ?>" /></td>
  </tr>
  <tr>
    <td>Награда за квест Пополнение 50 (руб.):</td>
    <td width="150" align="center"><input type="text" name="ins_quest_bonus2" value="<?=$settings["ins_quest_bonus2"]; ?>" /></td>
  </tr>
  <tr>
    <td>Награда за квест Пополнение 100 (руб.):</td>
    <td width="150" align="center"><input type="text" name="ins_quest_bonus3" value="<?=$settings["ins_quest_bonus3"]; ?>" /></td>
  </tr>
  <tr>
    <td>Награда за квест Пополнение 500 (руб.):</td>
    <td width="150" align="center"><input type="text" name="ins_quest_bonus4" value="<?=$settings["ins_quest_bonus4"]; ?>" /></td>
  </tr>
  <tr>
    <td>Награда за квест Пополнение 1000 (руб.):</td>
    <td width="150" align="center"><input type="text" name="ins_quest_bonus5" value="<?=$settings["ins_quest_bonus5"]; ?>" /></td>
  </tr>
  <tr>
    <td>Награда за квест Пополнение 5000 (руб.):</td>
    <td width="150" align="center"><input type="text" name="ins_quest_bonus6" value="<?=$settings["ins_quest_bonus6"]; ?>" /></td>
  </tr>
  <tr>
    <td>Награда за квест Пополнение 10000 (руб.):</td>
    <td width="150" align="center"><input type="text" name="ins_quest_bonus7" value="<?=$settings["ins_quest_bonus7"]; ?>" /></td>
  </tr>
  <tr> <td colspan="2" align="center"><input name="yes" type="submit" value="Сохранить" /></td> </tr>
  

</table>
</form><BR /><BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>