<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Заявки на выплаты</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
<?=(isset($errors)) ? $errors : ''; ?>

<table class="table table-bordered table-striped" >
 <tr >
	<td align="center" class="m-tb">Платёжная система</td>
	<td align="center" class="m-tb">Кошелёк</td>
	<td align="center" class="m-tb">Пользователь</td>
	<td align="center" class="m-tb">Сумма</td>
	<td align="center" class="m-tb">Дата</td>
	<td align="center" class="m-tb">Действие</td>
  </tr>
<?php foreach($payments as $row) : ?>

	<tr class="htt">
		<td align="center"><b><?=$paynames[$row['payment_system']]; ?></b></td>
		<td align="center"><?=$row['purse']; ?></td>
		<td align="center"><a href="/admin/users/edit/<?=$row["user_id"]; ?>" class="stn"><?=$row["user"]; ?></a></td>
		<td align="center"><?=$row['sum']; ?></td>
		<td align="center"><?=date("d.m.Y H:i", $row['date_add']); ?></td>
		<td align="center">
			<form method="post" action="" style="display: inline-block;">
				<input type="hidden" name="batch" value="<?=$row['id']; ?>">
				<input type="submit" name="yes" value="выплачено">
			</form>
			<form method="post" action="" style="display: inline-block;">
				<input type="hidden" name="batch" value="<?=$row['id']; ?>">
				<input type="submit" name="no" value="отклонить">
			</form>
		</td>
	</tr>

<?php endforeach; ?>
</table>
<BR /><BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>