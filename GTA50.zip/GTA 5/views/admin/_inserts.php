<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">История пополнений</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
        <center><a href="/admin/inserts">Список пополнений</a> | <a href="/admin/inserts/days">По дням</a></center><BR />
<?php if(count($inserts) > 0) : ?>
<table class="table table-bordered table-striped" >
   <tr >
			<td align="center" width="50" class="m-tb">ID</td>
			<td align="center" width="150" class="m-tb">Пользователь</td>
			<td align="center" width="75" class="m-tb">Сумма</td>
			<td align="center" width="75" class="m-tb">Платёжка</td>
			<td align="center" width="75" class="m-tb">Счёт</td>
			<td align="center" width="150" class="m-tb">Дата операции</td>
		</tr>
		
				<?php foreach($inserts as $row) : ?>

		<tr class="htt">
		    <td align="center" width="50"><?=$row["id"]; ?></td>
		    <td align="center"><a href="/admin/users/edit/<?=$row["user_id"]; ?>" class="stn"><?=$row["user"]; ?></a></td>
		    <td align="center" width="75"><?=$row["sum"]; ?></td>
			<td align="center" width="75"><?=$row["payment_system"]; ?></td>
			<td align="center" width="75"><?=$types[$row["type"]]; ?></td>
			<td align="center" width="150"><?=date("d.m.Y в H:i:s",$row["date_add"]); ?></td>
	  	</tr>

	<?php endforeach; ?>



</table>
<?php else : ?>

	<center><b>Записей нет</b></center>

<?php endif; ?>

<?php echo $navigation; ?>

</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>