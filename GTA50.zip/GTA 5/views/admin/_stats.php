<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>

  
  <div class="content">
        <div class="header">
      

            <h1 class="page-title">Статистика проекта</h1>
                    

        </div>
        <div class="main-content">
 
 

	



<div class="panel panel-default" >

      





<table class="table table-bordered table-striped" >
  <tr bgcolor="#efefef">
    <td align="center" width="135" class="m-tb">Зарегистрировано пользователей</td>
    <td align="center" width="120"><?=$data_stats["all_users"]; ?> чел.</td>
  </tr>
<tr bgcolor="#efefef">
    <td align="center" width="135" class="m-tb">Введено пользователями:</td>
    <td align="center" width="120"><?=sprintf("%.2f",$data_stats["insert_sum"]); ?> руб.</td>
  </tr>
<tr bgcolor="#efefef">
    <td align="center" width="135" class="m-tb">Выплачено пользователям:</td>
    <td align="center" width="120"><?=sprintf("%.2f",$data_stats["payment_sum"]); ?> руб.</td>  
    </tr>
  <tr bgcolor="#efefef">
    <td align="center" width="135" class="m-tb">Денег на покупки (общая сумма):</td>
    <td align="center" width="120"><?=sprintf("%.2f",$data_stats["money_b"]); ?> руб.</td>  
    </tr>
    <tr bgcolor="#efefef">
    <td align="center" width="135" class="m-tb">Денег на вывод (общая сумма):</td>
    <td align="center" width="120"><?=sprintf("%.2f",$data_stats["money_p"]); ?> руб.</td>  
    </tr>
    <tr bgcolor="#efefef">
    <td align="center" width="135" class="m-tb">Денег на рекламу (общая сумма):</td>
    <td align="center" width="120"><?=sprintf("%.2f",$data_stats["money_r"]); ?> руб.</td>  
    </tr>
    <tr bgcolor="#efefef">
    <td align="center" width="135" class="m-tb">Денег на кассах (общая сумма):</td>
    <td align="center" width="120"><?=sprintf("%.2f",$data_stats["money_k"]); ?> руб.</td>  
    </tr>
    


		

</table>


                 
        </div>
		
    </div>





  
  
  


								
			
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>