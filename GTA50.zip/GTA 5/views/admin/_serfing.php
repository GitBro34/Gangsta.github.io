<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Серфинг</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
         <center><a href="/admin/serfing">Одобренные ссылки</a> | <a href="/admin/serfing/new">Новые (остановленные) ссылки</a></center><BR />
        
<?=(isset($errors)) ? $errors : ''; ?>
<?php if(count($serfings) > 0) : ?>
<table class="table table-bordered table-striped" >
   <tr>
			<td align="center" class="m-tb">ID</td>
			<td align="center" class="m-tb">Пользователь</td>
			<td align="center" class="m-tb">План</td>
			<td align="center" class="m-tb">Заголовок</td>
			<td align="center" class="m-tb">Ссылка</td>
			<td align="center" class="m-tb">Баланс</td>
			<td align="center" class="m-tb">Операция</td>
		</tr>
		
				<?php foreach($serfings as $row) : ?>

		<tr class="htt">
		    <td align="center"><?=$row["id"]; ?></td>
		    <td align="center"><a href="/admin/users/edit/<?=$row["user_id"]; ?>" class="stn"><?=$row["user_name"]; ?></a></td>
		    <td align="center"><?=$row["name"]; ?></td>
		    <td align="center"><?=$row["title"]; ?></td>
			<td align="center"><a href="<?=$row["url"]; ?>" target="_blank" class="stn"><?=$row["url"]; ?></a></td>
			<td align="center"><?=$row["money"]; ?></td>
			<td align="center">
				<form action="" method="POST">
					<input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
					<input type="hidden" name="id" value="<?=$row['id']; ?>">
					<input type="submit" name="stop" value="Остановить">
					<input type="submit" name="delete" value="Удалить">
				</form>
			</td>
	  	</tr>

	<?php endforeach; ?>



</table>
<?php else : ?>

	<center><b>Записей нет</b></center>

<?php endif; ?>

<?php echo $navigation; ?>
<BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>