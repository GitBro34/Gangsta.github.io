<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Конкурсы инвесторов</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
  <center><a href="/admin/competition/invest">Конкурсы инвесторов</a> | <a href="/admin/competition/referal">Конкурсы рефералов</a></center><BR />
        
<?=(isset($errors)) ? $errors : ''; ?>
<h3>Завершенные конкурсы инвесторов</h3>
<br>

<?php if($competitions) : ?>

	<?php foreach($competitions as $row) : ?>
	
	<h4>Конкурс №<?=$row["id"]; ?></h4>
<table class="table table-bordered table-striped" >
 
		<tr bgcolor="#efefef">
			<td align="center" class="m-tb">1 место</td>
			<td align="center" class="m-tb">2 место</td>
			<td align="center" class="m-tb">3 место</td>
			<td align="center" class="m-tb">4 место</td>
			<td align="center" class="m-tb">5 место</td>
			<td align="center" class="m-tb">Начат</td>
			<td align="center" class="m-tb">Завершён</td>
		</tr>

		<tr class="htt">

		    <td align="center">

		    <?php if ($row["1m_sum"] && $row["1m_perc"]) : ?>

		    	<?=$row['1m_sum']; ?> руб. + <?=$row['1m_perc']; ?> %

		    <?php elseif ($row["1m_sum"] && !$row["1m_perc"]) : ?>

		    	<?=$row['1m_sum']; ?> руб.

		    <?php elseif (!$row["1m_sum"] && $row["1m_perc"]) : ?>

		    	<?=$row['1m_perc']; ?> %
		    	
		    <?php endif ?>
		    	
		    </td>

		    <td align="center">

		    <?php if ($row["2m_sum"] && $row["2m_perc"]) : ?>

		    	<?=$row['2m_sum']; ?> руб. + <?=$row['2m_perc']; ?> %

		    <?php elseif ($row["2m_sum"] && !$row["2m_perc"]) : ?>

		    	<?=$row['2m_sum']; ?> руб.

		    <?php elseif (!$row["2m_sum"] && $row["2m_perc"]) : ?>

		    	<?=$row['2m_perc']; ?> %
		    	
		    <?php endif ?>

		    </td>

			<td align="center">
				
			<?php if ($row["3m_sum"] && $row["3m_perc"]) : ?>

		    	<?=$row['3m_sum']; ?> руб. + <?=$row['3m_perc']; ?> %

		    <?php elseif ($row["3m_sum"] && !$row["3m_perc"]) : ?>

		    	<?=$row['3m_sum']; ?> руб.

		    <?php elseif (!$row["3m_sum"] && $row["3m_perc"]) : ?>

		    	<?=$row['3m_perc']; ?> %
		    	
		    <?php endif ?>

			</td>

			<td align="center">

			<?php if ($row["4m_sum"] && $row["4m_perc"]) : ?>

		    	<?=$row['4m_sum']; ?> руб. + <?=$row['4m_perc']; ?> %

		    <?php elseif ($row["4m_sum"] && !$row["4m_perc"]) : ?>

		    	<?=$row['4m_sum']; ?> руб.

		    <?php elseif (!$row["4m_sum"] && $row["4m_perc"]) : ?>

		    	<?=$row['4m_perc']; ?> %
		    	
		    <?php endif ?>

			</td>

			<td align="center">

			<?php if ($row["5m_sum"] && $row["5m_perc"]) : ?>

		    	<?=$row['5m_sum']; ?> руб. + <?=$row['5m_perc']; ?> %

		    <?php elseif ($row["5m_sum"] && !$row["5m_perc"]) : ?>

		    	<?=$row['5m_sum']; ?> руб.

		    <?php elseif (!$row["5m_sum"] && $row["5m_perc"]) : ?>

		    	<?=$row['5m_perc']; ?> %
		    	
		    <?php endif ?>

			</td>

			<td align="center"><?=date("d.m.Y в H:i:s",$row["date_add"]); ?></td>
			<td align="center"><?=date("d.m.Y в H:i:s",$row["date_end"]); ?></td>
	  	</tr>

	</table>
<?php if (isset($row['winers'])) : $i = 0; ?>
<table class="table table-bordered table-striped" >
    <tr >
			<td align="center" class="m-tb">Место</td>
			<td align="center" class="m-tb">Пользователь</td>
			<td align="center" class="m-tb">Сумма</td>
		</tr>
		
		<?php foreach ($row['winers'] as $winer) : $i++; ?>

	  	<tr class="htt">
			<td align="center"><?php if ($i <= 5) echo $i.' место'; ?></td>
			<td align="center"><a href="/admin/users/edit/<?=$winer["user_id"]; ?>" class="stn"><?=$winer["user"]; ?></a></td>
			<td align="center"><?=$winer["sum"]; ?> руб.</td>
		</tr>		
	
	  		<?php endforeach ?>

	</table>
	<br>

	  	<?php endif ?>

	<?php endforeach; ?>

	<br>

<?php else : ?>

	<center><b>Завершённых конкурсов нет</b></center><BR />

<?php endif; ?>

<h3>Текущий конкурс инвесторов</h3>
<br>

<?php if ($active_competition) : ?>
	
<table class="table table-bordered table-striped" >
		<tr bgcolor="#efefef">
			<td align="center" class="m-tb">ID</td>
			<td align="center" class="m-tb">1 место</td>
			<td align="center" class="m-tb">2 место</td>
			<td align="center" class="m-tb">3 место</td>
			<td align="center" class="m-tb">4 место</td>
			<td align="center" class="m-tb">5 место</td>
			<td align="center" class="m-tb">Начало</td>
			<td align="center" class="m-tb">Дата завершёния</td>
		</tr>

		<tr class="htt">
		    <td align="center"><?=$active_competition["id"]; ?></td>

		    <td align="center">

		    <?php if ($active_competition["1m_sum"] && $active_competition["1m_perc"]) : ?>

		    	<?=$active_competition['1m_sum']; ?> руб. + <?=$active_competition['1m_perc']; ?> %

		    <?php elseif ($active_competition["1m_sum"] && !$active_competition["1m_perc"]) : ?>

		    	<?=$active_competition['1m_sum']; ?> руб.

		    <?php elseif (!$active_competition["1m_sum"] && $active_competition["1m_perc"]) : ?>

		    	<?=$active_competition['1m_perc']; ?> %
		    	
		    <?php endif ?>
		    	
		    </td>

		    <td align="center">

		    <?php if ($active_competition["2m_sum"] && $active_competition["2m_perc"]) : ?>

		    	<?=$active_competition['2m_sum']; ?> руб. + <?=$active_competition['2m_perc']; ?> %

		    <?php elseif ($active_competition["2m_sum"] && !$active_competition["2m_perc"]) : ?>

		    	<?=$active_competition['2m_sum']; ?> руб.

		    <?php elseif (!$active_competition["2m_sum"] && $active_competition["2m_perc"]) : ?>

		    	<?=$active_competition['2m_perc']; ?> %
		    	
		    <?php endif ?>

		    </td>

			<td align="center">
				
			<?php if ($active_competition["3m_sum"] && $active_competition["3m_perc"]) : ?>

		    	<?=$active_competition['3m_sum']; ?> руб. + <?=$active_competition['3m_perc']; ?> %

		    <?php elseif ($active_competition["3m_sum"] && !$active_competition["3m_perc"]) : ?>

		    	<?=$active_competition['3m_sum']; ?> руб.

		    <?php elseif (!$active_competition["3m_sum"] && $active_competition["3m_perc"]) : ?>

		    	<?=$active_competition['3m_perc']; ?> %
		    	
		    <?php endif ?>

			</td>

			<td align="center">

			<?php if ($active_competition["4m_sum"] && $active_competition["4m_perc"]) : ?>

		    	<?=$active_competition['4m_sum']; ?> руб. + <?=$active_competition['4m_perc']; ?> %

		    <?php elseif ($active_competition["4m_sum"] && !$active_competition["4m_perc"]) : ?>

		    	<?=$active_competition['4m_sum']; ?> руб.

		    <?php elseif (!$active_competition["4m_sum"] && $active_competition["4m_perc"]) : ?>

		    	<?=$active_competition['4m_perc']; ?> %
		    	
		    <?php endif ?>

			</td>

			<td align="center">

			<?php if ($active_competition["5m_sum"] && $active_competition["5m_perc"]) : ?>

		    	<?=$active_competition['5m_sum']; ?> руб. + <?=$active_competition['5m_perc']; ?> %

		    <?php elseif ($active_competition["5m_sum"] && !$active_competition["5m_perc"]) : ?>

		    	<?=$active_competition['5m_sum']; ?> руб.

		    <?php elseif (!$active_competition["5m_sum"] && $active_competition["5m_perc"]) : ?>

		    	<?=$active_competition['5m_perc']; ?> %
		    	
		    <?php endif ?>

			</td>

			<td align="center"><?=date("d.m.Y в H:i:s",$active_competition["date_add"]); ?></td>
			<td align="center"><?=date("d.m.Y в H:i:s",$active_competition["date_end"]); ?></td>
	  	</tr>
	</table>

	<br>
<table class="table table-bordered table-striped" >

	<?php if (count($active_competition['users']) > 0) : $i = 0; ?>
	
		<tr bgcolor="#efefef">
			<td class="m-tb">Место</td>
			<td class="m-tb">Пользователь</td>
			<td class="m-tb">Очки</td>
		</tr>

		<?php foreach ($active_competition['users'] as $row) : $i++; ?>

		<tr class="htt">
			<td><?php if ($i <= 5) echo $i.' место'; ?></td>
			<td><a href="/admin/users/edit/<?=$row["user_id"]; ?>" class="stn"><?=$row["user"]; ?></a></td>
			<td><?=$row["points"]; ?></td>
		</tr>	
		
		<?php endforeach; ?>
		
	<?php endif; ?>

		<tr> 
			<td colspan="3" align="center">
				<br>
				<form action="" method="POST">
					<input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
					<input name="yes" type="submit" value="Завершить и зачислить">
					<input name="no" type="submit" value="Отменить без призов">
				</form>
			</td> 
		</tr>
	</table>

<?php else : ?>

	<form action="" method="POST">
		<input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
		<table cellpadding='3' cellspacing='0' border='0' bordercolor='#336633' align='center' width="99%">
			<tr bgcolor="#efefef">
			    <td class="m-tb"></td>
			    <td width="150" align="center" class="m-tb">руб.</td>
			    <td width="150" align="center" class="m-tb">%</td>
			</tr>
			<tr>
			    <td><b>Приз за 1 место:</b></td>
			    <td width="150" align="center"><input type="text" name="1m_sum" value="0"></td>
			    <td width="150" align="center"><input type="text" name="1m_perc" value="0"></td>
			</tr>
			<tr>
			    <td><b>Приз за 2 место:</b></td>
			    <td width="150" align="center"><input type="text" name="2m_sum" value="0"></td>
			    <td width="150" align="center"><input type="text" name="2m_perc" value="0"></td>
			</tr>
			<tr>
			    <td><b>Приз за 3 место:</b></td>
			    <td width="150" align="center"><input type="text" name="3m_sum" value="0"></td>
			    <td width="150" align="center"><input type="text" name="3m_perc" value="0"></td>
			</tr>
			<tr>
			    <td><b>Приз за 4 место:</b></td>
			    <td width="150" align="center"><input type="text" name="4m_sum" value="0"></td>
			    <td width="150" align="center"><input type="text" name="4m_perc" value="0"></td>
			</tr>
			<tr>
			    <td><b>Приз за 5 место:</b></td>
			    <td width="150" align="center"><input type="text" name="5m_sum" value="0"></td>
			    <td width="150" align="center"><input type="text" name="5m_perc" value="0"></td>
			</tr>
			<tr>
			    <td><b>Длительность (дней):</b></td>
			    <td width="150" align="center" colspan="2"><input type="text" name="term" value="7"></td>
			</tr>
			<tr> <td colspan="3" align="center"><input name="start" type="submit" value="Запустить"></td> </tr>
		</table>
	</form>

<?php endif ?>
		
<BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>