<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Настройки планов</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
        
        
<?=(isset($errors)) ? $errors : ''; ?>

<table class="table table-bordered table-striped" >
<?php foreach ($plans as $plan) : ?>

<form action="" method="post">
  <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
  <input type="hidden" name="id" value="<?=$plan['id']; ?>">

  <tr>
    <td colspan="2" align="center">-------------------План <?=$plan['name']; ?> (<?=$plan['id']; ?>)------------------- <br></td>
  </tr> 

  <tr>
    <td>Название:</td>
    <td width="150" align="center"><input type="text" name="name" value="<?=$plan['name']; ?>" /></td>
  </tr>
    
  <tr>
    <td>Стоимость:</td>
    <td width="150" align="center"><input type="text" name="price" value="<?=$plan['price']; ?>" /></td>
  </tr>

  <tr>
    <td>Доход в час руб.:</td>
    <td width="150" align="center"><input type="text" name="perc" value="<?=$plan['perc']; ?>" /></td>
  </tr>

  <tr> 
    <td colspan="2" align="center"><input name="yes" type="submit" value="Сохранить" /></td> 
  </tr>
</form>
<?php endforeach; ?>

</table>

<BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>