<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Настройки планов серфинга</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
<?=(isset($errors)) ? $errors : ''; ?>

<table class="table table-bordered table-striped" >
    <?php foreach ($plans as $plan) : ?>
<form action="" method="post">
  <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
  <input type="hidden" name="id" value="<?=$plan['id']; ?>">
  
 <tr>
    <td colspan="2" align="center">-------------------План <?=$plan['name']; ?> (<?=$plan['id']; ?>)------------------- <br></td>
  </tr> 

  <tr>
    <td>Название:</td>
    <td width="150" align="center"><input type="text" name="name" value="<?=$plan['name']; ?>" /></td>
  </tr>
    
  <tr>
    <td>Стоимость клика для рекламодателя:</td>
    <td width="150" align="center"><input type="text" name="price" value="<?=$plan['price']; ?>" /></td>
  </tr>

  <tr>
    <td>Стоимость клика для пользователя:</td>
    <td width="150" align="center"><input type="text" name="click_price" value="<?=$plan['click_price']; ?>" /></td>
  </tr>

  <tr>
    <td>Время просмотра:</td>
    <td width="150" align="center"><input type="text" name="view_time" value="<?=$plan['view_time']; ?>" /></td>
  </tr>

  <tr>
    <td>Выделение (приоритет):</td>
    <td width="150" align="center">
      <select name="highlight">
        <option value="3" <?php if ($plan['highlight'] == 3) echo 'selected'; ?>>1 место</option>
        <option value="2" <?php if ($plan['highlight'] == 2) echo 'selected'; ?>>2 место</option>
        <option value="1" <?php if ($plan['highlight'] == 1) echo 'selected'; ?>>3 место</option>
      </select>
    </td>
  </tr>

  <tr>
    <td>Переход после просмотра:</td>
    <td width="150" align="center">
      <select name="transition">
        <option value="1" <?php if ($plan['transition'] == 1) echo 'selected'; ?>>Да</option>
        <option value="0" <?php if ($plan['transition'] == 0) echo 'selected'; ?>>Нет</option>
      </select>
    </td>
  </tr>

  <tr> 
    <td colspan="2" align="center"><input name="yes" type="submit" value="Сохранить" /></td> 
  </tr>
</form>

<?php endforeach; ?>

</table>

<BR /><BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>