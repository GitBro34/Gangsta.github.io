<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Отзывы</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
        <center><a href="/admin/feedback">Одобренные отзывы</a> | <a href="/admin/feedback/new">Новые отзывы</a></center><BR />
        
<?php if(count($feedbacks) > 0) : ?>
<table class="table table-bordered table-striped" >
  <tr bgcolor="#efefef">
			<td align="center" width="50" class="m-tb">ID</td>
			<td align="center" width="150" class="m-tb">Пользователь</td>
			<td align="center" width="75" class="m-tb">Отзыв</td>
			<td align="center" width="150" class="m-tb">Дата</td>
			<td align="center" width="150" class="m-tb">Операция</td>
		</tr>
		
			<?php foreach($feedbacks as $row) : ?>

		<tr class="htt">
		    <td align="center" width="50"><?=$row["id"]; ?></td>
		    <td align="center"><a href="/admin/users/edit/<?=$row["user_id"]; ?>" class="stn"><?=$row["user"]; ?></a></td>
		    <td align="center" width="75"><?=$row["text"]; ?></td>
			<td align="center" width="150"><?=date("d.m.Y в H:i:s",$row["date_add"]); ?></td>
			<td align="center" width="150">
				<form action="" method="POST">
					<input type="hidden" name="id" value="<?=$row['id']; ?>">
					<input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
					<input type="submit" name="delete" value="Удалить">
					<input type="submit" name="acept" value="одобрить">
				</form>
			</td>
	  	</tr>

	<?php endforeach; ?>


</table>
<?php else : ?>

	<center><b>Записей нет</b></center>

<?php endif; ?>

<?php echo $navigation; ?>
<BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>