<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Пользователи</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
<b><?=(isset($errors)) ? $errors : ''; ?></b>
<table class="table table-bordered table-striped" >
  <tr bgcolor="#efefef">
    <td style="padding-left:10px;">ID:</td>
    <td width="200" align="center"><?=$users_info["id"]; ?></td>
  </tr>
  <tr>
    <td style="padding-left:10px;">Логин:</td>
    <td width="200" align="center"><?=$users_info["user"]; ?></td>
  </tr>
  <tr bgcolor="#efefef">
    <td style="padding-left:10px;">Email:</td>
    <td width="200" align="center"><?=$users_info["email"]; ?></td>
  </tr>
  <tr>
    <td style="padding-left:10px;">Пароль:</td>
    <td width="200" align="center">********</td>
  </tr>
  
  
  <tr bgcolor="#efefef">
    <td style="padding-left:10px;">Для покупок:</td>
    <td width="200" align="center"><?=sprintf("%.3f", $users_info['money_b']); ?> руб.</td>
  </tr>
  
  <tr>
    <td style="padding-left:10px;">Для вывода:</td>
    <td width="200" align="center"><?=sprintf("%.3f", $users_info['money_p']); ?>  руб.</td>
  </tr>
   <tr>
    <td style="padding-left:10px;">Для рекламы:</td>
    <td width="200" align="center"><?=sprintf("%.3f", $users_info['money_r']); ?>  руб.</td>
  </tr>
 <tr>
    <td style="padding-left:10px;">На кассе:</td>
    <td width="200" align="center"><?=sprintf("%.3f", $users_info['money_k']); ?> руб.</td>
  </tr>
  <tr>
    <td style="padding-left:10px;">Текущая скорость:</td>
    <td width="200" align="center"><?=sprintf("%.4f", $users_info["speed"]); ?> руб/ч</td>
  </tr>
  
 <tr>
    <td style="padding-left:10px;"> </td>
  
  </tr>
 <tr>
    <td style="padding-left:10px;">Зарегистрирован:</td>
    <td width="200" align="center"><?=date("d.m.Y в H:i:s",$users_info["date_reg"]); ?></td>
  </tr>
  <tr bgcolor="#efefef">
    <td style="padding-left:10px;">Последний вход:</td>
    <td width="200" align="center"><?=date("d.m.Y в H:i:s",$users_info["date_login"]); ?></td>
  </tr>
  <tr>
    <td style="padding-left:10px;">Последний IP:</td>
    <td width="200" align="center"><?=$users_info["ip"]; ?></td>
  </tr>
  
  
  <tr bgcolor="#efefef">
    <td style="padding-left:10px;">Пополнено на баланс:</td>
    <td width="200" align="center"><?=sprintf("%.2f",$users_info["insert_sum"]); ?> руб.</td>
  </tr>
  <tr>
    <td style="padding-left:10px;">Выплачено на кошелек:</td>
    <td width="200" align="center"> <?=sprintf("%.2f",$users_info["payment_sum"]); ?> руб.</td>
  </tr>
  
   <tr>
    <td style="padding-left:10px;"> </td>
  
  </tr>
  
  <?php for ($i = 1; $i <= $this->config['ref_lvls']; $i ++) : ?>
	
	<tr >
		<td  style="padding-left:10px;">Реферальная статистика <?=$i; ?> ур. :</td>
		<td style="padding-left:10px;"> </td>
	</tr>
<tr>
		<td style="padding-left:10px;">Referer <?=$i; ?>:</td>
		<td width="200" align="center">[<?=$users_info["referer".$i."_id"]; ?>]<?=$users_info["referer".$i]; ?></td>
	</tr>
<tr>
		<td  style="padding-left:10px;">Рефералов <?=$i; ?> ур.:</td>
		<td width="200" align="center"><?=$users_info["count_ref".$i]; ?> чел.</td>
	</tr>
	
	<tr>
		<td  style="padding-left:10px;">Заработал на рефералах <?=$i; ?> ур.:</td>
		<td width="200" align="center">

		  <?=sprintf("%.2f",$users_info["from_referals".$i]); ?> руб.

		</td>
	</tr>

	<tr>
		<td  style="padding-left:10px;">Принес рефереру <?=$i; ?> ур.:</td>
		<td width="200" align="center">

		  <?=sprintf("%.2f",$users_info["to_referer".$i]); ?> руб.

		</td>
	</tr>
<?php endfor; ?>
  
  <tr >
		<td  style="padding-left:10px;"></td>
		<td style="padding-left:10px;"> </td>
	</tr>
  
 
  <tr bgcolor="#efefef">
    <td style="padding-left:10px;">Забанен (<?=($users_info["banned"] > 0) ? '<font color = "red"><b>ДА</b></font>' : '<font color = "green"><b>НЕТ</b></font>'; ?>):</td>
    <td width="200" align="center">
	<form action="" method="post">
	 <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
		<input type="hidden" name="banned" value="<?=($users_info["banned"] > 0) ? 0 : 1 ;?>" />
	<input type="submit" value="<?=($users_info["banned"] > 0) ? 'Разбанить' : 'Забанить'; ?>" />
	</form>
	</td>
  </tr>
  
  <tr bgcolor="#efefef">
		<td style="padding-left:10px;">Сбросить пин код:</td>
		<td width="200" align="center">
			<form action="" method="post">
				<input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
				<input type="submit" name="reset_pass" value="Сбросить" />
			</form>
		</td>
	</tr>
  <tr bgcolor="#efefef">
		<td  style="padding-left:10px;">Сбросить кошельки:</td>
		<td width="200" align="center">
			<form action="" method="post">
				<input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
				<input type="submit" name="reset_purse" value="Сбросить" />
			</form>
		</td>
	</tr>
</table>
<BR />




<form action="" method="post">
<input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
<table width="100%" border="0">
  <tr bgcolor="#EFEFEF">
    <td align="center" colspan="4"><b>Операции с балансом:</b></td>
  </tr>
  <tr>
    <td align="center">
		<select name="balance_set">
			<option value="2">Добавить на баланс</option>
			<option value="1">Снять с баланса</option>
		</select>
	</td>
	<td align="center">
		<select name="balance_val">
			<option value="money_b">для покупок</option>
				<option value="money_p">для вывода</option>
				<option value="money_r">для рекламы</option>
		</select>
	</td>
    <td align="center"><input type="text" name="sum" value="100" size="7"/></td>
    <td align="center"><input type="submit" value="Выполнить" /></td>
  </tr>
</table>
</form><BR /><BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>