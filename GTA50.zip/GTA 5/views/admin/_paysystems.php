<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Настройки платёжек</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
        
        
<?=(isset($errors)) ? $errors : ''; ?>
<?php foreach ($paysystems as $row) : ?>

<form action="" method="post">
<input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
<input type="hidden" name="name" value="<?=$row["name"]; ?>">
<table class="table table-bordered table-striped" >

 <tr class="htt">
    <td colspan="2" align="center">-------------------<?=strtoupper($row['fullname']); ?>:-------------------<br></td>
  </tr>

  <tr class="htt">
    <td>Доступность</td>
    <td>
      <select name="active" id="">
        <option value="0" <?php if ($row["active"] == 0) echo "selected"; ?>>Отключена</option>
        <option value="1" <?php if ($row["active"] == 1) echo "selected"; ?>>Включена</option>
      </select>
    </td>
  </tr>

  <tr class="htt">
    <td>Пополнение</td>
    <td width="300" >
      <select name="active_insert" id="">
        <option value="0" <?php if ($row["active_insert"] == 0) echo "selected"; ?>>Отключена</option>

      <?php if ($row['name'] != 'pyb' && $row['name'] != 'pymt' && $row['name'] != 'pymf' && $row['name'] != 'pyt' && $row['name'] != 'pokp') : ?>

        <option value="1" <?php if ($row["active_insert"] == 1) echo "selected"; ?>>Включена</option>

      <?php endif; ?>

      </select>
    </td>
  </tr>

  <tr class="htt">
    <td>Вывод</td>
    <td width="300" >
      <select name="active_payment" id="">
        <option value="0" <?php if ($row["active_payment"] == 0) echo "selected"; ?>>Отключена</option>

      <?php if ($row['name'] != 'fk') : ?>

        <option value="1" <?php if ($row["active_payment"] == 1) echo "selected"; ?>>Авто</option>
        <option value="2" <?php if ($row["active_payment"] == 2) echo "selected"; ?>>Ручные</option>

      <?php endif; ?>
      
      </select>
    </td>
  </tr>

  <tr class="htt">
    <td>Комиссия</td>
    <td>
      <input type="text" name="comis" value="<?=$row['comis']; ?>">
    </td>
  </tr>

  <tr class="htt">
    <td>Мин. вывод</td>
    <td>
      <input type="text" name="min_pay" value="<?=$row['min_pay']; ?>">
    </td>
  </tr>

  <tr class="htt">
    <td>Макс. вывод</td>
    <td>
      <input type="text" name="max_pay" value="<?=$row['max_pay']; ?>">
    </td>
  </tr>

  <tr> <td colspan="2" align="center"><input type="submit" name="yes" value="Сохранить" /></td> </tr>
  
</table>
</form>

<?php endforeach; ?>
<BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>