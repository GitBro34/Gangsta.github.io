<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Гонка лидеров</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
<?=(isset($errors)) ? $errors : ''; ?>

<table class="table table-bordered table-striped" >

<?php foreach ($leads as $lead) : ?>

<form action="" method="post">
  <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
  <input type="hidden" name="id" value="<?=$lead['id']; ?>">

  <tr>
    <td colspan="2" align="center">-------------------Гонка <?=$lead['term']; ?> дней (день)------------------- <br></td>
  </tr> 

  <tr>
    <td>Длительность:</td>
    <td width="150" align="center"><input type="text" name="term" value="<?=$lead['term']; ?>" /></td>
  </tr>

  <tr>
    <td>Награда за 1-ое место (%):</td>
    <td width="150" align="center"><input type="text" name="1m" value="<?=$lead['1m']; ?>" /></td>
  </tr>

  <tr>
    <td>Награда за 2-ое место (%):</td>
    <td width="150" align="center"><input type="text" name="2m" value="<?=$lead['2m']; ?>" /></td>
  </tr>

  <tr>
    <td>Награда за 3-ое место (%):</td>
    <td width="150" align="center"><input type="text" name="3m" value="<?=$lead['3m']; ?>" /></td>
  </tr>

  <tr>
    <td>Награда за 4-ое место (%):</td>
    <td width="150" align="center"><input type="text" name="4m" value="<?=$lead['4m']; ?>" /></td>
  </tr>

  <tr>
    <td>Награда за 5-ое место (%):</td>
    <td width="150" align="center"><input type="text" name="5m" value="<?=$lead['5m']; ?>" /></td>
  </tr>

  <tr>
    <td>Дата окончания (UNIX):</td>
    <td width="150" align="center"><input type="text" name="next_date" value="<?=$lead['next_date']; ?>" /></td>
  </tr>

  <tr> 
    <td colspan="2" align="center"><input name="yes" type="submit" value="Сохранить" /></td> 
  </tr>
</form>

<?php endforeach; ?>

</table>

<BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>