<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">История покупок</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
      <center><a href="/admin/deposits">Список покупок</a> | <a href="/admin/deposits/days">По дням</a></center><BR />
        
<?php if(count($deposits) > 0) : ?>

<table class="table table-bordered table-striped" >
   <tr>
			<td align="center" width="50" class="m-tb">ID</td>
			<td align="center" width="150" class="m-tb">Пользователь</td>
			<td align="center" width="75" class="m-tb">Имя</td>
			<td align="center" width="150" class="m-tb">Дата операции</td>
		</tr>
		
			<?php foreach($deposits as $row) : ?>

		
		<tr class="htt">
		    <td align="center" width="50"><?=$row["id"]; ?></td>
		    <td align="center"><a href="/admin/users/edit/<?=$row["user_id"]; ?>" class="stn"><?=$row["user"]; ?></a></td>
		    <td align="center" width="75"><?=$row["name"]; ?></td>
			<td align="center" width="150"><?=date("d.m.Y в H:i:s",$row["date_add"]); ?></td>
	  	</tr>

	<?php endforeach; ?>



</table>
<?php else : ?>

	<center><b>Записей нет</b></center>

<?php endif; ?>

<?php echo $navigation; ?>
<BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>