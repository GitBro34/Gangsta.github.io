<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">История выплат</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
       <center><a href="/admin/payments">Список выплат</a> | <a href="/admin/payments/days">По дням</a></center><BR />

	<?php if(count($days_money) > 0) : ?>
<table class="table table-bordered table-striped" >
   <tr >
			<td align="center" class="m-tb">Дата</td>
			<td align="center" class="m-tb">Выплат</td>
			<td align="center" class="m-tb">На сумму</td>
		  </tr>
		
				<?php foreach($days_money as $date => $sum) : ?>

				<tr class="htt">
					<td align="center"><?=$date; ?></td>
					<td align="center"><?=$days_payment[$date]; ?> шт.</td>
					<td align="center"><?=$sum; ?> руб.</td>
				</tr>

			<?php endforeach; ?>



</table>
	<?php else : ?>

		<center><b>Записей нет</b></center><BR />

	<?php endif; ?>
<BR />
</div>
    </div>
<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>