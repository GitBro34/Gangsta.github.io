<?php
if(isset($_SESSION["user_id"]) OR isset($_SESSION["admin"])) :

	if(isset($_SESSION["admin"])) : ?>

<div class="leftbbmenu mainusermenu">	
	<h5>Админка</h5>
	<hr>
	<div class="field-gr"><a href="/">Главная сайта</a></div>

	<?php if(isset($_SESSION['user'])) : ?>

    <div class="field-gr"><a href="/cabinet">Кабинет</a></div>

    <?php endif; ?>
    
	<hr>
	<div class="field-gr"><a href="/admin/handlepayments">Заявки на выплаты(<?=$this->newpayments; ?>)</a></div>
	<div class="field-gr"><a href="/admin/feedback/new">Отзывы(<?=$this->newfeedbacks; ?>)</a></div>
	<div class="field-gr"><a href="/admin/serfing/new">Серфинг(<?=$this->newserfings; ?>)</a></div>
	<hr>
	<div class="field-gr"><a href="/admin/stats">Статистика</a></div>
	<div class="field-gr"><a href="/admin/inserts">История пополнений</a></div>
	<div class="field-gr"><a href="/admin/payments">История выплат</a></div>
	<div class="field-gr"><a href="/admin/deposits">История покупок</a></div>
	<hr>
	<div class="field-gr"><a href="/admin/competition/invest">Конкурсы</a></div>
	<div class="field-gr"><a href="/admin/leaders">Гонка лидеров</a></div>
	<hr>
	<div class="field-gr"><a href="/admin/settings">Общие настройки</a></div>
	<div class="field-gr"><a href="/admin/plans">Настройки планов</a></div>
	<div class="field-gr"><a href="/admin/paysystems">Настройки платёжек</a></div>
	<div class="field-gr"><a href="/admin/serfingplans">Настройки планов серфинга</a></div>
	<hr>
	<div class="field-gr"><a href="/admin/users">Список пользователей</a></div>
    <hr>
	<div class="field-gr"><a href="/exit">Выход из профиля</a></div>
</div>

<?php
	endif;
endif;
?>