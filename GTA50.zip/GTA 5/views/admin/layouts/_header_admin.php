
<!doctype html>
<html lang="en"><head>
   
    <title>Admin Panel</title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="/assets/styles/bootstrap\css\bootstrap.css">
    <link rel="stylesheet" href="/assets/styles/font-awesome\css\font-awesome.css">

    <script src="/assets/styles/jquery-1.11.1.min.js" type="95d53fb7e5a60e0ad47fbdc6-text/javascript"></script>

    

    <link rel="stylesheet" type="text/css" href="/assets/styles/theme.css">
    <link rel="stylesheet" type="text/css" href="/assets/styles/premium.css">

</head>