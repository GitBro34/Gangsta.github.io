<?php
if(isset($_SESSION["user_id"]) OR isset($_SESSION["admin"])) :

	if(isset($_SESSION["admin"])) : ?>
<!doctype html>
<html lang="en"><head>
   
    <title>Admin Panel</title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="/assets/styles/bootstrap\css\bootstrap.css">
    <link rel="stylesheet" href="/assets/styles/font-awesome\css\font-awesome.css">

    <script src="/assets/styles/jquery-1.11.1.min.js" type="95d53fb7e5a60e0ad47fbdc6-text/javascript"></script>

    

    <link rel="stylesheet" type="text/css" href="/assets/styles/theme.css">
    <link rel="stylesheet" type="text/css" href="/assets/styles/premium.css">

</head>
  <div class="navbar navbar-default" role="navigation">
        <div class="navbar-header">
        
          <a class="" href="index.html"><span class="navbar-brand"><span class="fa fa-paper-plane"></span> Панель администратора</span></a></div>

        <div class="navbar-collapse collapse" style="height: 1px;">
          <ul id="main-menu" class="nav navbar-nav navbar-right">
            <li class="dropdown hidden-xs">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <span class="glyphicon glyphicon-user padding-right-small" style="position:relative;top: 3px;"></span> Привет, Admin
                    
                </a>

              <ul class="dropdown-menu">
                <li class="divider"></li>
                <li><a tabindex="-1" href="index.php?menu=exit">Выход</a></li>
              </ul>
            </li>
          </ul>

        </div>
      </div>
 <div class="sidebar-nav">
    <ul>
    <li><a href="#" data-target=".dashboard-menu" class="nav-header" data-toggle="collapse"><i class="fa fa-fw fa-dashboard"></i> Статистика проекта</a></li>
    <li><ul class="dashboard-menu nav nav-list collapse in">
            <li><a href="/admin/stats"><span class="fa fa-caret-right"></span> Статистика общая</a></li>
            <li ><a href="/admin/inserts"><span class="fa fa-caret-right"></span> История пополнений</a></li>
            <li ><a href="/admin/payments"><span class="fa fa-caret-right"></span> История выплат</a></li>
            <li ><a href="/admin/deposits"><span class="fa fa-caret-right"></span> История покупок</a></li>
			
			
    </ul>
<ul>
    
     <li><a href="#" data-target=".dashboard-menu" class="nav-header" data-toggle="collapse"><i class="fa fa-fw fa-fighter-jet"></i> Обработка</a></li>
    <li><ul class="dashboard-menu nav nav-list collapse in">
           <li ><a href="/admin/handlepayments"><span class="fa fa-caret-right"></span> Заявки на выплаты (<?=$this->newpayments; ?>)</a></li>
            <li ><a href="/admin/feedback/new"><span class="fa fa-caret-right"></span> Отзывы (<?=$this->newfeedbacks; ?>)</a></li>
            <li ><a href="/admin/serfing/new"><span class="fa fa-caret-right"></span> Серфинг (<?=$this->newserfings; ?>)</a></li>
			
    </ul>
    <li><a href="#" data-target=".dashboard-menu" class="nav-header" data-toggle="collapse"><i class="fa fa-fw fa-fighter-jet"></i> Настройки</a></li>
    <li><ul class="dashboard-menu nav nav-list collapse in">
            <li><a href="/admin/settings"><span class="fa fa-caret-right"></span> Общие настройки</a></li>
            <li ><a href="/admin/plans"><span class="fa fa-caret-right"></span> Настройки планов</a></li>
            <li ><a href="/admin/paysystems"><span class="fa fa-caret-right"></span> Настройки платёжек</a></li>
            <li ><a href="/admin/serfingplans"><span class="fa fa-caret-right"></span> Настройки планов серфинга</a></li>
            <li ><a href="/admin/competition/invest"><span class="fa fa-caret-right"></span> Конкурсы</a></li>
            <li ><a href="/admin/leaders"><span class="fa fa-caret-right"></span> Гонка лидеров</a></li>
			<li ><a href="/admin/users"><span class="fa fa-caret-right"></span> Список пользователей</a></li>
		
    </ul>
    

    </div>
    
    <?php
	endif;
endif;
?>
<body class=" theme-blue">

    <!-- Demo page code -->

    <script type="3e3eeacc878640473bec2f3f-text/javascript">
        $(function() {
            var match = document.cookie.match(new RegExp('color=([^;]+)'));
            if(match) var color = match[1];
            if(color) {
                $('body').removeClass(function (index, css) {
                    return (css.match (/\btheme-\S+/g) || []).join(' ')
                })
                $('body').addClass('theme-' + color);
            }

            $('[data-popover="true"]').popover({html: true});
            
        });
    </script>
    <style type="text/css">
        #line-chart {
            height:300px;
            width:800px;
            margin: 0px auto;
            margin-top: 1em;
        }
        .navbar-default .navbar-brand, .navbar-default .navbar-brand:hover { 
            color: #fff;
        }
    </style>

    <script type="3e3eeacc878640473bec2f3f-text/javascript">
        $(function() {
            var uls = $('.sidebar-nav > ul > *').clone();
            uls.addClass('visible-xs');
            $('#main-menu').append(uls.clone());
        });
    </script>


     
	  
	 
	  
	  
	  
	  
	  
	  
	 
	
	
	
	
	      <script src="lib/jQuery-Knob/js/jquery.knob.js" type="3e3eeacc878640473bec2f3f-text/javascript"></script>
    <script type="3e3eeacc878640473bec2f3f-text/javascript">
        $(function() {
            $(".knob").knob();
        });
    </script>


    <link rel="stylesheet" type="text/css" href="stylesheets/theme.css">
    <link rel="stylesheet" type="text/css" href="stylesheets/premium.css">