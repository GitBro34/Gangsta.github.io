	<script src="lib/bootstrap/js/bootstrap.js" type="3e3eeacc878640473bec2f3f-text/javascript"></script>
    <script type="3e3eeacc878640473bec2f3f-text/javascript">
        $("[rel=tooltip]").tooltip();
        $(function() {
            $('.demo-cancel-click').click(function(){return false;});
        });
    </script>
    
  
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="3e3eeacc878640473bec2f3f-|49" defer=""></script>
</body>
</html>