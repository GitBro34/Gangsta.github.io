<?php require_once(ROOT . "/views/admin/layouts/_header_cab.php"); ?>
<div class="content">
        <div class="header">
      

            <h1 class="page-title">Пользователи</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center><br>
<form action="/admin/users/search" method="post">
<table width="250" border="0" align="center">
  <tr>
    <td><b>Логин:</b>&nbsp;</td>
    <td><input type="text" name="user" /></td>
	<td><input type="submit" value="Поиск" /></td>
  </tr>
</table>
</form>
<BR />
<?php if($users_info != false) : ?>

<table class="table table-bordered table-striped" >
  <tr bgcolor="#efefef">
    <td align="center" width="35" class="m-tb"><a  class="stn-sort">ID</a></td>
    <td align="center" width="120"><a class="stn-sort">Логин</a></td>
    <td align="center" width="45" class="m-tb"><a  class="stn-sort">Скорость</a></td>
	<td align="center" width="45" class="m-tb"><a  class="stn-sort">На покупки</a></td>
	<td align="center" width="45" class="m-tb"><a  class="stn-sort">На выплаты</a></td>
	<td align="center" width="45" class="m-tb"><a  class="stn-sort">На рекламу</a></td>
	<td align="center" width="50" class="m-tb"><a  class="stn-sort">Зарегистрирован</a></td>
		<td align="center" width="100" class="m-tb"><a  class="stn-sort">Пос. активность</a></td>
  </tr>
<?php foreach($users_info as $row) : ?>

	<tr class="htt">
    <td align="center"><?=$row["id"]; ?></td>
    <td align="center"><a href="/admin/users/edit/<?=$row["id"]; ?>" class="stn"><?=$row["user"]; ?></a></td>
    <td align="center"><?=sprintf("%.4f", $row["speed"]); ?> р.</td>
	<td align="center"><?=sprintf("%.2f",$row["money_b"]); ?> р.</td>
	<td align="center"><?=sprintf("%.2f",$row["money_p"]); ?> р.</td>
	<td align="center"><?=sprintf("%.2f",$row["money_r"]); ?> р.</td>
	<td align="center"><?=date("d.m.Y в H:i",$row["date_reg"]); ?></td>
	<td align="center"><?=date("d.m.Y в H:i",$row["lastupdate"]); ?></td>
  	</tr>

		<?php endforeach; ?>

</table>
<BR />
<?PHP else : ?>

	<center><b>На данной странице нет записей</b></center><BR />

<?php endif; ?>

<?=$navigation; ?>
</div>
    </div>
    
   


<?php require_once(ROOT . "/views/admin/layouts/_footer_admin.php"); ?>