<!--
########################
# https://www.youtube.com/channel/UCKVJ80CNo6Il92UFBGegdeA #
# https://vk.com/id582975124 #
# https://sandybiscript.ml/ #
########################
-->

<!DOCTYPE html><html >
    <head>
    <meta charset="UTF-8"><title><?=$_title; ?> | <?=NAME; ?></title>
        <meta name="viewport" content="width=1300">
    <link rel="shortcut icon" href="/assets/gan/favicon.ico">
     <link href="/assets/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/assets/gan/css/main.css?v=1.12">
    <link rel="stylesheet" type="text/css" href="/assets/gan/css/bootstrap.min.css">
    <link href="/assets/gan/css/owl.carousel.min.css" rel="stylesheet">
    <link href="/assets/gan/css/owl.theme.default.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/assets/gan/css/cabinet.css?v=1.12">
<script type="text/javascript" src="/assets/gan/static/front/js/jquery-1.11.1.js">
</script><script type="text/javascript" src="/assets/gan/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
    </head>

<body id="message/support">
    <div class="loaderArea" hidden><div class="loader"><img src="/assets/gan/images/barab.png"></div></div><div class="main_wr"><div class="row">
    
    
    <header class="header">
        <div class="top_nav"
        ><div class="container">
            
	
</div></div>

<nav class="main_nav">
<nav class="main_nav" style="margin-left: 300px;">
<div class="container">
<a href="/" class="logo left" ><img style="margin-left: -220px;margin-top: 27px;" src="/assets/gan/images/logo.png" alt="Logo"></a>
<ul style="width: 1000px;" class="main_ul right" id="maf_home_ul_a">
<li><a href="/">ГЛАВНАЯ</a></li>
<li><a href="/stats">СТАТИСТИКА</a></li>
<li><a href="/competitions">КОНКУРСЫ</a></li>
<li><a href="/feedback">ОТЗЫВЫ</a></li>
<li><a href="/contacts">КОНТАКТЫ</a></li>
<li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
<?php if (!$this->usid) : ?>
<li1><a href="/signup">РЕГИСТРАЦИЯ</a></li1>&nbsp;&nbsp;&nbsp;
<li1><a href="/login" >АВТОРИЗАЦИЯ</a></li1>
<?php else : ?>
<li1><a href="/cabinet">&nbsp;&nbsp;&nbsp;&nbsp;КАБИНЕТ&nbsp;&nbsp;&nbsp;&nbsp;</a></li1>&nbsp;&nbsp;&nbsp;
<li1><a href="/exit" >&nbsp;&nbsp;&nbsp;&nbsp;ВЫХОД&nbsp;&nbsp;&nbsp;&nbsp;</a></li1>
<?php endif; ?>


 
</ul></div></nav>
<ul class="lang clearfix" style="margin-left: 145px;margin-top: -111px;">
<li style="" onclick="doGTranslate('ru|ru');return false;" title="Русский"><img src="/assets/gan/images/ru.svg" align="left" style="cursor: pointer;margin-right:3px;margin-left: 10px;width: 30px;border-radius: 100%;-webkit-box-shadow: 0px 4px 8px -5px rgba(0,0,0,0.55);-moz-box-shadow: 0px 4px 8px -5px rgba(0,0,0,0.55);box-shadow: 0px 4px 8px -5px rgba(0,0,0,0.55);"></li>
<li style="cursor: pointer;margin-left:45px;" onclick="doGTranslate('ru|en');return false;" title="Английский"><img src="/assets/gan/images/en.svg" align="left" style="cursor: pointer;margin-right:3px;margin-left: 10px;width: 30px;border-radius: 0%;-webkit-box-shadow: 0px 4px 8px -5px rgba(0,0,0,0.55);-moz-box-shadow: 0px 4px 8px -5px rgba(0,0,0,0.55);box-shadow: 0px 4px 8px -5px rgba(0,0,0,0.55);"></li>


</ul>
<style type="text/css">
<!---
a.gflag {vertical-align:middle;font-size:16px;padding:1px 0;background-repeat:no-repeat;background-image:url(//gtranslate.net/flags/16.png);}
a.gflag img {border:0;}
a.gflag:hover {background-image:url(//gtranslate.net/flags/16a.png);}
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
-->
</style>
<div id="google_translate_element2"><div class="skiptranslate goog-te-gadget" dir="ltr" style=""><div id=":0.targetLanguage"><select class="goog-te-combo"><option value="ru">русский</option><option value="az">азербайджанский</option><option value="sq">албанский</option><option value="am">амхарский</option><option value="en">английский</option><option value="ar">арабский</option><option value="hy">армянский</option><option value="af">африкаанс</option><option value="eu">баскский</option><option value="be">белорусский</option><option value="bn">бенгальский</option><option value="my">бирманский</option><option value="bg">болгарский</option><option value="bs">боснийский</option><option value="cy">валлийский</option><option value="hu">венгерский</option><option value="vi">вьетнамский</option><option value="haw">гавайский</option><option value="gl">галисийский</option><option value="el">греческий</option><option value="ka">грузинский</option><option value="gu">гуджарати</option><option value="da">датский</option><option value="zu">зулу</option><option value="iw">иврит</option><option value="ig">игбо</option><option value="yi">идиш</option><option value="id">индонезийский</option><option value="ga">ирландский</option><option value="is">исландский</option><option value="es">испанский</option><option value="it">итальянский</option><option value="yo">йоруба</option><option value="kk">казахский</option><option value="kn">каннада</option><option value="ca">каталанский</option><option value="ky">киргизский</option><option value="zh-TW">китайский (традиционный)</option><option value="zh-CN">китайский (упрощенный)</option><option value="ko">корейский</option><option value="co">корсиканский</option><option value="ht">креольский (Гаити)</option><option value="ku">курманджи</option><option value="km">кхмерский</option><option value="xh">кхоса</option><option value="lo">лаосский</option><option value="la">латинский</option><option value="lv">латышский</option><option value="lt">литовский</option><option value="lb">люксембургский</option><option value="mk">македонский</option><option value="mg">малагасийский</option><option value="ms">малайский</option><option value="ml">малаялам</option><option value="mt">мальтийский</option><option value="mi">маори</option><option value="mr">маратхи</option><option value="mn">монгольский</option><option value="de">немецкий</option><option value="ne">непальский</option><option value="nl">нидерландский</option><option value="no">норвежский</option><option value="pa">панджаби</option><option value="fa">персидский</option><option value="pl">польский</option><option value="pt">португальский</option><option value="ps">пушту</option><option value="ro">румынский</option><option value="sm">самоанский</option><option value="ceb">себуанский</option><option value="sr">сербский</option><option value="st">сесото</option><option value="si">сингальский</option><option value="sd">синдхи</option><option value="sk">словацкий</option><option value="sl">словенский</option><option value="so">сомалийский</option><option value="sw">суахили</option><option value="su">суданский</option><option value="tg">таджикский</option><option value="th">тайский</option><option value="ta">тамильский</option><option value="te">телугу</option><option value="tr">турецкий</option><option value="uz">узбекский</option><option value="uk">украинский</option><option value="ur">урду</option><option value="tl">филиппинский</option><option value="fi">финский</option><option value="fr">французский</option><option value="fy">фризский</option><option value="ha">хауса</option><option value="hi">хинди</option><option value="hmn">хмонг</option><option value="hr">хорватский</option><option value="ny">чева</option><option value="cs">чешский</option><option value="sv">шведский</option><option value="sn">шона</option><option value="gd">шотландский (гэльский)</option><option value="eo">эсперанто</option><option value="et">эстонский</option><option value="jw">яванский</option><option value="ja">японский</option></select></div>Технологии <span style="white-space:nowrap"><a class="goog-logo-link" href="https://translate.google.com" target="_blank"><img src="https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png" width="37px" height="14px" style="padding-right: 3px" alt="Google Переводчик">Переводчик</a></span></div></div></div>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'ru',autoDisplay: false}, 'google_translate_element2');}
</script><script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>
<script type="text/javascript">
/* <![CDATA[ */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',43,43,'||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'.split('|'),0,{}))
/* ]]> */
</script>
</header>

<div class="row"><div class="container"><article class="maf_cab_wr"><div>

 

  <!-- Tab panes -->
  <div class="tab-content">
    

    <div role="tabpanel" class="tab-pane active fade in" id="usd">
		<div class="maf_main_stat_top">
			<div>
				<span><i style="margin-top: 40px;" class="glyphicon glyphicon-arrow-up"></i></span>
				<p style="margin-left: 75px;margin-top: 5px;">БАЛАНС НА ПОКУПКИ</p>
				<p style="margin-left: 70px;" class="maf_p_up"><i class="counter"><?=sprintf("%.2f", $this->user_data['money_b']); ?></i> <b style="font-size: 15px;">RUB</b></p><hr style="margin-left: 70px;margin-top: 10px;width: 150px;"><br>
								<p style="margin-left: 32px;margin-top: -10px;width: 210px;"><a href="/insert" style="font-size: 13px;font-weight: 900; text-decoration:none;color:#ccc;"><i class="fa fa-plus" aria-hidden="true"></i> &nbsp;ПОПОЛНИТЬ БАЛАНС (&nbsp;+<?=$this->config['insert_b_bonus']; ?>%&nbsp;)</a></p>

			</div>
			<div>
				<span><i style="margin-top: 40px;" class="glyphicon glyphicon-arrow-down"></i></span>
				<p style="margin-left: 75px;margin-top: 5px;">БАЛАНС НА ВЫВОД</p>
				<p style="margin-left: 70px;" class="maf_p_up"><i class="counter"><?=sprintf("%.2f", $this->user_data['money_p']); ?></i> <b style="font-size: 15px;">RUB</b></p><hr style="margin-left: 70px;margin-top: 10px;width: 150px;"><br>
								<p style="margin-left: 28px;margin-top: -10px;width: 210px;"><a href="/payment" style="font-size: 13px;font-weight: 900; text-decoration:none;color:#ccc;"><i class="fa fa-minus" aria-hidden="true"></i> &nbsp;ЗАКАЗАТЬ ВЫПЛАТУ</a></p>
			</div>
			<div>
				<span><i style="margin-top: 40px;" class="glyphicon glyphicon-share-alt"></i></span>
				<p style="margin-left: 75px;margin-top: 5px;">БАЛАНС НА РЕКЛАМУ</p>
				<p style="margin-left: 70px;" class="maf_p_up"><i class="counter"><?=sprintf("%.2f", $this->user_data['money_r']); ?></i> <b style="font-size: 15px;">RUB</b></p><hr style="margin-left: 70px;margin-top: 10px;width: 150px;"><br>
								<p style="margin-left: 32px;margin-top: -10px;width: 210px;"><a href="/insertserfing" style="font-size: 13px;font-weight: 900; text-decoration:none;color:#ccc;"><i class="fa fa-plus" aria-hidden="true"></i> &nbsp;ПОПОЛНИТЬ БАЛАНС (&nbsp;+<?=$this->config['insert_r_bonus']; ?>%&nbsp;)</a></p>
			</div>
			<div>
				<span><i style="margin-top: 40px;" class="glyphicon glyphicon-fire"></i></span>
				<p style="margin-left: 75px;margin-top: 5px;">СКОРОСТЬ ЗАРОБОТКА</p>
				<p style="margin-left: 70px;" class="maf_p_up"><i class="counter"><?=sprintf("%.4f", $this->user_data['speed']); ?></i> <b style="font-size: 15px;">RUB / ЧАС</b></p><hr style="margin-left: 70px;margin-top: 10px;width: 150px;"><br>
								<p style="margin-left: 30px;margin-top: -10px;width: 210px;"><a href="/exchange" style="font-size: 13px;font-weight: 900; text-decoration:none;color:#ccc;"><i class="fa fa-recycle" aria-hidden="true"></i> &nbsp;ОБМЕН БАЛАНСА</a></p>
			</div>
		</div>
    </div>
  </div>

</div>










<aside class="maf_cab_asid left">
	
		<ul id="maf_ul_a">
		<li><a href="/cabinet" style="font-weight: 900;"><i class="fa fa-home" aria-hidden="true"></i> МОЙ КАБИНЕТ</a></li>
		<li><a href="/leaders" style="font-weight: 900;"><i class="fa fa-fire" aria-hidden="true"></i> ГОНКА ЛИДЕРОВ</a></li>
        <li><a href="/shop" style="font-weight: 900;"><i class="fa fa-shopping-basket" aria-hidden="true"></i> КУПИТЬ ПЕРСОНАЖА</a></li>
        <li><a href="/hero" style="font-weight: 900;"><i class="fa fa-bolt" aria-hidden="true"></i> ВАШИ ПЕРСОНАЖИ  ( <?=$this->counters['deposits']; ?> )</a></li>
		<hr>
		<li><a href="/bonus" style="font-weight: 900;"><i class="fa fa-gift" aria-hidden="true"></i> ЕЖЕДНЕВНЫЙ БОНУС</a></li>
		<li><a href="/quests" style="font-weight: 900;"><i class="fa fa-credit-card" aria-hidden="true"></i> ОПЛАЧИВАЕМЫЕ КВЕСТЫ</a></li>
		<li><a href="/questsins" style="font-weight: 900;"><i class="fa fa-credit-card" aria-hidden="true"></i> БОНУСЫ ЗА ПОПОЛНЕНИЕ</a></li>
		<li><a href="/serfing" style="font-weight: 900;"><i class="fa fa-link" aria-hidden="true"></i>  СЕРФИНГ САЙТОВ ( <?=$this->counters['allserf']; ?> )</a></li>
	
				<hr>
					
		<li><a href="/partnership" style="font-weight: 900;"><i class="fa fa-list-alt" aria-hidden="true"></i>  ПАРТНЕРСКАЯ ПРОГРАММА</a></li>
		<li><a href="/referals" style="font-weight: 900;"><i class="fa fa-users" aria-hidden="true"></i>  ВАШИ РЕФЕРАЛЫ ( <?=$this->counters['referals']; ?> )</a></li>
		<li><a href="/settings" style="font-weight: 900;"><i class="fa fa-cog" aria-hidden="true"></i>  НАСТРОЙКИ АККАУНТА</a></li>
		
		
	</ul>
</aside>