<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_c.php"); ?>
<div class="maf_main_stat_wr left">
	<div class="maf_main_stat maf_main_stat2 maf_main_stat_plan left">

				
				

			<h3 class="main_stat_title" style="margin-top: -5px;font-size:22px;text-transform: uppercase;"><?=$_title; ?></h3><br>
			<div class="row">
			    
		
				
		
				
				
	
				
				






<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Пополнить баланс на 10 рублей</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['ins_quest_bonus']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Пополните баланс на 10 рублей и получите вознаграждение на развитие вашей банды !
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="ins_quest" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>
				


<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Пополнить баланс на 50 рублей</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['ins_quest_bonus2']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Пополните баланс на 50 рублей и получите вознаграждение на развитие вашей банды !
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="ins_quest2" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>
				
				
				<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Пополнить баланс на 100 рублей</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['ins_quest_bonus3']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Пополните баланс на 100 рублей и получите вознаграждение на развитие вашей банды !
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="ins_quest3" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>
				
				
				<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Пополнить баланс на 500 рублей</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['ins_quest_bonus4']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Пополните баланс на 500 рублей и получите вознаграждение на развитие вашей банды !
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="ins_quest4" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>
				
				
				
				<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Пополнить баланс на 1000 рублей</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['ins_quest_bonus5']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Пополните баланс на 1000 рублей и получите вознаграждение на развитие вашей банды !
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="ins_quest5" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>
				
				
				
				<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Пополнить баланс на 5000 рублей</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['ins_quest_bonus6']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Пополните баланс на 5000 рублей и получите вознаграждение на развитие вашей банды !
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="ins_quest6" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>
				
				
				
				<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Пополнить баланс на 10000 рублей</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['ins_quest_bonus7']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Пополните баланс на 10000 рублей и получите вознаграждение на развитие вашей банды !
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="ins_quest7" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>
				
				
				
				
				



			</div>


 

	

	</div>
</div></div>

</article></div></div>
<script src="/assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>