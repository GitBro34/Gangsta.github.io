<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_c.php"); ?>
 <div class="cp-content">
         <a style="width: 850px;margin-top: 10px; margin-left: 20px;" class="start_button77"  >
                <img style="width: 850px;height: 70px  " class="bg" src="/assets/frontend/web/images/bg/b3.png" alt="">
                <span><b class="grad99" style=" margin-left: 25px;margin-top: 10px;font-size:34px;text-transform: uppercase;"><?=$_title; ?></b></span>
            </a>
     
<div class="bg03" style="width: 1150px; margin-left: 60px;margin-top: -185px;">
    <div class="container">
        <div class="ourstat">
            <div class="head_content1">
            <div class="info1">
            </div>
        </div>  

   
            <div class="row" style=" margin-left: -65px;margin-top:75px;">

                
                
                <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 74%;max-width: 74%;">
                    
                    <div class="plan1">
                        <h4 style=" margin-top: -25px;"><div class="head_content1">
            <div class="info1">
               
                
                     <a style="width: 375px;margin-top: -35px; margin-left: 224px;" class="start_button10"  >
                <img style="width: 375px;height: 50px  " class="bg" src="/assets/frontend/web/images/bg/b3.png" alt="">
                <span><b class="grad4" style="font-size:21px;margin-top: 0px;">ПАРТНЕРСКАЯ ПРОГРАММА</b></span></a>
            </div>
        </div>  </h4>
                       

                        
 <h4 style=" margin-top: -35px;"><div class="head_content1">
            <div class="info1">
                <div class="title1" style="color:#ccc; margin-left: 0px;font-size:14px;height:105px;">
                
                 
                <br>  <b class="ts4" style="color:#ccc;font-size:13px;letter-spacing: 2px;font-family: Gilroy-Black;">
               В партнёрской программе может участвовать любой пользователь проекта. Программа предусматривает ряд вознаграждений за ваших рефералов, а так же рефералов 5 уровня.
                <br><br>
                <font style="color:#ffc923;">25<b style="font-family: arial;">%</b> - 15<b style="font-family: arial;">%</b> - 10<b style="font-family: arial;">%</b> - 5<b style="font-family: arial;">%</b> - 3<b style="font-family: arial;">%</b></font>
      <br><br>
                Ваша реферальная ссылка - <font style="color:#ffc923;"><?=$ref_link; ?></font></b>
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div> 
               
              <div data-aos="fade-up" data-aos-delay="300" class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 74%;max-width: 74%;">
                    
                    <div class="plan1">
                        <h4 style=" margin-top: -25px;"><div class="head_content1">
            <div class="info1">
           
                
                    
                
             
                
                <a style="width: 375px;margin-top: -35px; margin-left: 224px;" class="start_button10"  >
                <img style="width: 375px;height: 50px  " class="bg" src="/assets/frontend/web/images/bg/b3.png" alt="">
                <span><b class="grad4" style="font-size:21px;margin-top: 0px;">РЕКЛАМНЫЕ МАТЕРИАЛЫ</b></span></a>
            </div>
        </div>  </h4>
                       

                        
 <h4 style=" margin-top: -15px;"><div class="head_content1">
            <div class="info1">
                <div class="title1" style=" margin-left: 0px;font-size:14px;">
                
                 
                <br>  
                 <img src="<?=PROTOCOL; ?>://<?=HOST; ?>/assets/banners/MM-468.gif">
                 <br> <br>
               <img src="<?=PROTOCOL; ?>://<?=HOST; ?>/assets/banners/MM-728x90.gif">
                <br> <br>
               <img src="<?=PROTOCOL; ?>://<?=HOST; ?>/assets/banners/MM-200x300.gif">
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div> 

        </div>

    </div>
</div></div>
            
</div></div></div>

<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>