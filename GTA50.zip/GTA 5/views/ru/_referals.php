<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_c.php"); ?>
 <div class="maf_main_stat_wr left">
	<div class="maf_main_stat maf_main_stat2 maf_main_stat_plan left">

				
				
		<form method="post" name="add">
			<input name="Oper" id="add_Oper" value="CASHIN" type="hidden">
			<h3 class="main_stat_title" style="margin-top: -5px;font-size:22px;text-transform: uppercase;"><?=$_title; ?></h3><br>
			<div class="row">

		<a href="/referals/1" style="text-decoration:none;width: 135px;margin-top: -15px;float:left;margin-left: 225px;" class="start_button5"  >
                <img style="width: 135px;height: 35px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:16px;letter-spacing: 1px;">1-й уровень</b></span>
            <img style="width: 135px;height: 35px " class="hover" src="/assets/gan/images/q9.png" alt="">
                </a>
    
            <a href="/referals/2" style="text-decoration:none;width: 135px;margin-top: -15px;float:left;margin-left: 15px;" class="start_button5"  >
                <img style="width: 135px;height: 35px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:16px;letter-spacing: 1px;">2-й уровень</b></span>
            <img style="width: 135px;height: 35px " class="hover" src="/assets/gan/images/q9.png" alt="">
                </a>
             <a href="/referals/3" style="text-decoration:none;width: 135px;margin-top: -15px;float:left;margin-left: 15px;" class="start_button5"  >
                <img style="width: 135px;height: 35px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:16px;letter-spacing: 1px;">3-й уровень</b></span>
            <img style="width: 135px;height: 35px " class="hover" src="/assets/gan/images/q9.png" alt="">
                </a>
             

			</div>


 


			<table class="table1" style="width:100%;margin-bottom:0px;">

          <tr>
            <td class="ts3" style="color:#fff;font-size:15px;width: 33%;text-transform: uppercase;">Логин реферала</td>
            <td class="ts3" style="color:#fff;font-size:15px;width: 33%;text-transform: uppercase;">Доход с реферала</td>
            <td class="ts3" style="color:#fff;font-size:15px;width: 33%;text-transform: uppercase;">Дата регистрации</td>
            
          </tr>
      

     

   <?php if(count($referals) > 0) : ?>

                          <?php foreach($referals as $referal) : ?>

                          <tr role="row">
                            <td style=" color:#cccccc;font-size:13px"><?=$referal['user']; ?></td>
                            <td style=" color:#cccccc;font-size:13px"><?=sprintf("%.2f", $referal["to_referer".$lvl]); ?> руб.</td>
                            <td style=" color:#cccccc;font-size:13px"><?=date("d.m.Y H:i", $referal['date_reg']); ?></td>
                          </tr>

                          <?php endforeach; ?>

                        <?php else : ?>
 <tr role="row">
                            <td colspan="3" style=" color:#cccccc;font-size:13px">У вас нет рефералов <?=$lvl; ?> уровня</td>
                          </tr>

                        <?php endif; ?>

      </table>
		</form>

	</div>
</div>

<script>
	mins={
		USD: [10, 50, 50, 250, 50, 7500],
		BTC: [0.0015, 0.005, 0.005, 0.0115, 0.0115, 0.0115, 0.0115]
	};
	rates={
		USD: 1,
		BTC: 9797.43432928
	}

	$('input[name=PSys]').click(psyschanged=function(){
		curr=$('input[name=PSys]:checked').data('curr');
		plan=$('input[name=Plan]:checked').val();
		$('#plan_sum').val((mins['USD'][plan-1]/rates[curr]).toFixed((curr == 'USD') ? 2 : 6));
	});
	$('input[name=Plan]').click(psyschanged);
	psyschanged();
</script><script type="text/javascript">function showComis(){$('#csum').html('');$('#sum2').html('');$.ajax({type: 'POST',url: 'ajax',data: 'module=balance&do=getsum'+'&oper='+$('#add_Oper').val()+'&cid='+$('#add_PSys').val()+'&sum='+$('#add_Sum').val(),success:function(ex){ex=eval(ex);$('#ccurr').html(ex[0]);$('#csum').html(ex[1]);$('#sum2').html(ex[2]);}});}tid=0;tf=function(){clearTimeout(tid);tid=setTimeout(function(){ showComis(); }, 200);};$('#add_PSys').change(tf);$('#add_Sum').keypress(tf);showComis();</script></article></div></div>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>