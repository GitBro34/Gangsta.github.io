<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_c.php"); ?>
<script src="/assets/scripts/jquery-3.1.0.min.js"></script>
<script src="/assets/js/serfing.js"></script>
<script>

  function goserf(obj) {

    setTimeout(function(){

      obj.parentNode.parentNode.parentNode.parentNode.classList.add('surfblockopen');

      var myReq = new XMLHttpRequest();

      function succFunc (e){
        var tckns = [];
        tckn = myReq.responseText;
        console.log(tckn);
        tckns = document.querySelectorAll('input[name="_tocken"]');
        tckns.forEach(function(item, i, tckns) {
          item.value = tckn;
        });
      }

      myReq.open("POST", "/serfing/gettocken", true);
      myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      myReq.onreadystatechange = succFunc;
      myReq.send();

    }, 200)

  }

</script>
<div class="maf_main_stat_wr left">
	<div class="maf_main_stat maf_main_stat2 maf_main_stat_plan left">

				
				
	
		
			<h3 class="main_stat_title" style="margin-top: -5px;font-size:22px;text-transform: uppercase;"><?=$_title; ?></h3><br>
			<div class="row">
			    
			    
			   <a href="/serfing" style="text-decoration:none;width: 200px;margin-top: -15px;float:left;margin-left: 116px;" class="start_button5"  >
                <img style="width: 200px;height: 35px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:16px;letter-spacing: 1px;">СЕРФИНГ&nbsp;САЙТОВ</b></span>
            <img style="width: 200px;height: 35px " class="hover" src="/assets/gan/images/q9.png" alt="">
                </a>
    
            <a href="/serfing/my" style="text-decoration:none;width: 200px;margin-top: -15px;float:left;margin-left:25px;" class="start_button5"  >
                <img style="width: 200px;height: 35px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:16px;letter-spacing: 1px;">МОИ&nbsp;САЙТ</b></span>
            <img style="width: 200px;height: 35px " class="hover" src="/assets/gan/images/q9.png" alt="">
                </a>
             <a href="/serfing/add" style="text-decoration:none;width: 200px;margin-top: -15px;float:left;margin-left: 25px;" class="start_button5"  >
                <img style="width: 200px;height: 35px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:16px;letter-spacing: 1px;">ДОБАВИТЬ&nbsp;САЙТ</b></span>
            <img style="width: 200px;height: 35px " class="hover" src="/assets/gan/images/q9.png" alt="">
                </a> 
			    
				
		
				
			 <?php if (count($user_links) > 0) : ?>

            <?php foreach ($user_links as $link) : ?>
                
  		<div class="col-lg-6 " style=" margin-bottom:15px; width:100%;">
					<label  class="pay_label">
  
                  
                
                <div  class="col-sm-3" >
                    
                    <div class="plan1"  style=" margin-bottom:15px; height:120px;width:800px;">
                        <h4 style=" margin-top: 0px;"><div class="head_content1">
            <div class="info1">
                
                    
                   <b class="ts3" style="font-size:25px;margin-top: 0px;margin-left: 0px;"><?=$link['title']; ?></b>
            </div>
        </div>  </h4>
                       

                        
 <h4 style=" margin-top: 15px;"><div class="head_content1">
            <div class="info1">
                <div class="" >
                
                
             
      <br>
      
      <table class="table" style="width:100%;margin-bottom:0px;margin-top: -20px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 25%;text-transform: uppercase;">Просмотрено: <?=$link['view']; ?> раз.</td>
                        <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 25%;text-transform: uppercase;">Осталось <?=floor($link['money'] / $link['price']); ?> просмотров</td>

            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 25%;text-transform: uppercase;">Баланс сайта: <?=$link['money']; ?></td>

            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 25%;text-transform: uppercase;">Статус: <?=$statuses[$link['status']]; ?></td>

          </tr>
          
       
      </table></div>
             <form action="" method="POST" class="cp_form" style=" margin-top: -15px;">
                    <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
                    
                    
                     

                    <?php if ($link['status'] == 2): ?>
                     <form style=" margin-left: 0px;" class="inner-form"  >
                      
                      
                      <button type="submit" name="start" value="<?=$link['id']; ?>" class="start_button5" style="width: 150px;height: 45px;margin-top: 20px;margin-left: 0px;">
                    <img style="width: 150px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:14px;letter-spacing: 1px;">ВОЗОБНОВИТЬ</b></span>
            <img style="width: 150px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
                    </button>
</form>
                    <?php elseif ($link['status'] == 1) : ?>
<form style=" margin-left: 0px;" class="inner-form"  >
    
                      
                      
                      
                      <button type="submit" name="stop" value="<?=$link['id']; ?>" class="start_button5" style="width: 150px;height: 45px;margin-top: 20px;margin-left: 0px;">
                    <img style="width: 150px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:14px;letter-spacing: 1px;">ПРИОСТАНОВИТЬ</b></span>
            <img style="width: 150px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
                    </button>
                    
</form>
                    <?php endif ?>
<form action="" method="POST" class="inner-form">
                      <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
                 <div class="form-group field-loginform-username required" style=" margin-top: -68px;margin-left: 175px;height: 45px">
                   <input style="width: 200px;font-family: Gilroy-Black;font-size: 15px;color:#fff;margin-top: 25px;margin-left: 10px;height: 45px" name="sum" type="text" maxlength="9" class="plan_sum" placeholder="Введите сумму... (руб.)" ></div>
                   
                    
                      
                        <button type="submit" name="insert" value="<?=$link['id']; ?>"  class="start_button5" style="width: 180px;height: 45px;margin-top: -62px;margin-left: 420px;">
                    <img style="width: 180px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:14px;letter-spacing: 1px;">ПОПОЛНИТЬ</b></span>
            <img style="width: 180px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
                    </button>
                      
                    </form>
                     
<form style=" margin-top: -65px;margin-left: 650px;"  action="" method="POST">
                     
                      
                      
                       <button type="submit" name="delete" value="<?=$link['id']; ?>"  class="start_button5" style="width: 150px;height: 45px;">
                    <img style="width: 150px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:14px;letter-spacing: 1px;">УДАЛИТЬ САЙТ</b></span>
            <img style="width: 150px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
                    </button>
                      </form>

                  
             
                  
                  
                  
                  
                  
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div> 
               
            
               
               
               
               
               
               
               
               
               
               
               
               
               

            <?php endforeach ?>

          <?php else : ?>

            <div class="col-lg-12">
              <h4 class="text-center surfnoneh4" style="color:#a94442;margin-left: -45px;"><b class="ts4">Вы не добавили ни одного сайта в сёрфинг :(</b></h4>
            </div>

          <?php endif ?>


  <?php if (count($user_links) > 0) : ?>

    <?php foreach ($user_links as $link) : ?>

    

    <?php endforeach; ?>

  <?php endif; ?>


</label>


			</div>


 

	

	</div>
</div>

</article></div></div>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>