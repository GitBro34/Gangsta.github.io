<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_c.php"); ?>

<div class="maf_main_stat_wr left" >
<div class="maf_main_stat left" style="height: 472px;"><h3 class="maf_welc" style="color:#fff;font-size:20px;">Добро пожаловать! <span><?=$this->user_data['user']; ?></span></h3>
<div class="clear"></div>
<div class="row"><div class="m-t" style="background: url(../images/tote-head.jpg) top center no-repeat #121212 !important;">
<div class="row main_row"></div>

  </div><table class="table" style="width:100%;margin-bottom:0px;">
   
          <tr >
            <td  class="ts3" style="font-size:14px;width: 50%;text-transform: uppercase;">ЛОГИН</td>
            <td class="ts3" style="color:#fff;font-size:14px;width: 50%;text-transform: uppercase;"><?=$this->user_data['user']; ?></td>
          </tr> <tr >
            <td  class="ts3" style="font-size:14px;width: 50%;text-transform: uppercase;">E-mail</td>
            <td class="ts3" style="color:#fff;font-size:14px;width: 50%;text-transform: uppercase;"><?=$this->user_data['email']; ?></td>
          </tr> <tr >
            <td  class="ts3" style="font-size:14px;width: 50%;text-transform: uppercase;">Меня пригласил</td>
            <td class="ts3" style="color:#fff;font-size:14px;width: 50%;text-transform: uppercase;"><?=($this->user_data['referer1']) ? $this->user_data['referer1'] : 'сам пришёл'; ?></td>
          </tr>  <tr >
            <td  class="ts3" style="font-size:14px;width: 50%;text-transform: uppercase;">рефералов</td>
            <td class="ts3" style="color:#fff;font-size:14px;width: 50%;text-transform: uppercase;"><?=$this->user_data['count_ref1']; ?> чел.</td>
          </tr> <tr >
            <td  class="ts3" style="font-size:14px;width: 50%;text-transform: uppercase;">Время на проекте</td>
            <td class="ts3" style="color:#fff;font-size:14px;width: 50%;text-transform: uppercase;"><?=$this->user_data['days']; ?> дней</td>
          </tr> 


    

      </table></div></div>





<div class="maf_main_stat_wr2 left" >
<div class="maf_com_st left" style="height: 472px;width: 440px;"><h3 class="maf_welc" style="color:#fff;font-size:20px;margin-top:-90px;"></span></h3>
<table class="table" style="width:100%;margin-bottom:0px;margin-top:41px;">
   
          <tr >
            <td  class="ts3" style="font-size:14px;width: 50%;text-transform: uppercase;">Скорость заработка</td>
            <td class="ts3" style="color:#fff;font-size:14px;width: 50%;text-transform: uppercase;"><?=sprintf("%.4f", $this->user_data['speed']); ?> р/ч</td>
          </tr>
      <tr >
            <td  class="ts3" style="font-size:14px;width: 50%;text-transform: uppercase;">Сумма пополнений</td>
            <td class="ts3" style="color:#fff;font-size:14px;width: 50%;text-transform: uppercase;"><?=sprintf("%.2f", $this->user_data['insert_sum']); ?> руб.</td>
          </tr> <tr >
            <td  class="ts3" style="font-size:14px;width: 50%;text-transform: uppercase;">Сумма выплат</td>
            <td class="ts3" style="color:#fff;font-size:14px;width: 50%;text-transform: uppercase;"><?=sprintf("%.2f", $this->user_data['payment_sum']); ?> руб.</td>
          </tr> <tr >
            <td  class="ts3" style="font-size:14px;width: 50%;text-transform: uppercase;">Доход с рефералов</td>
            <td class="ts3" style="color:#fff;font-size:14px;width: 50%;text-transform: uppercase;"><?=sprintf("%.2f", $this->user_data['from_referals1'] + $this->user_data['from_referals2'] + $this->user_data['from_referals3'] + $this->user_data['from_referals4'] + $this->user_data['from_referals5']); ?> руб.</td>
          </tr> <tr >
            <td  class="ts3" style="font-size:14px;width: 50%;text-transform: uppercase;">Сделано кликов</td>
            <td class="ts3" style="color:#fff;font-size:14px;width: 50%;text-transform: uppercase;"><?=$this->user_data['serf_clicks']; ?></td>
          </tr> 


    

      </table></div>






</div></div>



</div></article></div></div>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>
