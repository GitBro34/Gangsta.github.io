<?php if (isset($_POST["dfotpr"]) && isset($_POST["antirobotpro"]) && $_POST["antirobotpro"] == "gdfg56FG423er") {
$to = "SANDYBISCRIPT@yandex.ru";
$subject = "Письмо с вашего сайта";
$charset = "utf-8";
$un = strtoupper(uniqid(time()));
$head = "Mime-Version: 1.0\r\n";
$head .= "Content-Type:multipart/mixed;";
$head .= "boundary=\"----------".$un."\"\n\n";

$body = "------------".$un."\nContent-Type:text/html; charset=$charset\r\n";

$msg =
"Имя: ".$_POST["elemnamea0"]."\n<br />".
"E-Mail: ".$_POST["elemnamea1"]."\n<br />".
"Сообщение: ".$_POST["elemnameb0"]."\n<br />".
"";

$body .= "Content-Transfer-Encoding: 8bit\n\n".$msg."\n\n";

mail($to, $subject, $body, $head);
print "<script>alert('Сообщение успешно отправлено!'); window.location='".$_SERVER['REQUEST_URI']."';</script>";
}
?>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_d.php"); ?>
<style>
#blink7 {
	width: 100%;
	display: block;
	height: 42px;
	border-radius: 50px;
	padding-left: 15px;
	border: 2px solid #3F0E0C;
	margin-bottom: 10px;
	z-index: 5;
	position: relative;
	background: linear-gradient(to right, #120E10, #161415 );
	outline: none;
	border: 2px solid rgba(32,124,194,0.4) !important;
	padding-left: 20px !important;
}


</style>
<center><div class="maf_login_wr_title" style="margin-top: -100px; "><h1 style="margin-top: 20px;">КОНТАКТЫ</h1></div></center>

<div class="maf_login_wr maf_login_man" style="margin-top: -235px; ">
<div class="maf_admin"><span style="margin-left: -20px; "><?=EMAIL; ?></span></div>
<div class="block_form"><br/>

<div  class="resultokno" >
  <form action="" method="post" enctype="multipart/form-data" class="ui-sortable">
    <div class="block_form_el cfix">
    <label for="login_frm_Login"> <span class="descr_star"></span></label>
    
    
    <div class="block_form_el cfix">
    <div class="block_form_el_right">
    <input style="text-align: center; " id="blink7" type="text" name="elemnamea0" class="dr" best="false" placeholder="Ваше имя">
    </div></div>
    
    <div class="block_form_el cfix">
    <div class="block_form_el_right">
    <input style="text-align: center; " id="blink7" type="text" name="elemnamea1"  class="dr" best="false" placeholder="Ваш E-Mail" >
    </div></div>
        
        
     <div class="block_form_el cfix">
    <div class="block_form_el_right">
    <input style="text-align: center;height: 65px  " id="blink7" name="elemnameb0" class="drt" placeholder="Текст сообщения"  data-error maxlength="2000">
    </div></div>
 
        
       
            
            <button class="start_button"   class="drr " type="submit" name="dfotpr" value="" style="margin-top: 15px;height: 50px;width: 245px; ">
    <img style="width: 245px;height: 50px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:22px;letter-spacing: 0px;">ОТПРАВИТЬ</b></span>
                 <img style="width: 245px;height: 50px " class="hover" src="/assets/gan/images/q11.png" alt="">
</button>
        </form>
<div class="avtorc "><a  target="_blank"></a></div>
<script type='text/javascript' src='https://blogjquery.ru/wp-content/files/services/bestkonst/obrab.js'></script> 


</div></div></article></div></div>

<script src="/assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>

<?php if(isset($errors) && $errors !== false) :  ?>

  <script>
    setTimeout(function(){swal('<?=$errors[0]; ?>', '<?=$errors[1]; ?>', '<?=$errors[2]; ?>')}, 100);
  </script>

<?php endif; ?>

<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>