<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_c.php"); ?>
 <div class="maf_main_stat_wr left">
	<div class="maf_main_stat maf_main_stat2 maf_main_stat_plan left">

				
				
		<form method="post" name="add">
			<input name="Oper" id="add_Oper" value="CASHIN" type="hidden">
			<h3 class="main_stat_title" style="margin-top: -5px;font-size:22px;text-transform: uppercase;"><?=$_title; ?></h3><br>
			<div class="row">
 <?php foreach ($plans as $plan) : ?>
			<div class="col-lg-6" style=" margin-bottom:15px; min-height:450px;">
					<label for="payInput1" class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" min-height:450px;width: 325px;">
                        <h4 style=" margin-top: -5px;margin-left: 25px;"><div class="head_content1">
            <div class="info1">
       
        
            </div>
        </div>  </h4>
                       

                        
 <h4 style=" margin-top: -35px;"><div class="head_content1">
            <div class="info1">
                <div class="title1" style=" margin-left: 0px;font-size:14px">
                
                 
                <br>
              
                <center>
             <div class="image"><img style="width: 240px;margin-left: 20px;margin-top: 0px;" src="/assets/images/vehicles/w<?=$plan['id']; ?>.png" alt=""></div>
              <b class="ts3" style="color:#FFC600;font-size:25px;margin-left: 25px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;"><?=$plan['name']; ?></b><br><br>
              <b class="ts3" style="color:#ccc;font-size:18px;margin-left: 25px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;">Доход в месяц: <?=round($plan['inh']); ?> %</b><br>
              <b class="ts3" style="color:#ccc;font-size:18px;margin-left: 25px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;">Доход в час: <?=sprintf("%.4f", $plan['perc']); ?> руб.</b><br>
              <b class="ts3" style="color:#ccc;font-size:18px;margin-left: 25px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;">Цена: <?=$plan['price']; ?> руб. </b><br>
              
               <form style=" " class="inner-form" action="" method="POST">
                  <input type="hidden" name="plan" value="<?=$plan['id']; ?>">
                  <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">


              <button style="margin-top: 10px; width: 245px;height: 45px;margin-left: 54px;" class="start_button" type="submit" name="buy">

                <img style="width: 245px;height: 45px  " class="bg" src="assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:19px;">КУПИТЬ ПЕРСОНАЖА</b></span>
                <img style="width: 245px;height: 45px " class="hover" src="assets/gan/images/q11.png" alt="">
            </button>
</form>
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</label>
				</div>
  <?php endforeach; ?>







			</div>


 

		</form>

	</div>
</div>

<script>
	mins={
		USD: [10, 50, 50, 250, 50, 7500],
		BTC: [0.0015, 0.005, 0.005, 0.0115, 0.0115, 0.0115, 0.0115]
	};
	rates={
		USD: 1,
		BTC: 9797.43432928
	}

	$('input[name=PSys]').click(psyschanged=function(){
		curr=$('input[name=PSys]:checked').data('curr');
		plan=$('input[name=Plan]:checked').val();
		$('#plan_sum').val((mins['USD'][plan-1]/rates[curr]).toFixed((curr == 'USD') ? 2 : 6));
	});
	$('input[name=Plan]').click(psyschanged);
	psyschanged();
</script><script type="text/javascript">function showComis(){$('#csum').html('');$('#sum2').html('');$.ajax({type: 'POST',url: 'ajax',data: 'module=balance&do=getsum'+'&oper='+$('#add_Oper').val()+'&cid='+$('#add_PSys').val()+'&sum='+$('#add_Sum').val(),success:function(ex){ex=eval(ex);$('#ccurr').html(ex[0]);$('#csum').html(ex[1]);$('#sum2').html(ex[2]);}});}tid=0;tf=function(){clearTimeout(tid);tid=setTimeout(function(){ showComis(); }, 200);};$('#add_PSys').change(tf);$('#add_Sum').keypress(tf);showComis();</script></article></div></div>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>