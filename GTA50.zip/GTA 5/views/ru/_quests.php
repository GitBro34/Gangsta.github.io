<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_c.php"); ?>
<div class="maf_main_stat_wr left">
	<div class="maf_main_stat maf_main_stat2 maf_main_stat_plan left">

				
				

			<h3 class="main_stat_title" style="margin-top: -5px;font-size:22px;text-transform: uppercase;"><?=$_title; ?></h3><br>
			<div class="row">
			    
		
				
		
				
				
	
				
				
				
				
				
				
  		<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Подписаться на сообщество проекта во ВКонтакте</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['vk_quest_bonus']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Описание квеста: Самый простой квест. Перейдите на <a target="_blank" href="<?=VK; ?>" style="color:#FFC600;">официальную страницу проекта<sup><i class="fa fa-external-link"></i></sup></a> <?=HOST; ?> во ВКонтакте и подпишитесь на сообщество со своей страницы.
               
                 
                <br>
              
                <center>
            
             <a style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" href="/handler/vk?bonus=0" >
                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">  Проверить задание</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </a>

              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>









	<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Просмотреть 100 сайтов в сёрфинге</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['serf_quest_bonus']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Сделайте 100 просмотров в разделе «<a href="serfing" style="color:#FFC600;">Сёрфинг сайтов</a>» за любой промежуток времени, а затем подавайте отчет.
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="serf_quest" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>



<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Просмотреть 500 сайтов в сёрфинге</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['serf_quest_bonus2']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Сделайте 500 просмотров в разделе «<a href="serfing" style="color:#FFC600;">Сёрфинг сайтов</a>» за любой промежуток времени, а затем подавайте отчет.
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="serf_quest2" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>



	<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Просмотреть 1000 сайтов в сёрфинге</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['serf_quest_bonus3']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Сделайте 1000 просмотров в разделе «<a href="serfing" style="color:#FFC600;">Сёрфинг сайтов</a>» за любой промежуток времени, а затем подавайте отчет.
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="serf_quest3" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>



	<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Набрать 10 рефералов в свою команду</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['ref_quest_bonus']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Пригласите в проект 10 рефералов благодаря «Партнерской программе» за любой промежуток времени.
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="ref_quest" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>

<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Набрать 50 рефералов в свою команду</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['ref_quest_bonus2']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Пригласите в проект 50 рефералов благодаря «Партнерской программе» за любой промежуток времени.
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="ref_quest2" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>

<div class="col-lg-6 " style=" margin-bottom:55px; height:140px;width: 100%;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 865px;">
                        <h4 style=" margin-top: -5px;margin-left: 0px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:18px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;color:#FFC600;margin-left: 100px;">Набрать 100 рефералов в свою команду</b>
        
            </div>
        </div>  </h4>
                       
<table class="table" style="width:20%;margin-bottom:0px;margin-top: -37px;margin-left: -26px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">НАГРАДА</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:15px;width: 100%;text-transform: uppercase;"><?=$this->config['ref_quest_bonus3']; ?> RUB</td>
            
          </tr>
       <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:12px;width: 100%;text-transform: uppercase;">Тип задания</td>
            
          </tr>
           <tr >
            <td colspan="2" class="ts3" style="color:#FFC600;font-size:14px;width: 100%;text-transform: uppercase;">одноразовое</td>
            
          </tr>
      </table>
                  
 <h4 style=" margin-top: -125px;margin-left: 45px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 155px;font-size:14px;width: 565px;"><b class="ts4" style="color:#fff;font-size:13px;letter-spacing: 2px;">Пригласите в проект 100 рефералов благодаря «Партнерской программе» за любой промежуток времени.
               
                 
                <br>
              
                <center>
            
           
	<form action="" method="POST">
     <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              			
              			<button type="submit" name="ref_quest3" style="text-decoration:none;width: 255px;margin-top: 18px; margin-left: 150px;height: 45px" class="start_button" >

                <img style="width: 255px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПРОВЕРИТЬ ЗАДАНИЕ</b></span>
                <img style="width: 255px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>		
              					
              				</form>
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>











				
				
				
				
				
				
				



			</div>


 

	

	</div>
</div></div>

</article></div></div>
<script src="/assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>