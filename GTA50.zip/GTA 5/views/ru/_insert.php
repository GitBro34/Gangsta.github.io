<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_c.php"); ?>
<style>
#blink7 {
	width: 100%;
	display: block;
	height: 42px;
	border-radius: 50px;
	padding-left: 15px;
	border: 2px solid #3F0E0C;
	margin-bottom: 10px;
	z-index: 5;
	position: relative;
	background: linear-gradient(to right, #120E10, #161415 );
	outline: none;
	border: 2px solid rgba(32,124,194,0.4) !important;
	padding-left: 20px !important;
}


</style>
 <div class="maf_main_stat_wr left">
	<div class="maf_main_stat maf_main_stat2 maf_main_stat_plan left">

				
				
		<form method="post" name="add">
			<input name="Oper" id="add_Oper" value="CASHIN" type="hidden">
			<h3 class="main_stat_title" style="margin-top: -5px;font-size:22px;text-transform: uppercase;"><?=$_title; ?></h3><br>
			<div class="row">

				<div class="col-lg-6">
					<input type="radio" name="PSys" id="payInput1" class="payInput"  checked="checked" >
					
					<label for="payInput1" class="pay_label">
						<span class="pay_span" style=" margin-top: -2px;margin-left: -22px;">ВЫБРАНО</span>
					<?php foreach ($paysystems as $paysystem) : ?>

      <?php if ($paysystem['name'] == fk) continue; ?>
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:170px;">
                        <h4 style=" margin-top: -5px;margin-left: 114px;"><div class="head_content1">
            <div class="info1">
<b class="ts3" style="font-size:36px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;"><?=$paysystem['fullname']; ?></b>
            </div>
        </div>  </h4>
                       

                        
 <h4 style=" margin-top: -35px;"><div class="head_content1">
            <div class="info1">
                <div class="title1" style=" margin-left: 0px;font-size:14px">
                
                 
                <br>
              
                <center>
              <form  class="inner_form" method="POST" action="">
              <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              <input type="hidden" name="ps" value="<?=$paysystem['name']; ?>">
                 <div class="form-group field-loginform-username required">
                <input  style="width: 325px;font-family: Gilroy-Black;font-size: 15px;color:#fff;margin-top: 25px;margin-left: 10px;" name="amount" type="text" class="plan_sum " maxlength="9" placeholder="Введите сумму пополнения... (руб.)" required>
              </div>
           

                    <button style="margin-top: 20px;margin-left: 63px;width: 225px;height: 45px " class="start_button" type="submit">

                <img style="width: 225px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:19px;"> ПЕРЕЙТИ К ОПЛАТЕ</b></span>
                <img style="width: 225px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>
            </form>
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
                <?php endforeach; ?>
					</label>
				</div>









				<div class="col-lg-6">
					<input type="radio" name="PSys" id="payInput2" class="payInput" value="6" data-min="0.001021" data-curr="BTC">
					<label for="payInput2" class="pay_label">
						<span class="pay_span" style=" margin-top: -2px;margin-left: -20px;">ВЫБРАНО</span>
						<?php foreach ($paysystems as $paysystem) : ?>

      <?php if ($paysystem['name'] == py) continue; ?>
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:170px;">
                        <h4 style=" margin-top: -5px;margin-left: 80px;"><div class="head_content1">
            <div class="info1">
<b class="ts3" style="font-size:36px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;"><?=$paysystem['fullname']; ?></b>
            </div>
        </div>  </h4>
                       

                        
 <h4 style=" margin-top: -35px;"><div class="head_content1">
            <div class="info1">
                <div class="title1" style=" margin-left: 0px;font-size:14px">
                
                 
                <br>
              
                <center>
              <form  class="inner_form" method="POST" action="">
              <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
              <input type="hidden" name="ps" value="<?=$paysystem['name']; ?>">
                 <div class="form-group field-loginform-username required">
                <input style="width: 325px;font-family: Gilroy-Black;font-size: 15px;color:#9F8660;margin-top: 25px;margin-left: 10px;background: linear-gradient(to right, #1a1c1e, #251a1a) !important;
	color: #fff;
	height: 45px;
	border: 2px solid  rgba(255,255,255,0.7);
	border-radius: 35px;" name="amount" type="text" class="plan_sum " maxlength="9" placeholder="Введите сумму пополнения... (руб.)" required>
              </div>
           

                    <button style="margin-top: 20px;margin-left: 63px;width: 225px;height: 45px " class="start_button" type="submit">

                <img style="width: 225px;height: 45px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:19px;"> ПЕРЕЙТИ К ОПЛАТЕ</b></span>
                <img style="width: 225px;height: 45px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>
            </form>
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
                <?php endforeach; ?>
					</label>
				</div>

			</div>


 
<br>
			<h3 class="main_stat_title mt-15" style="text-transform: uppercase;">Ваши последние пополнения</h3>

			<table class="table1" style="width:100%;margin-bottom:0px;">

          <tr>
            <td class="ts3" style="color:#fff;font-size:15px;width: 25%;text-transform: uppercase;">Дата пополнения</td>
            <td class="ts3" style="color:#fff;font-size:15px;width: 25%;text-transform: uppercase;">Сумма пополнения</td>
            <td class="ts3" style="color:#fff;font-size:15px;width: 25%;text-transform: uppercase;">Платежная система</td>
            <td class="ts3" style="color:#fff;font-size:15px;width: 25%;text-transform: uppercase;">Статус</td>
          </tr>
      

     

 <?php foreach ($last_inserts as $insert) : ?>

                      <tr class="text-center">
                        <td><?=date("d/m/Y в H:i", $insert['date_add']); ?></td>
                        <td><?=sprintf("%.2f", $insert['sum']); ?> руб.</td>
                        <td><?=$insert['payment_system']; ?></td>
                        <td><?=$insert['status']; ?></td>    
                      </tr> 

                    <?php endforeach; ?>
      

      </table>
		</form>

	</div>
</div>

<script>
	mins={
		USD: [10, 50, 50, 250, 50, 7500],
		BTC: [0.0015, 0.005, 0.005, 0.0115, 0.0115, 0.0115, 0.0115]
	};
	rates={
		USD: 1,
		BTC: 9797.43432928
	}

	$('input[name=PSys]').click(psyschanged=function(){
		curr=$('input[name=PSys]:checked').data('curr');
		plan=$('input[name=Plan]:checked').val();
		$('#plan_sum').val((mins['USD'][plan-1]/rates[curr]).toFixed((curr == 'USD') ? 2 : 6));
	});
	$('input[name=Plan]').click(psyschanged);
	psyschanged();
</script><script type="text/javascript">function showComis(){$('#csum').html('');$('#sum2').html('');$.ajax({type: 'POST',url: 'ajax',data: 'module=balance&do=getsum'+'&oper='+$('#add_Oper').val()+'&cid='+$('#add_PSys').val()+'&sum='+$('#add_Sum').val(),success:function(ex){ex=eval(ex);$('#ccurr').html(ex[0]);$('#csum').html(ex[1]);$('#sum2').html(ex[2]);}});}tid=0;tf=function(){clearTimeout(tid);tid=setTimeout(function(){ showComis(); }, 200);};$('#add_PSys').change(tf);$('#add_Sum').keypress(tf);showComis();</script></article></div></div>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>