<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header.php"); ?>
 <link rel="stylesheet" href="/assets/css/styles.min.css" type="text/css" media="all" />
 <script type='text/javascript' src='/assets/jquery/dist/jquery.min.js'></script>
    <script type='text/javascript' src='/assets/js/app.min.js'></script>
<section class="maf_1"><div class="container"><article class="maf_text"><div class="col-lg-6" style="position: relative;"><div class="sm_1"></div></div><div class="col-lg-6"><div class="maf1_text"><h3>Добро пожаловать  !</h3><p>Предлагаем Вам посетить нашу уникальную экономическую игру с выводом реальных денег <?=NAME; ?>.Здесь Вы можете влиться в преступный мир ,с помощью которого не только проведете время,играя в игру,но и с возможностью заработать.Хотели бы занять место на троне, к тому же получая за это деньги? Тогда Вы сделали правильный выбор!
Пройдите простую регистрацию,после чего каждому пользователю нашего проекта сразу же после регистрации дается персонаж GANSTER 1 LVL в подарок.</p><div class="home_button" style="margin: -10px auto 0 -90px;"><?php if (!$this->usid) : ?>
    <a href="/signup" >СОЗДАТЬ АККАУНТ</a>
     <?php else : ?>
    <a href="/cabinet" >В АККАУНТ</a>
      <?php endif; ?></div></div></div></article></div></section>



<section class="maf_2"><div class="container" style="position: relative;"><div class="home_title" style="margin-top:35px;margin-left: 15px;"><h2><span><b style="font-size:65px;margin-top:110px">ПАРТНЕРСКАЯ</b></span>ПРОГРАММА</h2></div><div class="home_pr"><img src="/assets/gan/images/home/home_pr.png" alt=""></div></div></section>



<section class="maf_3">
<div class="container" style="position: relative;">
<div class="row">
<div class="col-lg-6">
<div class="plans_info"> 
</div>
   
    
  <section class="vehicle-classes" style="margin-top: 140px;width: 830px;margin-left: -40px;">
   
        <div class="col-xs-12">
          <div class="vehicle-classes__vehicles">
            <div class="vehicle-classes__vehicle" style="height: 510px;">
              <img style="width: 290px;margin-left: 40px;margin-top: -10px;" src="/assets/images/vehicles/w1.png" alt="The Blade" />
              <div class="vehicle-classes__description" style="margin-left: 230px;margin-top: -25px;">
                <div class="vehicle-classes__description--inner" style="margin-left: -320px;margin-top: -25px;">
                  <h3 style="color: #ccc;font-size: 35px;font-family: Gilroy-Black;">GANSTER 1 LVL</h3>
                  <p style="color: #ccc;font-size: 20px;margin-top: 20px;">
                 
                    <strong>Стоимость :</strong> 100 рублей<br />
                    <strong>Доход в час :</strong> 0.0261 руб./час.<br />
                    <strong>Доход в месяц :</strong> 19% в месяц.<br />
                    <strong>Срок жизни :</strong> Неогроничен
                  </p>
                </div>
              </div>
            </div>
           <div class="vehicle-classes__vehicle" style="height: 510px;">
              <img style="width: 290px;margin-left: 40px;margin-top: -10px;" src="/assets/images/vehicles/w2.png" alt="The Blade" />
              <div class="vehicle-classes__description" style="margin-left: 230px;margin-top: -25px;">
                <div class="vehicle-classes__description--inner" style="margin-left: -320px;margin-top: -25px;">
                  <h3 style="color: #ccc;font-size: 35px;font-family: Gilroy-Black;">GANSTER 2 LVL</h3>
                  <p style="color: #ccc;font-size: 20px;margin-top: 20px;">
                   
                    <strong>Стоимость :</strong> 500 рублей<br />
                    <strong>Доход в час :</strong> 0.1461  руб./час.<br />
                    <strong>Доход в месяц :</strong> 22% в месяц.<br />
                    <strong>Срок жизни :</strong> Неогроничен
                  </p>
                </div>
              </div>
            </div>
           <div class="vehicle-classes__vehicle" style="height: 510px;">
              <img style="width: 290px;margin-left: 40px;margin-top: -10px;" src="/assets/images/vehicles/w3.png" alt="The Blade" />
              <div class="vehicle-classes__description" style="margin-left: 230px;margin-top: -25px;">
                <div class="vehicle-classes__description--inner" style="margin-left: -320px;margin-top: -25px;">
                  <h3 style="color: #ccc;font-size: 35px;font-family: Gilroy-Black;">GANSTER 3 LVL</h3>
                  <p style="color: #ccc;font-size: 20px;margin-top: 20px;">
                   
                    <strong>Стоимость :</strong> 1000 рублей<br />
                    <strong>Доход в час :</strong> 0.3261 руб./час.<br />
                    <strong>Доход в месяц :</strong> 24% в месяц.<br />
                    <strong>Срок жизни :</strong> Неогроничен
                  </p>
                </div>
              </div>
            </div>
             <div class="vehicle-classes__vehicle" style="height: 510px;">
              <img style="width: 290px;margin-left: 40px;margin-top: -10px;" src="/assets/images/vehicles/w4.png" alt="The Blade" />
              <div class="vehicle-classes__description" style="margin-left: 230px;margin-top: -25px;">
                <div class="vehicle-classes__description--inner" style="margin-left: -320px;margin-top: -25px;">
                  <h3 style="color: #ccc;font-size: 35px;font-family: Gilroy-Black;">GANSTER 4 LVL</h3>
                  <p style="color: #ccc;font-size: 20px;margin-top: 20px;">
                   
                    <strong>Стоимость :</strong> 2000 рублей<br />
                    <strong>Доход в час :</strong> 0.6861 руб./час.<br />
                    <strong>Доход в месяц :</strong> 26% в месяц.<br />
                    <strong>Срок жизни :</strong> Неогроничен
                  </p>
                </div>
              </div>
            </div>
              <div class="vehicle-classes__vehicle" style="height: 510px;">
              <img style="width: 290px;margin-left: 40px;margin-top: -10px;" src="/assets/images/vehicles/w5.png" alt="The Blade" />
              <div class="vehicle-classes__description" style="margin-left: 230px;margin-top: -25px;">
                <div class="vehicle-classes__description--inner" style="margin-left: -320px;margin-top: -25px;">
                  <h3 style="color: #ccc;font-size: 35px;font-family: Gilroy-Black;">GANSTER 5 LVL</h3>
                  <p style="color: #ccc;font-size: 20px;margin-top: 20px;">
                   
                    <strong>Стоимость :</strong> 3000 рублей<br />
                    <strong>Доход в час :</strong> 1.3461 руб./час.<br />
                    <strong>Доход в месяц :</strong> 33% в месяц.<br />
                    <strong>Срок жизни :</strong> Неогроничен
                  </p>
                </div>
              </div>
            </div>
            <div class="vehicle-classes__vehicle" style="height: 510px;">
              <img style="width: 290px;margin-left: 40px;margin-top: -10px;" src="/assets/images/vehicles/w6.png" alt="The Blade" />
              <div class="vehicle-classes__description" style="margin-left: 230px;margin-top: -25px;">
                <div class="vehicle-classes__description--inner" style="margin-left: -320px;margin-top: -25px;">
                  <h3 style="color: #ccc;font-size: 35px;font-family: Gilroy-Black;">GANSTER 6 LVL</h3>
                  <p style="color: #ccc;font-size: 20px;margin-top: 20px;">
                   
                    <strong>Стоимость :</strong> 5000 рублей<br />
                    <strong>Доход в час :</strong> 2.5061 руб./час.<br />
                    <strong>Доход в месяц :</strong> 37% в месяц.<br />
                    <strong>Срок жизни :</strong> Неогроничен
                  </p>
                </div>
              </div>
            </div>
             <div class="vehicle-classes__vehicle" style="height: 510px;">
              <img style="width: 290px;margin-left: 40px;margin-top: -10px;" src="/assets/images/vehicles/w7.png" alt="The Blade" />
              <div class="vehicle-classes__description" style="margin-left: 230px;margin-top: -25px;">
                <div class="vehicle-classes__description--inner" style="margin-left: -320px;margin-top: -25px;">
                  <h3 style="color: #ccc;font-size: 35px;font-family: Gilroy-Black;">GANSTER 7 LVL</h3>
                  <p style="color: #ccc;font-size: 20px;margin-top: 20px;">
                    
                    <strong>Стоимость :</strong> 10 000 рублей<br />
                    <strong>Доход в час :</strong> 6.0061 руб./час.<br />
                    <strong>Доход в месяц :</strong> 45% в месяц.<br />
                    <strong>Срок жизни :</strong> Неогроничен
                  </p>
                </div>
              </div>
            </div>
             <div class="vehicle-classes__vehicle" style="height: 510px;">
              <img style="width: 290px;margin-left: 40px;margin-top: -10px;" src="/assets/images/vehicles/w8.png" alt="The Blade" />
              <div class="vehicle-classes__description" style="margin-left: 230px;margin-top: -25px;">
                <div class="vehicle-classes__description--inner" style="margin-left: -320px;margin-top: -25px;">
                  <h3 style="color: #ccc;font-size: 35px;font-family: Gilroy-Black;">GANSTER 8 LVL</h3>
                  <p style="color: #ccc;font-size: 20px;margin-top: 20px;">
                   
                    <strong>Стоимость :</strong> 15 000 рублей<br />
                    <strong>Доход в час :</strong> 13.0061 руб./час.<br />
                    <strong>Доход в месяц :</strong> 65% в месяц.<br />
                    <strong>Срок жизни :</strong> Неогроничен
                  </p>
                </div>
              </div>
            </div>
           
          </div>
          
          
        
          <div class="vehicle-classes__classes" style="margin-top: -170px;">
            <div>
              <div class="vehicle-classes__class blade">
                <img src="/assets/images/vehicles/q001.png" alt="The Blade" />
              </div>
            </div>
            <div>
              <div class="vehicle-classes__class outlaw">
                <img src="/assets/images/vehicles/q002.png" alt="The Outlaw" />
              </div>
            </div>
            <div>
              <div class="vehicle-classes__class vortex">
                <img src="/assets/images/vehicles/q003.png" alt="The Vortex" />
              </div>
            </div>
            <div>
              <div class="vehicle-classes__class charger">
                <img src="/assets/images/vehicles/q004.png" alt="The Charger" />
              </div>
            </div>
           <div>
              <div class="vehicle-classes__class interceptor">
                <img src="/assets/images/vehicles/q005.png" alt="The Interceptor" />
              </div>
            </div>
            <div>
              <div class="vehicle-classes__class dynamo">
                <img src="/assets/images/vehicles/q006.png" alt="The Dynamo" />
              </div>
            </div>
            <div>
              <div class="vehicle-classes__class titan">
                <img src="/assets/images/vehicles/q007.png" alt="The Titan" />
              </div>
            </div>
            <div>
              <div class="vehicle-classes__class enforcer">
                <img src="/assets/images/vehicles/q008.png" alt="The Enforcer" />
              </div>
            </div>
           
          </div>
        </div>
     
  </section>
    

      
</div><div class="col-lg-6" style="position: relative;"><div class="home_title"><h2><b style="margin-left: -315px;font-size:55px;font-family: Gilroy-Black;">МАРКЕТИНГ ПРОЕКТА</b></h2></div><div id="scene2" class="main_sc"><div class="bonny_2" data-depth="0.09"></div>
    
    
    </div></div></div></div>
</section>







<section class="maf_4"><div class="container"><div class="home_stat">					<h2><b style="font-size:55px;font-family: Gilroy-Black;">СТАТИСТИКА ПРОЕКТА</b></h2>
					<div class="clear"></div>
					<div class="maf_stat_wr">
						<div class="maf_stat">
							<h3>ПОЛЬЗОВАТЕЛЕЙ</h3>
							<div class="clear"></div>
							<div class="maf_stat_sum">
								<span><?=$stats['all_users']; ?> чел.</span>
								
							</div>

						</div>

						<div class="maf_stat">
							<h3>ВСЕГО ПОПОЛНЕНО</h3>
							<div class="clear"></div>
							<div class="maf_stat_sum">
								
								<span><?=sprintf("%.2f", $stats['all_insert']); ?> руб.</span>
								
							</div>
						</div>

						<div class="maf_stat">
							<h3>ВСЕГО ВЫПЛАЧЕНО</h3>
							<div class="clear"></div>
							<div class="maf_stat_sum">
								<span><?=sprintf("%.2f", $stats['all_payment']); ?> руб.</span>
								
							</div>
						</div>

						<style>
						.maf_stat_sum span{
							color: #FFA337;
							font-weight: 700;
							font-size: 24px;
						}
					</style>


					<div class="maf_stat">
						<h3>ДНЕЙ РАБОТАЕМ</h3>
						<div class="clear"></div>
						<div class="maf_stat_sum">
							<span><?=$stats['days_work']; ?> день</span>
							
						</div>
					</div>

				</div><div class="home_button" style="margin: 20px auto 0 auto;font-size:22px;"><a href="/stats" >ПОДРОБНАЯ СТАТИСТИКА</a></div></div></div></section>
				
				
				
				
			</div></div>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>
