
<!DOCTYPE html>
<html >
<head>
	<meta charset="UTF-8">
	<title>404</title>    <link rel="stylesheet" type="text/css" href="/assets/gan/css/main.css?v=1.12">

</head>
    <body id="message/support" >


	<style>
		body {
			display: flex;
			justify-content: center;
			align-items: center;
			text-align: center;
			font-family: sans-serif;
			color: #980700;
			width: 100%;
			height: 100vh;
			overflow: hidden;
			-webkit-background-size: cover;
			background-size: cover;
		}
	</style>    


	<div style="width: 100%; font-size: 152px; font-weight: bold;">
		404
		<div style="width: 100%; font-size: 21px;">ОШИБКА</div>
		<a href="/" style="display: inline-block; background: #FF7B07; color: #000; padding: 10px 65px; border-radius: 3px; text-decoration: none; font-weight: normal; font-size: 21px;">НА ГЛАВНАЮ</a>
	</div>
	
	
</body>
</html>