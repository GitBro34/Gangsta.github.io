<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_d.php"); ?>
<center><div class="maf_login_wr_title" style="margin-top: -100px; "><h1 style="margin-top: 20px;">ОТЗЫВЫ</h1></div></center>




<?php if ($this->usid) : ?>
<div  class="maf_login_wr" style="margin-left: 105px; width: 1160px;min-height: 300px;margin-bottom: 270px;">
     <table class="table" style="width:100%;margin-bottom:0px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:20px;width: 100%;text-transform: uppercase;">Оставить отзыв</td>
          </tr>
          
       
      </table>
      
      <form style="width: 1145px; margin-left: 15px;" action="" method="POST" class="inner-form">
        <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
     <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 96%;max-width: 100%">
                    
                    <div class="plan1">
                        <h4 style=" margin-top: -25px;"><div class="head_content1">
            <div class="info1">
                 <br>
                 <center><textarea style="width: 745px;height: 115px;margin-top: 30px; margin-left: 135px;color:#000; " name="text" class="textarea textarea_fullwidth" maxlength="750" placeholder="Введите текст отзыва, 80 - 750 символов"></textarea></center>
                
               <center>  <button type="submit" style="height: 50px;margin-top: 10px;margin-left: 375px;" class=" start_button"  >

                <img style="width: 285px;height: 50px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:22px;">ДОБАВИТЬ ОТЗЫВ</b></span>
                <img style="width: 285px;height: 50px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button></center>
                    
                    
            </div>
        </div> </h4>

        </div>

    </div>
 </form>
<div class="block_form"><br/>
<div class="block_form_el cfix">

        <center >
<div class="ts33" style=" margin-top: 0px;font-size:18px;color:#ccc;font-family: 'Roboto Condensed', sans-serif !important;"><?=$feedback['text']; ?></div>
</center>


</div>
</div></div>
<?php endif; ?>







 <?php foreach ($feedbacks as $feedback) : ?>

<div  class="maf_login_wr" style="float:left;margin-left: 90px; width: 337px;min-height: 300px;margin-bottom: 270px;">
     <table class="table" style="width:100%;margin-bottom:0px;">
          <tr >
            <td colspan="2" class="ts3" style="color:#fff;font-size:20px;width: 100%;text-transform: uppercase;"><?=$feedback['user']; ?></td>
          </tr>
          
        <tr>
          <td style="width: 50%;">Опубликовано</td>
          <td style="width: 50%;"><?=date("d.m.Y", $feedback['date_add']); ?></td>
        </tr>
      </table>
<div class="block_form"><br/>
<div class="block_form_el cfix">

        <center >
<div class="ts33" style=" margin-top: 0px;font-size:18px;color:#ccc;font-family: 'Roboto Condensed', sans-serif !important;"><?=$feedback['text']; ?></div>
</center>


</div>
</div></div>
     <?php endforeach; ?>  





<script src="/assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>

<?php if(isset($errors) && $errors !== false) :  ?>

  <script>
    setTimeout(function(){swal('<?=$errors[0]; ?>', '<?=$errors[1]; ?>', '<?=$errors[2]; ?>')}, 100);
  </script>

<?php endif; ?>

<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>