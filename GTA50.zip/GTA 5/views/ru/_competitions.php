<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_d.php"); ?>
<center><div class="maf_login_wr_title" style="margin-top: -100px; "><h1 style="margin-top: 20px;">КОНКУРСЫ</h1></div></center>





<div  class="maf_login_wr" style="float:left;margin-left: 110px; width: 545px;min-height: 400px;margin-bottom: 270px;">
<div class="maf_admin1" style="margin-top: -25px;"><span style="margin-left: -35px;font-size:19px ">Ежемесячный&nbsp;Конкурс&nbsp;инвесторов</span></div>
<div class="ts3" style=" margin-top: -20px;margin-left: 160px;font-size:14px;color:#ffc10a;text-transform: uppercase;">Окончание конкурса: <?=date("d/m/Y в H:i", $invest_competition['date_end']); ?></div>
<div class="block_form"><br/>


 
    <div class="block_form_el cfix">

 
        <?php if ($invest_competition) : ?>
 <table class="table" style="width:100%;margin-bottom:0px;">
   
          <tr >
            <td  class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">ЛОГИН</td>
            <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Пополнений</td>
             <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Приз</td>
          </tr>
     
        
      <?php if (isset($invest_competition['users'])) : $i = 0; ?>

            <?php foreach ($invest_competition['users'] as $user) : $i++; ?>

              <?php if ($i > 5) break; ?>

            <tr>
              <td ><?=$user['user']; ?></td>
              <td ><?=sprintf("%.2f", $user['points']); ?> руб.</td>

                <?php if ($i <= 5) : ?>

              <td  class="tdactive">

                <?php if ($invest_competition[$i.'m_sum'] > 0 && $invest_competition[$i.'m_perc'] > 0) : ?>

                  <?=$invest_competition[$i.'m_sum']; ?> руб. + <?=$invest_competition[$i.'m_perc']; ?> % 

                <?php elseif ($invest_competition[$i.'m_sum'] == 0 && $invest_competition[$i.'m_perc'] > 0) : ?>

                  <?=$invest_competition[$i.'m_perc']; ?> % от суммы

                <?php elseif ($invest_competition[$i.'m_sum'] > 0 && $invest_competition[$i.'m_perc'] == 0) : ?>

                  <?=$invest_competition[$i.'m_sum']; ?> руб.
                  
                <?php endif ?>

              </td>

                <?php else : ?>

              <td> - </td>

                <?php endif; ?>

            </tr>

            <?php endforeach; ?>

          <?php else: ?>

            <tr>
              <td colspan="3">Участников еще нет</td>
            </tr>

          <?php endif; ?>

          </table> <?php endif ?> 




</div>
</div></div>

<div  class="maf_login_wr" style="float:left;margin-left: 74px; width: 545px;min-height: 400px;margin-bottom: 270px;">
<div class="maf_admin1" style="margin-top: -25px;"><span style="margin-left: -35px;font-size:19px ">Ежемесячный&nbsp;Конкурс&nbsp;рефералов</span></div>
<div class="ts3" style=" margin-top: -20px;margin-left: 160px;font-size:14px;color:#ffc10a;text-transform: uppercase;">Окончание конкурса: <?=date("d/m/Y в H:i", $invest_competition['date_end']); ?></div>
<div class="block_form"><br/>


 
    <div class="block_form_el cfix">

 <?php if ($referal_competition) : ?>
        
<table class="table" style="width:100%;margin-bottom:0px;">

          <tr>
            <td  class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">ЛОГИН</td>
            <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Пополнений</td>
             <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Приз</td>
          </tr>
      

   <?php if (isset($referal_competition['users'])) : $i = 0; ?>

            <?php foreach ($referal_competition['users'] as $user) : $i++; ?>

              <?php if ($i > 5) break; ?>

            <tr>
              <td><?=$user['user']; ?></td>
              <td ><?=sprintf("%.2f", $user['points']); ?> руб.</td>
              
              
                    <?php if ($i <= 5) : ?>

              <td  class="tdactive">

                <?php if ($referal_competition[$i.'m_sum'] > 0 && $referal_competition[$i.'m_perc'] > 0) : ?>

                  <?=$referal_competition[$i.'m_sum']; ?> руб. + <?=$referal_competition[$i.'m_perc']; ?> % 

                <?php elseif ($referal_competition[$i.'m_sum'] == 0 && $referal_competition[$i.'m_perc'] > 0) : ?>

                  <?=$referal_competition[$i.'m_perc']; ?> % от суммы

                <?php elseif ($referal_competition[$i.'m_sum'] > 0 && $referal_competition[$i.'m_perc'] == 0) : ?>

                  <?=$referal_competition[$i.'m_sum']; ?> руб.
                  
                <?php endif ?>

              </td>

                <?php else : ?>

              <td> - </td>

                <?php endif; ?>

            </tr>

            <?php endforeach; ?>

          <?php else: ?>

              
            <tr>
              <td colspan="3">Участников еще нет</td>
            </tr>

          <?php endif; ?>

          </table>       <?php endif; ?>



</div>
</div></div>








<script src="/assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>

<?php if(isset($errors) && $errors !== false) :  ?>

  <script>
    setTimeout(function(){swal('<?=$errors[0]; ?>', '<?=$errors[1]; ?>', '<?=$errors[2]; ?>')}, 100);
  </script>

<?php endif; ?>

<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>