
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="refresh" content="3;URL=/cabinet" />
	<title><?=$_title; ?> | <?=NAME; ?></title>
	<link href='https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,300,600,700' rel='stylesheet' type='text/css'>
	<link href="/assets/styles/animation.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="/assets/styles/main.css">
</head>
<body style="background-color:#000;"><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<b style="margin-left: 440px;font-size: 55px;">Ошибка !</b>
</body>
</html>