<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_c.php"); ?>
<script src="/assets/scripts/jquery-3.1.0.min.js"></script>
<script src="/assets/js/serfing.js"></script>
<script>

  function goserf(obj) {

    setTimeout(function(){

      obj.parentNode.parentNode.parentNode.parentNode.classList.add('surfblockopen');

      var myReq = new XMLHttpRequest();

      function succFunc (e){
        var tckns = [];
        tckn = myReq.responseText;
        console.log(tckn);
        tckns = document.querySelectorAll('input[name="_tocken"]');
        tckns.forEach(function(item, i, tckns) {
          item.value = tckn;
        });
      }

      myReq.open("POST", "/serfing/gettocken", true);
      myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      myReq.onreadystatechange = succFunc;
      myReq.send();

    }, 200)

  }

</script>
<div class="maf_main_stat_wr left">
	<div class="maf_main_stat maf_main_stat2 maf_main_stat_plan left">

				
				

			<h3 class="main_stat_title" style="margin-top: -5px;font-size:22px;text-transform: uppercase;"><?=$_title; ?></h3><br>
			<div class="row">
			    
			    
			   <a href="/serfing" style="text-decoration:none;width: 200px;margin-top: -15px;float:left;margin-left: 116px;" class="start_button5"  >
                <img style="width: 200px;height: 35px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:16px;letter-spacing: 1px;">СЕРФИНГ&nbsp;САЙТОВ</b></span>
            <img style="width: 200px;height: 35px " class="hover" src="/assets/gan/images/q9.png" alt="">
                </a>
    
            <a href="/serfing/my" style="text-decoration:none;width: 200px;margin-top: -15px;float:left;margin-left:25px;" class="start_button5"  >
                <img style="width: 200px;height: 35px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:16px;letter-spacing: 1px;">МОИ&nbsp;САЙТ</b></span>
            <img style="width: 200px;height: 35px " class="hover" src="/assets/gan/images/q9.png" alt="">
                </a>
             <a href="/serfing/add" style="text-decoration:none;width: 200px;margin-top: -15px;float:left;margin-left: 25px;" class="start_button5"  >
                <img style="width: 200px;height: 35px  " class="bg" src="/assets/gan/images/q9.png" alt="">
            <span><b class="ts4" style="color:#fff;font-size:16px;letter-spacing: 1px;">ДОБАВИТЬ&nbsp;САЙТ</b></span>
            <img style="width: 200px;height: 35px " class="hover" src="/assets/gan/images/q9.png" alt="">
                </a> 
			    
				
		
				
				
			 <?php foreach ($serfs as $serf) : ?>
  		<div class="col-lg-6 " style=" margin-bottom:15px; height:140px;">
					<div  class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:140px;width: 325px;">
                        <h4 style=" margin-top: -5px;margin-left: 25px;"><div class="head_content1">
            <div class="info1">
       <b class="ts3" style="font-size:25px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;"><?=$serf['title']; ?></b>
        
            </div>
        </div>  </h4>
                       

                        
 <h4 style=" margin-top: 15px;margin-left: 25px;"><div class="head_content1">
            <div class="info1">
              <div class="title1" style=" margin-left: 0px;font-size:14px"><b class="ts4" style="color:#fff;font-size:14px;letter-spacing: 2px;">Время просмотра: <?=$serf['view_time']; ?> сек.
              
                <br>Осталось <?=floor($serf['money']/$serf['price']); ?> просмотров</b>
               
                 
                <br>
              
                <center>
            
            <form  action="/serfing/<?=$serf['id']; ?>" method="POST" target="_blank" style="display: inline-block">
                <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
 <button type="submit" onclick="goserf(this);" style="width: 275px;height: 50px  " class="start_button" >

                <img style="width: 275px;height: 50px  " class="bg" src="/assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:17px;">ПОСМОТРЕТЬ САЙТ (<?=$serf['click_price']; ?> руб.)</b></span>
                <img style="width: 275px;height: 50px " class="hover" src="/assets/gan/images/q11.png" alt="">
            </button>
            </form>

              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</div>
				</div>
  <?php endforeach; ?>







			</div>


 

	

	</div>
</div>

</article></div></div>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>