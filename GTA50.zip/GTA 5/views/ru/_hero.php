<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_c.php"); ?>
 <div class="maf_main_stat_wr left">
	<div class="maf_main_stat maf_main_stat2 maf_main_stat_plan left">

				
				
		<form method="post" name="add">
			<input name="Oper" id="add_Oper" value="CASHIN" type="hidden">
			<h3 class="main_stat_title" style="margin-top: -5px;font-size:22px;text-transform: uppercase;"><?=$_title; ?></h3><br>
			<div class="row">
			    
			    
			    
			    	<div class="col-lg-6" style=" margin-bottom:15px;width: 100%; ">
					<label for="payInput1" class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;">
                    
                    <div class="plan1" style=" height:155px;width: 810px;">
                        <h4 style=" margin-top: -5px;margin-left: 25px;"><div class="head_content1">
            <div class="info1">
       
        
            </div>
        </div>  </h4>
                       

                        
 <h4 style=" margin-top: -35px;"><div class="head_content1">
            <div class="info1">
                <div class="title1" style=" margin-left: 0px;font-size:14px">
                
                 
                <br>
              
                <center>
             
              <b class="ts3" style="color:#FFC600;font-size:25px;margin-left: 0px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;">КАССА ВАШИХ ПЕРСОНАЖЕЙ</b><br><br>
              <span id="bls " style=" margin-left: -50px;"><b style="color:#ccc;font-family: Gilroy-Black;font-size: 33px;" class="ts4"><?=sprintf("%.8f", $this->user_data['money_k']); ?></b> </span>  <div style=" margin-top: -18px;margin-left: 188px;" class="rub"><b style=" color:#ccc;font-size:14px;font-family: Gilroy-Black;" class="ts4">рублей</b></div>
              
              <?php if ($this->user_data['money_k'] < 0.01) : ?>

                <p class="text-muted m-b-0 m-t-15">
                  <div class="carserrorbox" style="font-size:14px;color:#ffc10a;font-weight: 900;margin-top: 25px;" ><b class="ts4" style="font-size:14px;color:#ffc10a;font-weight: 900;">Снять деньги с кассы можно как только накопится хотя бы 0.01 руб !</b></div>
                </p>

              <?php else : ?>
    <center>
                <form style="margin-top: -10px;"  action="" method="post" class="inner-form">
                  <input type="hidden" name="_tocken" value="<?=Session::$tocken; ?>">
                
                  
                  
                  
                    
                    
                    
                    <button style="width: 285px;height: 45px "   class="start_button3" type="submit" name="swap">

                <img style="width: 285px;height: 50px  " class="bg" src="assets/gan/images/q9.png" alt="">
                <span><b class="ts3" style="color:#fff;font-size:22px;">СНЯТЬ С КАССЫ</b></span>
                <img style="width: 285px;height: 50px " class="hover" src="assets/gan/images/q11.png" alt="">
            </button>
                </form>
    </center>
              <?php endif; ?>
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</label>
				</div>
				
				
				
  <?php foreach ($deposits as $deposit )  :  ?>
			<div class="col-lg-6" style=" margin-bottom:15px; ">
					<label for="payInput1" class="pay_label">
  
                  <div  class="col-sm-3" style="-ms-flex: 0 0 25%;flex: 0 0 25%;max-width: 37%;float:left;">
                    
                    <div class="plan1" style=" height:310px;width: 325px;">
                        <h4 style=" margin-top: -5px;margin-left: 25px;"><div class="head_content1">
            <div class="info1">
       
        
            </div>
        </div>  </h4>
                       

                        
 <h4 style=" margin-top: -35px;"><div class="head_content1">
            <div class="info1">
                <div class="title1" style=" margin-left: 0px;font-size:14px">
                
                 
                <br>
              
                <center>
             <div class="image"><img style="width: 240px;margin-left: 20px;margin-top: -10px;" src="/assets/images/vehicles/w<?=$deposit['plan']; ?>.png" alt=""></div>
              <b class="ts3" style="color:#FFC600;font-size:25px;margin-left: 20px;margin-top: 0px;font-family: Gilroy-Black;text-transform: uppercase;"><?=$deposit['name']; ?></b><br><br>
              
              
              
                  </center>
       
                
                </div>
            </div>
        </div>  </h4>
   


                    </div>

                </div>
               
					</label>
				</div>
  <?php endforeach; ?>







			</div>


 

		</form>

	</div>
</div>

<script>
	mins={
		USD: [10, 50, 50, 250, 50, 7500],
		BTC: [0.0015, 0.005, 0.005, 0.0115, 0.0115, 0.0115, 0.0115]
	};
	rates={
		USD: 1,
		BTC: 9797.43432928
	}

	$('input[name=PSys]').click(psyschanged=function(){
		curr=$('input[name=PSys]:checked').data('curr');
		plan=$('input[name=Plan]:checked').val();
		$('#plan_sum').val((mins['USD'][plan-1]/rates[curr]).toFixed((curr == 'USD') ? 2 : 6));
	});
	$('input[name=Plan]').click(psyschanged);
	psyschanged();
</script><script type="text/javascript">function showComis(){$('#csum').html('');$('#sum2').html('');$.ajax({type: 'POST',url: 'ajax',data: 'module=balance&do=getsum'+'&oper='+$('#add_Oper').val()+'&cid='+$('#add_PSys').val()+'&sum='+$('#add_Sum').val(),success:function(ex){ex=eval(ex);$('#ccurr').html(ex[0]);$('#csum').html(ex[1]);$('#sum2').html(ex[2]);}});}tid=0;tf=function(){clearTimeout(tid);tid=setTimeout(function(){ showComis(); }, 200);};$('#add_PSys').change(tf);$('#add_Sum').keypress(tf);showComis();</script></article></div></div>
<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>