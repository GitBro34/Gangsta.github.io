<?php require_once(ROOT . "/views/" . LANG . "/layouts/_header_d.php"); ?>
<center><div class="maf_login_wr_title" style="margin-top: -100px; "><h1 style="margin-top: 20px;">СТАТИСТИКА</h1></div></center>

<div  class="maf_login_wr" style="float:left;margin-left: 110px; width: 545px;min-height: 400px;margin-bottom: 270px;">
<div class="maf_admin1" style="margin-top: -25px;"><span style="margin-left: -30px;font-size:19px ">Рейтинг&nbsp;по&nbsp;скорости&nbsp;заработка</span></div>
<div class="block_form"><br/>


   <center>
    <div class="block_form_el cfix">

 
        
 <table class="table" style="width:100%;margin-bottom:0px;">
   
          <tr >
            <td  class="ts3" style="color:#fff;font-size:16px;width: 50%;text-transform: uppercase;">ЛОГИН</td>
            <td class="ts3" style="color:#fff;font-size:16px;width: 50%;text-transform: uppercase;">Скорость</td>
          </tr>
     
        
      <?php foreach ($top_speed as $user) : ?>

      
        <tr>
          <td >&nbsp;<?=$user['user']; ?>&nbsp;</td>
          <td><?=sprintf("%.4f", $user['speed']); ?> руб.</td>
        </tr>

 <?php endforeach; ?>
    

      </table>




</div>
</div></div>

<div  class="maf_login_wr" style="float:left;margin-left: 74px; width: 545px;min-height: 400px;margin-bottom: 270px;">
<div class="maf_admin1" style="margin-top: -25px;"><span style="margin-left: -30px;font-size:19px ">Рейтинг&nbsp;по&nbsp;доходу&nbsp;c&nbsp;рефералов</span></div>
<div class="block_form"><br/>


 
    <div class="block_form_el cfix">

 
        
<table class="table" style="width:100%;margin-bottom:0px;">

          <tr>
            <td class="ts3" style="color:#fff;font-size:16px;width: 50%;text-transform: uppercase;">Логин</td>
            <td class="ts3" style="color:#fff;font-size:16px;width: 50%;text-transform: uppercase;">Реф. доход</td>
          </tr>
      

      <?php foreach ($top_referals_money as $user) : ?>

        <tr>
          <td>&nbsp;<?=$user['user']; ?>&nbsp;</td>
          <td><?=sprintf("%.2f", $user['ref_sum']); ?> руб.</td>
        </tr>

      <?php endforeach; ?>

      </table>




</div>
</div></div>




<div  class="maf_login_wr" style="float:left;margin-left: 110px; width: 545px;min-height: 400px;margin-bottom: 270px;">
<div class="maf_admin1" style="margin-top: -25px;"><span style="margin-left: -30px;font-size:19px ">Рейтинг&nbsp;по&nbsp;сумме&nbsp;заработка</span></div>
<div class="block_form"><br/>


 
    <div class="block_form_el cfix">

 
        
<table class="table" style="width:100%;margin-bottom:0px;">
     
          <tr>
            <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Логин</td>
            <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Дата регистрации</td>
            <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Выведено</td>
          </tr>
       

      <?php foreach ($top_pays as $user) : ?>

        <tr>
          <td>&nbsp;<?=$user['user']; ?>&nbsp;</td>
          <td><?=date("d/m/Y в H:i", $user['date_reg']); ?></td>
          <td><?=sprintf("%.2f", $user['payment_sum']); ?> руб.</td>
        </tr>

      <?php endforeach; ?>

      </table>




</div>
</div></div>

<div  class="maf_login_wr" style="float:left;margin-left: 75px; width: 545px;min-height: 400px;margin-bottom: 270px;">
<div class="maf_admin1" style="margin-top: -25px;"><span style="margin-left: -30px;font-size:19px ">Рейтинг&nbsp;по&nbsp;кол-ву&nbsp;рефералов</span></div>
<div class="block_form"><br/>


 
    <div class="block_form_el cfix">

 
        
 <table class="table" style="width:100%;margin-bottom:0px;">
     
          <tr>
            <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Логин</td>
            <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Дата регистрации</td>
            <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Рефералы</td>
          </tr>
       

      <?php foreach ($top_referals as $user) : ?>

        <tr>
          <td>&nbsp;<?=$user['user']; ?>&nbsp;</td>
          <td><?=date("d/m/Y в H:i", $user['date_reg']); ?></td>
          <td><?=$user['count_ref1']; ?> чел.</td>
        </tr>

      <?php endforeach; ?>

      </table>




</div>
</div></div>

<div  class="maf_login_wr" style="float:left;margin-left: 110px; width: 545px;min-height: 400px;margin-bottom: 50px;">
<div class="maf_admin1" style="margin-top: -25px;"><span style="margin-left: 0px;font-size:19px ">Последние&nbsp;10&nbsp;выплат</span></div>
<div class="block_form"><br/>


 
    <div class="block_form_el cfix">

 
        
 <table class="table" style="width:100%;margin-bottom:0px;">
      
            <tr>
              <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Логин</td>
              <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;"> система</td>
              <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Сумма</td>
            </tr>
     

        <?php foreach ($pays as $pay) : ?>

          <tr>
            <td><?=$pay['user']; ?></td>
            <td><?=$pay['fullname']; ?></td>
            <td><?=sprintf("%.2f", $pay['sum']); ?> руб.</td>
          </tr>

        <?php endforeach; ?>

        </table>




</div>
</div></div>

<div  class="maf_login_wr" style="float:left;margin-left: 75px; width: 545px;min-height: 400px;margin-bottom: 50px;">
<div class="maf_admin1" style="margin-top: -25px;"><span style="margin-left: 0px;font-size:19px ">Последние&nbsp;10&nbsp;пополнений</span></div>
<div class="block_form"><br/>


 
    <div class="block_form_el cfix">

 
        
 <table class="table" style="width:100%;margin-bottom:0px;">
   
         
            <tr>
              <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Логин</td>
              <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;"> система</td>
              <td class="ts3" style="color:#fff;font-size:16px;width: 33%;text-transform: uppercase;">Сумма</td>
            </tr>
        

        <?php foreach ($inserts as $insert) : ?>

          <tr>
            <td><?=$insert['user']; ?></td>
            <td><?=$insert['fullname']; ?></td>
            <td><?=sprintf("%.2f", $insert['sum']); ?> руб.</td>
          </tr>

        <?php endforeach; ?>

      </table>




</div>
</div></div>





<script src="/assets/plugins/bootstrap-sweetalert/sweet-alert.min.js"></script>

<?php if(isset($errors) && $errors !== false) :  ?>

  <script>
    setTimeout(function(){swal('<?=$errors[0]; ?>', '<?=$errors[1]; ?>', '<?=$errors[2]; ?>')}, 100);
  </script>

<?php endif; ?>

<?php require_once(ROOT . "/views/" . LANG . "/layouts/_footer.php"); ?>