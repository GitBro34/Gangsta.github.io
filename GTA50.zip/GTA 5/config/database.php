<?php

// Массив с параметрами подключения к базе данных
return array(
    'host' => 'localhost',
    'dbname' => '435435',
    'user' => '354345345',
    'password' => '345354345!',
);