<?php 

define('PROTOCOL', 'http');

define('HOST', $_SERVER['HTTP_HOST']);

define('NAME', 'GANSTER MONEY');

define('VK', 'https://vk.com/'); 

define('FB', 'https://FB.com/'); 

define('TW', 'https://TW.com/'); 

define('TG', 'https://TG.com/'); 

define('SKYPE', 'GANSTERMONEY');

define('EMAIL', 'support@GANSTERMONEY.ru');