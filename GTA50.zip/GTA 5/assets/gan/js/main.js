$(function(){ new Clipboard('#btncopy'); });
$(function(){ new Clipboard('#btncopy2'); });

$(function() {
  var d=360;
  $("#rol_btn").click(function(){
    // $(".rol_s").toggleClass("rol_s_anim");
    $('.rol').each(function(){
      var $this = $(this);
      var r=Math.floor(Math.random()*1000)-360;
      $this.css({
        '-moz-transform':'rotate('+r+'deg)',
        '-webkit-transform':'rotate('+r+'deg)',
        'transform':'rotate('+r+'deg)'
      });
    });
  });
});

jQuery(document).ready(function( $ ) {
  $('.counter').counterUp({
    delay: 100,
    time: 2000
  });
});

jQuery(document).ready(function( $ ) {
         // Pretty simple huh?
         var scene = document.getElementById('scene');
         var parallax = new Parallax(scene);
       });

jQuery(document).ready(function( $ ) {
         // Pretty simple huh?
         var scene = document.getElementById('scene2');
         var parallax = new Parallax(scene);
       });

$(document).ready(function() {
	var owl = $('.maf_total_carousel1');
	owl.owlCarousel({
		items: 1,
		loop: true,
		nav: false,
		margin: 10,
		autoplay: true,
		lazyLoad: true,
		autoplayTimeout: 4000,
		autoplayHoverPause: true,
		responsive:{
			0:{
				items:1
			},
			600:{
				items:1
			},
			1000:{
				items:1
			}
		}
	});
})

$(document).ready(function() {
	var owl = $('.maf_total_carousel2');
	owl.owlCarousel({
		items: 5,
		loop: false,
		nav: false,
		margin: 0,
		autoplay: true,
		lazyLoad: true,
		autoplayTimeout: 3500,
		autoplayHoverPause: true,
		responsive:{
			0:{
				nav: true,
				items:1
			},
			600:{
				nav: true,
				items:3
			},
			1000:{
				nav: true,
				items:5
			}
		}
	});
})


$(function(){
  $('#sroll-block').totemticker({
    row_height : '55px',
    next : '#next',
    previous : '#previous',
    stop : '#stop',
    start : '#start',
    speed : 1500,
    max_items	: 	null,
    interval : 4000,
    mousestop : false,
  });
});

$(function(){
  $('#sroll-block2').totemticker({
    row_height : '55px',
    next : '#next',
    previous : '#previous',
    stop : '#stop',
    start : '#start',
    speed : 1500,
    max_items	: 	null,
    interval : 4000,
    mousestop : false,
  });
});

$(function(){
  $('#sroll-block3').totemticker({
    row_height : '55px',
    next : '#next',
    previous : '#previous',
    stop : '#stop',
    start : '#start',
    speed : 1500,
    max_items	: 	null,
    interval : 4000,
    mousestop : false,
  });
});

$(function(){
  $('#sroll-block4').totemticker({
    row_height : '55px',
    next : '#next',
    previous : '#previous',
    stop : '#stop',
    start : '#start',
    speed : 1500,
    max_items	: 	null,
    interval : 4000,
    mousestop : false,
  });
});


$(function(){
  $('#sroll-block5').totemticker({
    row_height : '55px',
    next : '#next',
    previous : '#previous',
    stop : '#stop',
    start : '#start',
    speed : 1500,
    max_items	: 	null,
    interval : 4000,
    mousestop : false,
  });
});

$(function(){
  $('#sroll-block6').totemticker({
    row_height : '55px',
    next : '#next',
    previous : '#previous',
    stop : '#stop',
    start : '#start',
    speed : 1500,
    max_items	: 	null,
    interval : 4000,
    mousestop : false,
  });
});

$(window).on('load', function () {
  $preloader = $('.loaderArea'),
  $loader = $preloader.find('.loader');
  $loader.fadeOut();
  $preloader.delay(350).fadeOut('slow');
});

$("[data-fancybox]").fancybox({

});

// $('.maf_cab_asid ul li').click(function(){
//     $(this).toggleClass('maf_cab_asid_act')
// })

try{
  var el=document.getElementById('maf_ul_a').getElementsByTagName('a');
  var url=document.location.href;
  for(var i=0;i<el.length; i++){
    if (url==el[i].href){
      el[i].className += 'maf_cab_asid_act';
    };
  };
}catch(e){}

try{
  var el=document.getElementById('maf_home_ul_a').getElementsByTagName('a');
  var url=document.location.href;
  for(var i=0;i<el.length; i++){
    if (url==el[i].href){
      el[i].className += 'maf_home_ul_a_act';
    };
  };
}catch(e){}

