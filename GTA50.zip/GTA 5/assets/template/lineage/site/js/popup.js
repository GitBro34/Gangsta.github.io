//==============================
$(document).ready(function(){
	$('div[data-rel="popup-content"]').wrapAll('<div id="popup"><div id="popup-flex"><div id="popup-block"></div></div></div>');
	$('#popup').prepend('<a class="popup-close"></a>');

	var class_1 = 'modal-open';
	var class_2 = 'modal-close';
	var time = 300;

	$('div[data-rel="popup-content"]').addClass(class_1);
	$('div[data-rel="popup-content"]').prepend('<a class="popup-close-content"></a>');

	$(document).on('click', 'a[data-rel="popup"]', function(e){
		var popup = $(this).attr('data-href');
		$('#popup').fadeIn(time);
		$('#popup #popup-flex').addClass('active').find(popup).fadeIn(time);
		$('.navigation, #general').removeClass(class_2).addClass(class_1);
		$('body').css('overflow', 'hidden');
		e.preventDefault();
	});
	$('#popup').on('click', 'a[data-rel="popup-inner"]', function(e){
		var popup = $(this).attr('data-href');
		$('#popup #popup-flex').find('div[data-rel="popup-content"]').removeClass(class_1).addClass(class_2).fadeOut(time);
		setTimeout(function(){
			$('#popup #popup-flex').find(popup).show();
		}, time);
		e.preventDefault();
	});

	$('#popup').on('click', 'a.popup-close, a.popup-close-content', function(e){
		$('#popup #popup-flex').removeClass('active').find('div[data-rel="popup-content"]').fadeOut(time);
		setTimeout(function(){
			$('#popup').fadeOut(time);
			$('.navigation, #general').removeClass(class_1).addClass(class_2);
			$('body').css('overflow', 'auto');
		}, time);
		e.preventDefault();
	});
});
//==============================